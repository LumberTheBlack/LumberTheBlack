<?php

namespace App\Repository;

use App\Entity\Cartridge;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Cartridge|null find($id, $lockMode = null, $lockVersion = null)
 * @method Cartridge|null findOneBy(array $criteria, array $orderBy = null)
 * @method Cartridge[]    findAll()
 * @method Cartridge[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class CartridgeRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Cartridge::class);
    }

    public function findBySn($search)
    {
        return $this->createQueryBuilder('c')
            ->andWhere("c.sn LIKE :search")
            ->setParameter('search','%'.$search.'%')
            ->getQuery()
            ->getResult()
            ;
    }

    // /**
    //  * @return Cartridge[] Returns an array of Cartridge objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('c.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Cartridge
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
