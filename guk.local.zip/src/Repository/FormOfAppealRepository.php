<?php

namespace App\Repository;

use App\Entity\FormOfAppeal;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method FormOfAppeal|null find($id, $lockMode = null, $lockVersion = null)
 * @method FormOfAppeal|null findOneBy(array $criteria, array $orderBy = null)
 * @method FormOfAppeal[]    findAll()
 * @method FormOfAppeal[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class FormOfAppealRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, FormOfAppeal::class);
    }

    // /**
    //  * @return FormOfAppeal[] Returns an array of FormOfAppeal objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('f')
            ->andWhere('f.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('f.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?FormOfAppeal
    {
        return $this->createQueryBuilder('f')
            ->andWhere('f.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
