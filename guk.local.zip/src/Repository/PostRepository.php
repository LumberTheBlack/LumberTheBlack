<?php

namespace App\Repository;

use App\Entity\Post;
use App\Entity\Tag;
use App\Entity\User;
use App\Pagination\Paginator;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * This custom Doctrine repository contains some methods which are useful when
 * querying for blog post information.
 *
 * See https://symfony.com/doc/current/doctrine/repository.html
 *
 */
class PostRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Post::class);
    }

    public function findLatest(Tag $tag = null)
    {
        $qb = $this->createQueryBuilder('p')
            ->addSelect('a', 't')
            ->innerJoin('p.author', 'a')
            ->leftJoin('p.tags', 't')
            ->where('p.publishedAt <= :now')
            ->setParameter('now', new \DateTime())
        ;

        if (null !== $tag) {
            $qb->andWhere(':tag MEMBER OF p.tags')
                ->setParameter('tag', $tag);
        }

        $qb->orderBy('p.publishedAt', 'DESC');
        return $qb;
    }

    public function findByUser(User $user){
        $qb=$this->createQueryBuilder('p')
            ->addSelect('a','t')
            ->innerJoin('p.author','a')
            ->leftJoin('p.tags','t')
            ->where('p.author=:user')
            ->orderBy('p.publishedAt','DESC')
            ->setParameter('user',$user);
        return $qb;
    }

    public function findBySearchQuery(string $rawQuery, int $limit = Post::NUM_ITEMS)
    {
        $searchTerms = $this->extractSearchTerms($rawQuery);

        if (0 === \count($searchTerms)) {
            return null;
        }

        $queryBuilder = $this->createQueryBuilder('p');

        foreach ($searchTerms as $key => $term) {
            $queryBuilder
                ->orWhere('LOWER(p.title) LIKE LOWER(:t_'.$key.')')
                ->setParameter('t_'.$key, '%'.$term.'%')
            ;
        }

         $queryBuilder
            ->orderBy('p.publishedAt', 'DESC');
            //->setMaxResults($limit)
            //->getQuery()
            //->getResult();
        return $queryBuilder;
    }

    /**
     * Removes all non-alphanumeric characters except whitespaces.
     */
    private function sanitizeSearchQuery(string $query): string
    {
        return trim(preg_replace('/[[:space:]]+/', ' ', $query));
    }

    /**
     * Splits the search query into terms and removes the ones which are irrelevant.
     */
    private function extractSearchTerms(string $searchQuery): array
    {
        $terms = array_unique(explode(' ', $searchQuery));

        return array_filter($terms, function ($term) {
            return 2 <= mb_strlen($term);
        });
    }
}
