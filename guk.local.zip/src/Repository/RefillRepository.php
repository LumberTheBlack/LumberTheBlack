<?php

namespace App\Repository;

use App\Entity\Refill;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Refill|null find($id, $lockMode = null, $lockVersion = null)
 * @method Refill|null findOneBy(array $criteria, array $orderBy = null)
 * @method Refill[]    findAll()
 * @method Refill[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class RefillRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Refill::class);
    }

    public function findLatest()
    {
        return $this->createQueryBuilder('r')
            ->orderBy("r.createdAt","DESC")
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
            ;
    }

    public function findAllOrderedByCreatedAt()
    {
        return $this->createQueryBuilder('r')
            ->orderBy("r.createdAt","DESC");
    }
    public function findByOrderedByCreatedAt($value)
    {
        return  $this->createQueryBuilder('r')
                     ->leftJoin("r.cartridge","c")
                     ->leftJoin("r.employee","e")
                     ->where("LOWER(c.sn) LIKE LOWER(:val)")
                     ->orWhere("LOWER(e.fio) LIKE LOWER(:val)")
                     ->setParameter("val","%".$value."%")
                     ->orderBy("r.createdAt","DESC")
          ;
    }
    public function findAllGroupByMonth()
    {
        return $this->createQueryBuilder('r')
            ->Select('count(r.id) AS summary, date_format(r.createdAt,\'%Y.%m\') as createdYearMonth')
            ->groupBy('createdYearMonth')
            ->getQuery()
            ->getResult();
    }
    public function findAllGroupByOwner()
    {
        return $this->createQueryBuilder('r')
            ->leftJoin('r.employee','e')
            ->Select('count(r.id) AS summary,SUBSTRING_INDEX(e.fio,\' \',1) AS Employee')
            ->groupBy('e.id')
            ->getQuery()
            ->getResult();
    }

    public function findAllGroupByDepartment()
    {
        return $this->createQueryBuilder('r')
            ->leftJoin('r.employee','e')
            ->leftJoin('e.position','p')
            ->leftJoin('p.department','d')
            ->Select('count(r.id) AS summary,SUBSTRING_INDEX(d.name,\' \',3) AS Department')
            ->groupBy('d.id')
            ->getQuery()
            ->getResult();
    }

    // /**
    //  * @return Refill[] Returns an array of Refill objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('r')
            ->andWhere('r.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('r.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Refill
    {
        return $this->createQueryBuilder('r')
            ->andWhere('r.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
