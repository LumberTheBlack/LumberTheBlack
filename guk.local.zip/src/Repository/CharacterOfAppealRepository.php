<?php

namespace App\Repository;

use App\Entity\CharacterOfAppeal;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method CharacterOfAppeal|null find($id, $lockMode = null, $lockVersion = null)
 * @method CharacterOfAppeal|null findOneBy(array $criteria, array $orderBy = null)
 * @method CharacterOfAppeal[]    findAll()
 * @method CharacterOfAppeal[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class CharacterOfAppealRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CharacterOfAppeal::class);
    }

    // /**
    //  * @return CharacterOfAppeal[] Returns an array of CharacterOfAppeal objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('c.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?CharacterOfAppeal
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
