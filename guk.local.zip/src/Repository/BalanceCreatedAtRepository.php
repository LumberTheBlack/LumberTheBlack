<?php

namespace App\Repository;

use App\Entity\BalanceCreatedAt;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method BalanceCreatedAt|null find($id, $lockMode = null, $lockVersion = null)
 * @method BalanceCreatedAt|null findOneBy(array $criteria, array $orderBy = null)
 * @method BalanceCreatedAt[]    findAll()
 * @method BalanceCreatedAt[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class BalanceCreatedAtRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, BalanceCreatedAt::class);
    }

    // /**
    //  * @return BalanceCreatedAt[] Returns an array of BalanceCreatedAt objects
    //  */
    public function getLastUpdate()
    {
        return $this->createQueryBuilder('b')
            ->Select('max(b.createdAt)')
            ->getQuery()
            ->getSingleScalarResult()
        ;
    }

    /*
    public function findOneBySomeField($value): ?BalanceCreatedAt
    {
        return $this->createQueryBuilder('b')
            ->andWhere('b.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
