<?php

namespace App\Repository;

use App\Entity\ExecutionTime;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method ExecutionTime|null find($id, $lockMode = null, $lockVersion = null)
 * @method ExecutionTime|null findOneBy(array $criteria, array $orderBy = null)
 * @method ExecutionTime[]    findAll()
 * @method ExecutionTime[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ExecutionTimeRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, ExecutionTime::class);
    }

    // /**
    //  * @return ExecutionTime[] Returns an array of ExecutionTime objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('e')
            ->andWhere('e.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('e.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?ExecutionTime
    {
        return $this->createQueryBuilder('e')
            ->andWhere('e.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
