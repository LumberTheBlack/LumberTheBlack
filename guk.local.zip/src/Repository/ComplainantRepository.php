<?php

namespace App\Repository;

use App\Entity\Complainant;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Complainant|null find($id, $lockMode = null, $lockVersion = null)
 * @method Complainant|null findOneBy(array $criteria, array $orderBy = null)
 * @method Complainant[]    findAll()
 * @method Complainant[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ComplainantRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Complainant::class);
    }

    public function findAllOrderByFio($individual=1)
    {
        return $this->createQueryBuilder('c')
            ->leftJoin('c.type','cType')
            ->addSelect('cType')
            ->andWhere('cType.id=:complainantType')
            ->setParameter('complainantType',($individual==1?1:2))
            ->orderBy('c.fio','ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult();
    }

    public function findByFio($value, $individual=1)
    {
        return $this->createQueryBuilder('c')
            ->leftJoin('c.type','cType')
            ->addSelect('cType')
            ->andWhere('cType.id=:complainantType')
            ->andWhere('lower(c.fio) LIKE lower(:val)')
            ->setParameter('val','%'.$value.'%')
            ->setParameter('complainantType',($individual==1?1:2))
            ->orderBy('c.fio','ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult();
    }
    public function RecordExists2($fio,$address)
    {
        $rawQuery="SELECT * FROM complainant WHERE lower(fio) LIKE lower(:val) AND address_id=:address";
        $statement=$this->getEntityManager()->getConnection()->prepare($rawQuery);
        $statement->bindValue('val',$fio);
        $statement->bindValue('address',$address);
        $statement->execute();
        return $statement->fetchAll();
    }
    public function RecordExists(Complainant $complainant)
    {
        $rawQuery="SELECT * FROM complainant WHERE lower(fio) LIKE lower(:val) AND address_id=:address";
        $statement=$this->getEntityManager()->getConnection()->prepare($rawQuery);
        $statement->bindValue('val',$complainant->getFio());
        $statement->bindValue('address',$complainant->getAddress()->getId());
        $statement->execute();
        return $statement->fetchAll();

        return $this->createQueryBuilder('c')
            ->andWhere("lower(c.fio) LIKE :fio")
            ->andWhere("c.address=:address")
            ->setParameter("fio",strtolower($complainant->getFio()))
            ->setParameter("address",$complainant->getAddress()->getId())
            ->setMaxResults(2)
            ->getQuery()
            ->getResult();
    }
    public function findWith($q=null){
       if($q==null) 
        return $this->createQueryBuilder('c')
                    ->orderBy("c.fio","ASC")
       ;
       return $this->createQueryBuilder('c')
                   ->where("LOWER(c.fio) LIKE LOWER(:val)")
                   ->setParameter("val","%".$q."%")
                   ->orderBy("c.fio","ASC")
       ;  
    }
    // /**
    //  * @return Individual[] Returns an array of Individual objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('i')
            ->andWhere('i.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('i.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Individual
    {
        return $this->createQueryBuilder('i')
            ->andWhere('i.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
