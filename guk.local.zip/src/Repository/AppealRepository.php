<?php

namespace App\Repository;

use App\Entity\Answer;
use App\Entity\Appeal;
use App\Entity\FileReference;
use App\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\Query\Expr;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Appeal|null find($id, $lockMode = null, $lockVersion = null)
 * @method Appeal|null findOneBy(array $criteria, array $orderBy = null)
 * @method Appeal[]    findAll()
 * @method Appeal[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class AppealRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Appeal::class);
    }

    public function prepareQueryBuilder(?string $alias='a')
    {
        return $this->createQueryBuilder($alias)
            ->leftJoin(Answer::class,"answer",Expr\Join::WITH,$alias.'=answer.appeal')
            ->leftJoin(FileReference::class,'file',Expr\Join::WITH,$alias.'=file.appeal')
            ->Select($alias.' as appeal,count(DISTINCT(file.id)) as filesCount,count(DISTINCT(answer.id)) as answersCount,case when answer.approveAt IS NOT NULL then min(answer.createdAt) else NULLIF(1,1) end as answerDate, count(answer.returnAt) as returnedAnswer')
            ->groupBy($alias)
            ->orderBy($alias.'.DataIn','DESC');
    }
    public function findAllOrderByDataIn()
    {
        return $this->prepareQueryBuilder();
    }

    public function findRecordsWithoutReply($withoutReply=true, User $user=null)
    {
        $qb=$this->createQueryBuilder('a')
            ->leftJoin(Answer::class,"answer",Expr\Join::WITH,'a=answer.appeal')
            ->leftJoin(FileReference::class,'file',Expr\Join::WITH,'a=file.appeal')
            ->Select('a as appeal,count(DISTINCT(file.id)) as filesCount,count(DISTINCT(answer.id)) as answersCount, count(answer.returnAt) as returnedAnswer');
        if($withoutReply){
            $qb->addSelect("NULLIF(1,1) as answerDate")
                ->andWhere('answer is NULL')
                ->orWhere('answer.approveAt IS NULL');
        }else {
            $qb->addSelect("min(answer.createdAt) as answerDate")
                ->andWhere('answer IS NOT NULL')
                ->andWhere('answer.approveAt IS NOT NULL');
        }
        if($user!=null)
            $qb->andWhere(':user MEMBER OF a.executors')
                ->setParameter('user',$user);
         return $qb->groupBy('a')
            ->orderBy('a.DataIn','DESC');
    }

    public function getTotalAppealsWithoutReplyCount(User $user=null)
    {
        $qb=$this->createQueryBuilder('a')
            ->leftJoin(Answer::class,'answer',Expr\Join::WITH,'a=answer.appeal')
            ->select('a as appeal,count(answer) as answersCount')
            ->Where('answer iS NULL')
            ->orWhere('answer.approveAt IS NULL');
        if($user!=null) $qb->andWhere(':user MEMBER OF a.executors')->setParameter('user',$user);
        $result=$qb->groupBy('a')->getQuery()->getResult();
        return count($result);
    }
    public function getTotalAppealsCount()
    {
        return $this->createQueryBuilder('a')
            ->select('count(a.id)')
            ->getQuery()
            ->getSingleScalarResult();
    }
    public function getTotalUserAppealsCount(User $user)
    {
        return $this->createQueryBuilder('a')
                ->select('count(a.id)')
                ->andWhere(':user MEMBER OF a.executors')
                ->setParameter('user',$user)
                ->getQuery()
                ->getSingleScalarResult();
    }

    public function findByExecutor($user,$allAppeal=false)
    {
        return $this->prepareQueryBuilder()
            ->andWhere(':user MEMBER OF a.executors')
            ->andWhere('answer.approveAt IS NULL')
            ->setParameter('user',$user)
            ;
    }
    public function findByExecutorAll($user)
    {
        return $this->prepareQueryBuilder()
            ->leftJoin('a.executors','u')
            ->andWhere('u.fio LIKE :user')
            ->setParameter('user','%'.$user.'%')
            ;
    }

    public function findByComplainant($condition)
    {
        return $this->prepareQueryBuilder()
            ->leftJoin('a.complainant','complainant')
            ->andWhere('LOWER(complainant.fio) LIKE LOWER(:condition)')
            ->setParameter('condition','%'.$condition.'%');
    }

    public function findByAddress($condition)
    {
        return $this->prepareQueryBuilder()
            ->leftJoin('a.complainant','complainant')
            ->leftJoin('complainant.address','address')
            ->leftJoin('address.owner','parent')
            ->andWhere('LOWER(address.name) LIKE :condition')
            ->orWhere('LOWER(parent.name) LIKE LOWER(:condition)')
            ->setParameter('condition','%'.$condition.'%');
    }

    public function findByNumber($condition)
    {
        return $this->prepareQueryBuilder()
            ->andWhere('LOWER(a.number) LIKE LOWER(:condition)')
            ->orWhere('a.id=:id')
            ->setParameter('id',$condition)
            ->setParameter('condition','%'.$condition.'%');
    }

    public function findWithoutExecutors()
    {
        return $this->prepareQueryBuilder()
            ->leftJoin('a.executors','executor')
            ->having('count(executor.id)=0');
    }

    public function getCountAppealsWithoutExecutors()
    {
        return count($this->findWithoutExecutors()->getQuery()->getResult());
    }

    public function getAppealsWithAnswerForApprove()
    {
        return $this->prepareQueryBuilder()
            ->andWhere('answer IS NOT NULL')
            ->andwhere('answer.approveAt IS NULL')
            ->andwhere('answer.returnAt IS NULL')
            ;
    }

    public function getAppealWithTermLess10Days()
    {
        return $this->prepareQueryBuilder()
            ->andWhere("DATE_DIFF(DATE_ADD(a.DataIn,a.executionTime,'day'),CURRENT_DATE())BETWEEN 0 AND 10")
            ->andWhere("answer.approveAt IS NULL");
    }

    public function getCountAppealsWithTermLess10Days()
    {
        return $this->createQueryBuilder('a')
            ->leftJoin(Answer::class,'answer',Expr\Join::WITH,'a=answer.appeal')
            ->select('count(a.id)')
            ->andWhere("DATE_DIFF(DATE_ADD(a.DataIn,a.executionTime,'day'),CURRENT_DATE())BETWEEN 0 AND 10")
            ->andWhere("answer.approveAt IS NULL")
            ->getQuery()
            ->getSingleScalarResult();
    }
    public function findByPeriod($year)
    {
         if($year==NULL)$year=date('Y');
         return $this->createQueryBuilder('a')
                     ->leftJoin(Answer::class,'answer',Expr\Join::WITH,'a=answer.appeal')
                     ->leftJoin('a.complainant','complainant')
                     ->Select('a AS appeal,ifelse(min(answer.approveAt) IS NULL,0,1) AS executed')
                     ->andWhere('a.DataIn BETWEEN :start AND :end')
                     ->setParameter('start',new \DateTime('first day of January '.$year))
                     ->setParameter('end', new \DateTime('last day of December '.$year)) 
                     ->groupBy('a.id')
                     ->getQuery()
                     ->getResult() 
         ; 
    }
    public function findAllGroupByMonth()
    {
        return $this->createQueryBuilder('a')
            ->Select('count(a.id) AS summary, date_format(a.createdAt,\'%Y.%m\') as createdYearMonth')
            ->groupBy('createdYearMonth')
            ->getQuery()
            ->getResult();
    }
    public function findAllGroupByExecutor()
    {
        return $this->createQueryBuilder('a')
            ->leftJoin('a.executors','u')
            ->Select('count(a.id) AS summary, SUBSTRING_INDEX(u.fio,\' \',1) AS executor')
            ->Where('u IS NOT NULL')  
            ->groupBy('u.id')
            ->orderBy('summary','DESC')
            ->getQuery()
            ->getResult();
    }
    public function getAppealStats(){
       return $this->createQueryBuilder('a')
              ->leftJoin(Answer::class,'answer',Expr\Join::WITH,'a=answer.appeal')
              ->leftJoin('a.executors','u')
              ->Select('u.id as id, SUBSTRING_INDEX(u.fio,\' \',1) as executor,count(DISTINCT(a.id)) as appealCount')
              ->where('answer.approveAt IS NULL')
              ->andWhere('u IS NOT NULL')
              ->groupBy('u.id') 
              ->orderBy('executor','ASC')
              ->getQuery()
              ->getResult()  
       ;
    }
    public function getAnswerTermIsUpAppealStats(){
         $sql="SELECT data.executor,count((data.appeal_id)) as termIsUpAppealCount FROM( 
                    SELECT 
                      u.id as user_id,
                      SUBSTRING_INDEX(u.fio,' ',1) as executor,
                      a.id as appeal_id,
                      a.Data_In as created_at,
                      answer.approve_at as approve_at ,
                      STR_TO_DATE(DATE_FORMAT(DATE_ADD(a.Data_In,INTERVAL a.execution_Time DAY),'%Y-%m-%d 23:59:59'),'%Y-%m-%d %H:%i:%s') as term,
                      MIN(answer.created_At) as min_answer_date 
                    FROM appeal a 
                     LEFT JOIN answer ON a.id=answer.appeal_id 
                     LEFT JOIN appeal_user au ON a.id=au.appeal_id
                     LEFT JOIN user u ON au.user_id=u.id
                    GROUP BY u.id,a.id) data
                 WHERE data.created_at>'".date('Y-m-d 00:00:00',strtotime('-3 month'))."' AND (
                     data.term<data.min_answer_date OR (data.approve_at IS NULL AND data.term<CURRENT_DATE())
                 ) 
                 GROUP BY user_id
                 ORDER BY termIsUpAppealCount DESC, executor ASC
               ";                
         $conn=$this->getEntityManager()->getConnection();
         $stmt=$conn->prepare($sql);
         $stmt->execute();
         //dd($stmt->fetchAll());    
         return $stmt->fetchAll();  
         
    }  
    // /**
    //  * @return Appeal[] Returns an array of Appeal objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('a')
            ->andWhere('a.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('a.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Appeal
    {
        return $this->createQueryBuilder('a')
            ->andWhere('a.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
