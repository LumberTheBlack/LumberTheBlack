<?php

namespace App\Form;

use App\Entity\Nomenclature;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class NomenclatureFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('indexDoc',null,[
                'label'=>false,
                'attr'=>['placeholder'=>'nomenclature.indexDoc',]
            ])
            ->add('name',null,[
                    'label'=>false,
                    'attr'=>[
                        'placeholder'=>'nomenclature.name',
                        'rows'=>10
                    ]
                ]
            )
            ->add('term',null,[
                'label'=>false,
                'attr'=>[
                    'placeholder'=>'nomenclature.term',
                    'rows'=>10
                ]
            ])
            ->add('note',null,[
                'label'=>false,
                'attr'=>[
                    'placeholder'=>'nomenclature.note',
                    'rows'=>10
                ]
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Nomenclature::class,
        ]);
    }
}
