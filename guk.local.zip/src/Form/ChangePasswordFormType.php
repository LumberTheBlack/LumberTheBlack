<?php

namespace App\Form;

use App\Validator\MatchesPassword;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class ChangePasswordFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
              ->add('plainOldPassword', PasswordType::class, [
                'mapped' => false,
                'required' => false,
                'constraints' => [new MatchesPassword()]
              ])
              ->add('plainPassword',RepeatedType::class,[
                'type' => PasswordType::class,
                'label'=>false,
                'mapped'=>false, // не привязывать поле формы к свойству User->Password, для шифрования в контроллере
                // после Post
                'attr'=>[
                    'placeholder'=>'Password'
                ], // вариант ограничений на поле установленных прямо в классе формы
                'constraints'=>[
                    new NotBlank([
                        'message'=>'Choose a password'
                    ]),
                    new Length([
                        'min'=> 8,
                        'minMessage'=>'Too small password (min = 8 symbols)'
                    ])
                ]
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            // Configure your form options here
            'notResetPassword'=>true,
        ]);
    }
}
