<?php

namespace App\Form;

use App\Entity\Contract;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use App\Form\Type\DateTimePickerInput;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;


class ContractFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('sideType',null, [
                'help' => 'contract.sideType_help',
                'label' => 'contract.sideType',
            ])
            ->add('number',null, [
                'help' => 'contract.number_help',
                'label' => 'contract.number',
            ])
            ->add('dDate', DateTimePickerInput::class, [
                'label' => 'contract.dDate',
                'help' => 'contract.dDate_help',

            ])
            ->add('subject', TextareaType::class, [
                'help' => 'contract.subject_help',
                'label' => 'contract.subject',
            ])
            ->add('summa',null, [
                'help' => 'contract.summa_help',
                'label' => 'contract.summa',
            ])
            ->add('contragent',null, [
                'help' => 'contract.contragent_help',
                'label' => 'contract.contragent',
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Contract::class,
        ]);
    }
}
