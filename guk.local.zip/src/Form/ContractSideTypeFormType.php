<?php

namespace App\Form;

use App\Entity\ContractSideType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class ContractSideTypeFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name',null,[
                'label'=>false,
                'attr'=>[
                   'placeholder'=>'contract.sideType_help'
                ],
                'constraints' => [
                    new NotBlank(),
                    new Length(['min' => 3]),
               ]
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => ContractSideType::class,
        ]);
    }
}
