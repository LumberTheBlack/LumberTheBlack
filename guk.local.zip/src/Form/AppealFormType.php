<?php

namespace App\Form;

use App\Entity\Appeal;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AppealFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('complainant',null,[
                'attr'=>[
                    'readOnly'=>true,
                    'disabled'=>true
                ]
            ])
            ->add('DataIn')
            ->add('number')
            ->add('typeOfAppeal')
            ->add('characterOfAppeal')
            ->add('formOfAppeal')
            ->add('nomenclature')
            ->add('content',TextareaType::class,[
                'attr'=>[
                    'rows'=>10
                ]
            ])
            ->add('executionTime')
        ;
        if(!$options['individual']) {
            $builder
                ->add('DateDoc', null, [
                    'label'=>'appeal.DateDoc'
                ])
                ->add('initialNumber', null, [
                    'label'=>'appeal.initialNumber'
                ]);
        }
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Appeal::class,
            'individual'=>false
        ]);
    }
}
