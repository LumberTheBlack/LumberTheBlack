<?php

namespace App\Form;

use App\Entity\Complainant;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class ComplainantFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('fio',null,[
               'label'=>'complainant.fio',
               'constraints' => [
                    new NotBlank(),
                    new Length(['min' => 3]),
               ]
            ])
            ->add('address',null,[
               'label'=>'complainant.address',
               "disabled"=>true 
            ])
            ->add('type',null,[
              'label'=>'complainant.type',
              "disabled"=>true 
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Complainant::class,
        ]);
    }
}
