<?php

namespace App\Form;

use App\Entity\Act;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use App\Form\Type\DateTimePickerInput;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;


class ActFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('contragent',null,[ 
                'label' => 'act.contragent',
                 'help' => 'act.contragent_help',
                'required' => true,
              ])
            ->add('number',null,[ 
                'label' => 'act.number',
                 'help' => 'act.number_help',
                'required' => true,
              ])
            ->add('createdAt', DateTimePickerInput::class, [
                'label' => 'act.createdAt',
                 'help' => 'act.createdAt_help',
            ])
            ->add('subject', TextareaType::class, [
                'help' => 'act.subject_help',
                'label' => 'act.subject',
            ])


        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Act::class,
        ]);
    }
}
