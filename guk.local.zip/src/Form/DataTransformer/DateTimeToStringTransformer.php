<?php
/**
 * Created by PhpStorm.
 * User: udin
 * Date: 21.04.2020
 * Time: 14:21
 */

namespace App\Form\DataTransformer;


use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\Exception\TransformationFailedException;

class DateTimeToStringTransformer implements DataTransformerInterface
{
    /**
     * @param \DateTimeInterface $dateTimeValue
     */
    public function transform($dateTimeValue)
    {
       if(null === $dateTimeValue)
           return;
       if(!$dateTimeValue instanceof \DateTime && !$dateTimeValue instanceof \DateTimeInterface)
           throw new TransformationFailedException('Expected \\DateTime or \\DateTimeInterface');
       return $dateTimeValue->format("d.m.Y H:i:s");
    }

    public function reverseTransform($value)
    {
        // TODO: Implement reverseTransform() method.
        if(''===$value || null===$value)
            return new \DateTime();
        return date_create_from_format('d.m.Y H:i:s',$value);
    }
}