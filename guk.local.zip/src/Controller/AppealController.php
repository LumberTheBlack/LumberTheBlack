<?php

namespace App\Controller;

use App\Entity\Appeal;
use App\Repository\AnswerRepository;
use App\Repository\AppealRepository;
use App\Repository\FileReferenceRepository;
use App\Repository\LegalRepository;
use App\Repository\UserRepository;
use Knp\Component\Pager\Pagination\PaginationInterface;
use Knp\Component\Pager\Paginator;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpFoundation\HeaderUtils;


class AppealController extends AbstractController
{
    /**
     * @Route("/appeal", name="app_appeal")
     */
    public function index(Request $request,AppealRepository $repository,AnswerRepository $answerRepository,UserRepository $userRepository, PaginatorInterface $paginator)
    {
        //dd($repository->getAppealStats());
         // dd($repository->getAnswerTermIsUpAppealStats());
       // dd($repository->getTotalAppealsWithoutReplyCount());
        $user=$this->isGranted('ROLE_USER') && !$this->isGranted("ROLE_MANAGER") && !$this->isGranted("ROLE_ADMIN")?$this->getUser():null;
        if($request->query->has('noReply')){
            $qb=$repository->findRecordsWithoutReply(true,$user);
        }elseif ($request->query->has('withReply')) {
            $qb = $repository->findRecordsWithoutReply(false, $user);
        }elseif ($request->query->has('noExecutors')){
            $qb = $repository->findWithoutExecutors();
        }elseif($request->query->has('notApprovedAnswer')){
            $qb=$repository->getAppealsWithAnswerForApprove();
        }elseif($request->query->has('withTerm')){
            $qb=$repository->getAppealWithTermLess10Days();
        }elseif ($this->isGranted('ROLE_USER')&& !$this->isGranted("ROLE_MANAGER") && !$this->isGranted("ROLE_ADMIN") ){//|| $request->query->has('byUser')){
            $qb=$repository->findByExecutor($user);
        }elseif($request->query->has('byUser')){
            $qb=$repository->findByExecutor($userRepository->find($request->query->get('byUser')));
        }
        else
            $qb=$repository->findAllOrderByDataIn();
        //dd($qb->getQuery()->getResult());
        $appeals=$paginator->paginate(
            $qb,
            $request->query->get('page',1),
            10,
            ['wrap-queries'=>true]
        );
        $appealsWithoutReplyCount=$repository->getTotalAppealsWithoutReplyCount($user);
        $userAppealsCount=0;
        if($this->isGranted("ROLE_USER"))
            $userAppealsCount=$repository->getTotalAppealsWithoutReplyCount($this->getUser());
        $totalAppealsCount=$user==null?$repository->getTotalAppealsCount():$userAppealsCount;
        $chartDataGroupByMonth=$repository->findAllGroupByMonth();
        $chartDataGroupByExecutor=$repository->findAllGroupByExecutor();
        $chartDataTermIsUpAppeal=$repository->getAnswerTermIsUpAppealStats();
        return $this->render('appeal/index.html.twig', [
            'appeals' => $appeals,
            'appealsWithoutReply'=>$appealsWithoutReplyCount,
            'appealsWithReply'=>$totalAppealsCount-$appealsWithoutReplyCount,
            'appealsWithoutExecutors'=>$repository->getCountAppealsWithoutExecutors(),
            'appealsWithAnswerForApprove'=>$answerRepository->getCountNotApproved(),
            'userAppeals'=>$userAppealsCount,
            'executorAppeals'=>$repository->getAppealStats(),//$userRepository->getAppealsStat(),
            'appealsWithTerm'=>$repository->getCountAppealsWithTermLess10Days(),
            'data_group_by_month_x'=>json_encode(array_column($chartDataGroupByMonth,"createdYearMonth")),
            'data_group_by_month_y'=>json_encode(array_column($chartDataGroupByMonth,"summary")),
            'data_group_by_executor_x'=>json_encode(array_column($chartDataGroupByExecutor,"executor")),
            'data_group_by_executor_y'=>json_encode(array_column($chartDataGroupByExecutor,"summary")),
            'data_term_is_up_x'=>json_encode(array_column($chartDataTermIsUpAppeal,"executor")),
            'data_term_is_up_y'=>json_encode(array_column($chartDataTermIsUpAppeal,"termIsUpAppealCount")),
        ]);
    }

    /**
     * @param Request $request
     * @param Appeal $appeal
     * @param FileReferenceRepository $fileReferenceRepository
     * @Route("/appeal/{id}/show", name="app_appeal_show")
     */
    public function show(Request $request, Appeal $appeal,AnswerRepository $answerRepository, FileReferenceRepository $fileReferenceRepository, LegalRepository $legalRepository)
    {
        return $this->render("appeal/show.html.twig",[
            "appeal"=>$appeal,
            "files"=>$fileReferenceRepository->findBy(["appeal"=>$appeal],["fileName"=>"ASC"]),
            "legal"=>$legalRepository->findBy(["complainant"=>$appeal->getComplainant()]),
            "answers"=>$answerRepository->findBy(["appeal"=>$appeal])
        ]);
    }

    /**
     * @param Request $request
     * @Route("/appeal/search", name="app_appeal_search")
     */
    public function search(Request $request, AppealRepository $repository, PaginatorInterface $paginator)
    {
        //dd($request);
        $condition=$request->query->get("condition");
        $searchBy=$request->query->get("searchBy",0);
        switch ($searchBy){
            case 0:
                $qb=$repository->findByComplainant($condition);
                break;
            case 1:
                $qb=$repository->findByAddress($condition);
                break;
            case 3:
                $qb=$repository->findByExecutorAll($condition);
                break;
            default:
                $qb=$repository->findByNumber($condition);
        }
        $appeals=$paginator->paginate($qb,$request->query->get("page",1));
        return $this->render('appeal/search.html.twig',[
            'condition'=>$condition,
            'appeals'=>$appeals
        ]);
    }

    /**
     * @param Request $request
     * @param AppealRepository $repository
     * @ROUTE("/appeal/noexecutors", name="app_appeal_noexecutors")
     */
    public function getAppealsWithoutExecutors(Request $request,AppealRepository $repository)
    {
        $appeals=$repository->findWithoutExecutors()->getQuery()->getResult();
        dd($appeals);
        return $this->json([]);
    }
    /**
     * @Route("/appeal/journal/download", name="app_appeal_journal_download")
     */
    public function getJournal(Request $request, AppealRepository $repository)
    {
        if($request->query->has('year')){
            $appeals=$repository->findByPeriod($request->query->get('year'));
            $spreadsheet=new \PhpOffice\PhpSpreadsheet\Spreadsheet;
         
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Pdf\Dompdf($spreadsheet);
            /*$writer->setUseBOM(true); //UTF-8
            $writer->setDelimiter(';');
            $writer->setEnclosure('"');
            $writer->setLineEnding("\r\n");
            */
            //$writer->setFont('DejaVuSans');
            $writer->setSheetIndex(0);
            $worksheet=$spreadsheet->getActiveSheet();
            $worksheet->setTitle("Журнал обращений граждан");

            $fontFamily="DejaVu Sans"; 
            $headerStyle = [
                'font' => [
                    'bold' => true,
                    'name' => $fontFamily
                ],
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                            ],
                'borders' => [
                    'top' => [
                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                    ],
                ],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_GRADIENT_LINEAR,
                    'rotation' => 90,
                    'startColor' => [
                        'argb' => 'FFA0A0A0',
                    ],
                    'endColor' => [
                        'argb' => 'FFFFFFFF',
                    ],
                ],
            ];
            $cellStyle = [
                'font' => [
                    'bold' => false,
                    'name' => $fontFamily,
                    'size' => 8
                ],
                'alignment'=>[
                     'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
                ]
            ];
            $cellHCenteredStyle = [
                'alignment'=>[
                     'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER, 
                ],
            ];
            $worksheet->getStyle("A1:F1")->applyFromArray($headerStyle); 
            $worksheet
                ->setCellValue("A1", "Дата")
                ->setCellValue("B1", "Вх. №")
                ->setCellValue("C1", "Заявитель")
                ->setCellValue("D1", "Состав")
                ->setCellValue("E1", "Исполнители")
                ->setCellValue("F1", "Отметка о выполнении");
            $worksheet->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(1, 1);
            $row = 2;
            foreach ($appeals as $appeal) {
                $a=$appeal["appeal"];
                $worksheet->getStyle("A{$row}:F{$row}")->applyFromArray($cellStyle); 
                $worksheet->getStyle("F{$row}")->applyFromArray($cellHCenteredStyle); 
                $worksheet
                    ->setCellValue("A{$row}", $a->getDataIn()->format("d.m.Y"))
                    ->setCellValue("B{$row}", $a->getNumber())
                    ->setCellValue("C{$row}", $a->getComplainant()."(".$a->getComplainant()->getAddress().")")
                    ->setCellValue("D{$row}", $a->getContent())
                    ->setCellValue("E{$row}", implode(",",$a->getExecutors()->toArray()))
                    ->setCellValue("F{$row}", $appeal["executed"]?"Выполнено":"-")
                ;
                $row++;
            }
            $response=new StreamedResponse();
            $response->setCallback(function() use ($writer){
               $writer->save('php://output');
            });
            $response->headers->set('Content-Type', 'application/pdf');
            $disposition = HeaderUtils::makeDisposition(
                HeaderUtils::DISPOSITION_ATTACHMENT,
                'journal.pdf'
            );
            $response->headers->set('Content-Disposition', $disposition);

         
            return $response; 
        }
        return $this->render('appeal/journal.html.twig',[]);
    }
}

