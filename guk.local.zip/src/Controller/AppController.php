<?php

namespace App\Controller;

use App\Repository\PostRepository;
use App\Repository\TagRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class AppController extends AbstractController
{
    /**
     * @Route("/", name="homepage")
     */
    public function index(PostRepository $postRepository,TagRepository $tagRepository)
    {
        $Jumbotron=$tagRepository->findOneBy(["slug"=>"jumbotron"]);
        $posts=[];
        if($Jumbotron)$posts=$postRepository->findLatest($Jumbotron)->getQuery()->getResult();
        return $this->render('app/index.html.twig', [
            'jumbotrons' => $posts,
        ]);
    }
}
