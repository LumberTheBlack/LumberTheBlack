<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Knp\Component\Pager\PaginatorInterface;
use App\Entity\Act;
use App\Repository\ActRepository;
use App\Repository\FileReferenceRepository;


    /**
     * @Route("/act")
     */

class ActController extends AbstractController
{
    /**
     * @Route("/", name="act")
     */
    public function index(Request $request,ActRepository $actRepository, PaginatorInterface $paginator)
    {
        $acts=$paginator->paginate(
            $actRepository->findAllOrderedByCreatedAt($request->query->get("q",null)),
            $request->query->get('page',1),
            10
        );

        return $this->render('act/index.html.twig', [
            'acts' => $acts,
        ]);
    }
    /**
     * @Route("/show/{id}", name="act_show")
     */ 
     public function show(Act $act, FileReferenceRepository $fr)
     {
        return $this->render("act/show.html.twig",[
            "act"=>$act,
        ]);
     }
}
