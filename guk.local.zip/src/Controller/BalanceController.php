<?php

namespace App\Controller;

use App\Entity\Building;
use App\Repository\BalanceCreatedAtRepository;
use App\Repository\BalanceRepository;
use App\Repository\BuildingRepository;
use App\Repository\PersonalAccountRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class BalanceController extends AbstractController
{
    /**
     * @param Request $request
     * @param Building $building
     * @param PersonalAccountRepository $accountRepository
     * @Route("/api/balance/{id}/get", name="app_balance_get")
     */
    public function getBalance(Request $request,Building $building, BalanceRepository $balanceRepository)
    {
        return $this->json([
           "balance"=>$balanceRepository->findByBuilding($building)
        ]);
    }
    /**
     * @Route("/balance", name="balance")
     */
    public function index(Request $request, BuildingRepository $buildingRepository, BalanceCreatedAtRepository $balanceCreatedAtRepository)
    {
        if($request->query->has('query')){
            $buildings=$buildingRepository->findAllMatching($request->query->get("query"));
            return $this->json([
                "buildings"=>$buildings
            ]);
        }
        return $this->render('balance/index.html.twig', [
            'lastUpdated'=>$balanceCreatedAtRepository->getLastUpdate()
        ]);
    }


}
