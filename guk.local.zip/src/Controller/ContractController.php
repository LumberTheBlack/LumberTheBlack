<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Knp\Component\Pager\PaginatorInterface;
use App\Entity\Contract;
use App\Repository\ContractRepository;
use App\Repository\FileReferenceRepository;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpFoundation\HeaderUtils;

/**
 * @Route("/contract")
 */

class ContractController extends AbstractController
{
    /**
     * @Route("/", name="contract")
     */
    public function index(Request $request,ContractRepository $contractRepository, PaginatorInterface $paginator)
    {
        $contracts=$paginator->paginate(
            $contractRepository->findAllOrderedByDDate($request->query->get("q",null)),
            $request->query->get('page',1),
            10
        );

        return $this->render('contract/index.html.twig', [
            'contracts' => $contracts,
        ]);
    }
    /**
     * @Route("/show/{id}", name="contract_show")
     */ 
     public function show(Contract $contract, FileReferenceRepository $fr)
     {
        return $this->render("contract/show.html.twig",[
            "contract"=>$contract,
            "files"=>$fr->findBy(["contract"=>$contract],["fileName"=>"ASC"])
        ]);
     }
    /**
     * @Route("/contract/journal/download", name="app_contract_journal_download")
     */
     public function getJournal(Request $request, ContractRepository $repository)
     {
            $contracts=$repository->findAllOrderedByDDate()->getQuery()->getResult();
            $spreadsheet=new \PhpOffice\PhpSpreadsheet\Spreadsheet;
         
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            /*$writer->setUseBOM(true); //UTF-8
            $writer->setDelimiter(';');
            $writer->setEnclosure('"');
            $writer->setLineEnding("\r\n");
            */
            //$writer->setFont('DejaVuSans');
            //$writer->setSheetIndex(0);
            $worksheet=$spreadsheet->getActiveSheet();
            $worksheet->setTitle("Реестр договоров");

            $fontFamily="DejaVu Sans"; 
            $headerStyle = [
                'font' => [
                    'bold' => true,
                    'name' => $fontFamily
                ],
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                            ],
                'borders' => [
                    'top' => [
                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                    ],
                ],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_GRADIENT_LINEAR,
                    'rotation' => 90,
                    'startColor' => [
                        'argb' => 'FFA0A0A0',
                    ],
                    'endColor' => [
                        'argb' => 'FFFFFFFF',
                    ],
                ],
            ];
            $cellStyle = [
                'font' => [
                    'bold' => false,
                    'name' => $fontFamily,
                    'size' => 8
                ],
                'alignment'=>[
                     'vertical' =>  \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
                ]
            ];
            $cellHCenteredStyle = [
                'alignment'=>[
                     'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER, 
                ],
            ];
            $worksheet->getStyle("A1:F1")->applyFromArray($headerStyle); 
            $worksheet
                ->setCellValue("A1", "#")
                ->setCellValue("B1", "Номер договора")
                ->setCellValue("C1", "Дата заключения")
                ->setCellValue("D1", "Предмет")
                ->setCellValue("E1", "Сумма,руб.")
                ->setCellValue("F1", "Контрагент");
            $worksheet->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(1, 1);
            $row = 2;
            foreach ($contracts as $contract) {
                $worksheet->getStyle("A{$row}:F{$row}")->applyFromArray($cellStyle); 
                $worksheet->getStyle("F{$row}")->applyFromArray($cellHCenteredStyle); 
                $worksheet
                    ->setCellValue("A{$row}", $contract->getId())
                    ->setCellValue("B{$row}", $contract->getNumber())
                    ->setCellValue("C{$row}", $contract->getDDate()->format("d.m.Y"))
                    ->setCellValue("D{$row}", $contract->getSubject())
                    ->setCellValue("E{$row}", $contract->getSumma())
                    ->setCellValue("F{$row}", $contract->getContragent())
                ;
                $row++;
            }
            foreach(range('A','F') as $columnID) {
                $spreadsheet->getActiveSheet()->getColumnDimension($columnID)
                   ->setAutoSize(true);
            }

            $response=new StreamedResponse();
            $response->setCallback(function() use ($writer){
               $writer->save('php://output');
            });
            $response->headers->set('Content-Type', 'application/vnd.ms-excel');
            $disposition = HeaderUtils::makeDisposition(
                HeaderUtils::DISPOSITION_ATTACHMENT,
                'contractRegister.xlsx'
            );
            $response->headers->set('Content-Disposition', $disposition);

         
            return $response; 
     }
}
