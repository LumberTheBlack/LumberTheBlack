<?php

namespace App\Controller\Admin;

use App\Entity\AddressObject;
use App\Repository\AddressObjectRepository;
use App\Repository\ResidenceRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class AddressObjectController extends AbstractController
{
    /**
     * @Route("/admin/address/object", name="admin_address_object")
     */
    public function index()
    {
        return $this->render('admin/address_object/index.html.twig', [
            'controller_name' => 'AddressObjectController',
        ]);
    }
    /**
     * @Route("/admin/address_objects/select/{key}", name="admin_address_objects_select")
     * level:
     * 1 - регион
     * 2 - зарезервирован
     * 3 - район
     * 4 - город
     * 5 - внутригородская территория
     * 6 - населенный пункт
     * 7 - улицы
     * 8 - зарезервирован
     * 90 - дополнительная территория (ГСК, СНТ, лагери отдыха и т.п.)
     * 91 - улицы на дополнительной территории (улицы, линии, проезды)
     */
    public function select(Request $request, $key, AddressObjectRepository $addressObjectRepository)
    {
        $level=$request->query->get('level');
        $parent=$request->query->get('parent');
        $addressObjects=$addressObjectRepository->findByFormalName($key,$level,$parent);
        return $this->json(['address_objects'=>$addressObjects],200);
    }

    /**
     * @param Request $request
     * @param AddressObjectRepository $repository
     * @ROUTE("/admin/address_objects/get/{guid}", name="admin_address_objects_get")
     */
    public function getAddressObjectByGuid(Request $request, $guid, AddressObjectRepository $repository)
    {
        return $this->json(['address_object'=>$repository->findOneBy(["guid"=>$guid])],200);
    }
    /**
     * @Route("/admin/address_object/residence/select/{residence}/{parent}/{level}", name="admin_address_object_resodence_select")
     */
    public function selectResidence(Request $request,$residence,$parent,$level,EntityManagerInterface $manager,ResidenceRepository $repository, AddressObjectRepository $addressObjectRepository)
    {
        $rawQuery="SELECT * FROM residence WHERE residence.name LIKE :val AND parent_id=:parent";
        if($level!=0)
            $rawQuery="SELECT * FROM residence WHERE owner_id=:parent AND name LIKE :val";
        $statement=$manager->getConnection()->prepare($rawQuery);
        $statement->bindValue('parent',$parent);
        $statement->bindValue('val',$residence);
        $statement->execute();
        $result=$statement->fetchAll();
        return $this->json([
            "residence"=>$result
        ]);
    }
}
