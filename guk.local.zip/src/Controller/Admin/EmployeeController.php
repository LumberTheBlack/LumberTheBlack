<?php

namespace App\Controller\Admin;

use App\Entity\Employee;
use App\Repository\EmployeeRepository;
use App\Repository\PositionRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Normalizer\AbstractNormalizer;
use Symfony\Component\Serializer\SerializerInterface;

class EmployeeController extends AbstractController
{
    /**
     * @Route("/admin/employee", name="admin_employee")
     */
    public function index()
    {
        return $this->render('admin/employee/index.html.twig', [
        ]);
    }

    /**
     * @param Request $request
     * @param EntityManagerInterface $manager
     * @Route("/admin/employee/get/{search}", name="admin_employee_get")
     */
    public function getEmployees(Request $request, $search=null, EntityManagerInterface $manager, EmployeeRepository $employeeRepository)
    {
        if($search!=null) return $this->json(["employees"=>$employeeRepository->findBy(["fio"=>$search])]);
        return $this->json(['employees'=>$employeeRepository->findAll()]);
    }

    /**
     * @param Employee $employee
     * @param EntityManagerInterface $manager
     * @Route("/admin/employee/{id}/delete", methods={"DELETE"}, name="admin_employee_delete")
     */
    public function deleteEmployee(Employee $employee, EntityManagerInterface $manager)
    {
        $manager->remove($employee);
        $manager->flush();

        return new Response(null,Response::HTTP_NO_CONTENT);
    }

    /**
     * @param Request $request
     * @param Employee|null $employee
     * @param EntityManagerInterface $manager
     * @param SerializerInterface $serializer
     * @param EmployeeRepository $employeeRepository
     * @param PositionRepository $positionRepository
     * @Route("/admin/employee/save/{id}", methods="POST", name="admin_employee_save")
     */
    public function saveEmployee(Request $request, Employee $employee=null, EntityManagerInterface $manager,
                                 SerializerInterface $serializer, EmployeeRepository $employeeRepository, PositionRepository $positionRepository)
    {
        $decodedData=json_decode($request->getContent());
       if($employee==null) {
           if(count($employeeRepository->findBy(["fio"=>$decodedData->fio,"position"=>$decodedData->position->id]))>0)
              return $this->json([],Response::HTTP_FOUND);
           $employee=new Employee();
       }

       $serializer->deserialize(
           $request->getContent(),
           Employee::class,
           'json',
           [AbstractNormalizer::OBJECT_TO_POPULATE=>$employee]
       );
       $employee->setPosition($positionRepository->find($decodedData->position->id));
       $manager->persist($employee);
       $manager->flush();

       return $this->json(["employee"=>$employee]);
    }
}
