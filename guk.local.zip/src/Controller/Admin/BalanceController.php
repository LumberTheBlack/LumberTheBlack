<?php

namespace App\Controller\Admin;

use App\Entity\Balance;
use App\Entity\BalanceCreatedAt;
use App\Form\UploadPaymentDocumentFormType;
use App\Repository\BalanceRepository;
use App\Repository\PersonalAccountRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class BalanceController
 * @package App\Controller\Admin
 * @IsGranted("ROLE_ADMIN")
 */

class BalanceController extends AbstractController
{
    /**
     * @Route("/admin/balance/import", name="admin_balance_import")
     */
    public function ImportPaymentDocument(Request $request, PersonalAccountRepository $par, BalanceRepository $balanceRepository)
    {
        $form = $this->createForm(UploadPaymentDocumentFormType::class);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            /**
             * @var UploadedFile $file
             */
            $file = $form['UploadedPaymentDocument']->getData();

            if ($file) {
                $originalFilename = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
                // this is needed to safely include the file name as part of the URL
                $safeFilename = transliterator_transliterate('Any-Latin; Latin-ASCII; [^A-Za-z0-9_] remove; Lower()', $originalFilename);
                $newFilename = $safeFilename . '-' . uniqid() . '.' . ($file->guessExtension()?$file->guessExtension():$file->getClientOriginalExtension());

                // Move the file to the directory where brochures are stored
                try {
                    $now = new \DateTime();
                    $upload_dir=$this->getParameter('uploads_dir_name') . DIRECTORY_SEPARATOR . "paymentdocs" . DIRECTORY_SEPARATOR . $now->format('Y') . DIRECTORY_SEPARATOR . $now->format("m");
                    $file->move(
                        $upload_dir,
                        $newFilename
                    );
                } catch (FileException $e) {
                    $this->addFlash("error",'Balance were NOT loaded successfully /'.$e->getMessage());
                    return $this->render("admin/balance/import.html.twig", [
                        "form" => $form->createView(),
                    ]);
                }
                $balanceRepository->truncateSelf();
                $em=$this->getDoctrine()->getManager();
                $import_data = simplexml_load_file($upload_dir.DIRECTORY_SEPARATOR.$newFilename);
                $import_date = new \DateTime($import_data->attributes()->filedate);
                foreach ($import_data->PersAcc as $pa) {
                    $personalAccount=$par->findOneBy(["pid"=>$pa->attributes()->name_ls]);
                    if(null == $personalAccount) continue;
                    $balance=new Balance();
                    $balance->setPersonalAccount($personalAccount);
                    $balance->setSaldo($this->normalizeDecimal($pa->attributes()->debtend));
                    $em->persist($balance);
                    $em->flush();
                    $em->clear();
                }//for personalAcount string
                $balanceCreatedAt= new BalanceCreatedAt();
                $em->persist($balanceCreatedAt);
                $em->flush();
                $this->addFlash("success",'balance.loaded');
            }
        }//if submitted && isValid
        return $this->render("admin/balance/import.html.twig", [
            "form" => $form->createView(),
        ]);
    }

    function normalizeDecimal($val){
        $arrVal=explode(",",$val);
        return str_replace(" ","",$arrVal[0]).".".(count($arrVal)>1 ? $arrVal[1] :"00");
    }

}
