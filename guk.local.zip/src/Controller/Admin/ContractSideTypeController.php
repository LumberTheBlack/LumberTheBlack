<?php

namespace App\Controller\Admin;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use App\Repository\ContractSideTypeRepository;
use App\Entity\ContractSideType;
use App\Form\ContractSideTypeFormType;
use Doctrine\ORM\EntityManagerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;


    /**
     * @Route("/admin/contract/side/type")
     * @IsGranted("ROLE_CONTRACT_MANAGER")
     */
class ContractSideTypeController extends AbstractController
{
    /**
     * @Route("/", name="admin_contract_side_type")
     */
    public function index(ContractSideTypeRepository $contractSideTypeRepository)
    {
        return $this->render('admin/contract_side_type/index.html.twig', [
            'types' => $contractSideTypeRepository->findAllOrderByName(),
        ]);
    }
    /**
     *  @Route("/add", name="admin_contract_side_type_add")
     */
     public function add(Request $request)
     {
         $newSideType=new ContractSideType();
         $form=$this->createForm(ContractSideTypeFormType::class,$newSideType);
         $form->handleRequest($request);
         if($form->isSubmitted() && $form->isValid())
         {
             $manager=$this->getDoctrine()->getManager();
             $manager->persist($newSideType);
             $manager->flush();
             $this->addFlash("success","message.create_success"); 
             return $this->redirectToRoute("admin_contract_side_type");
         }
         return $this->render("admin/contract_side_type/add.html.twig",[
                "form"=>$form->createView()
         ]);
     }  
    /**
     *  @Route("/edit/{id}", name="admin_contract_side_type_edit")
     */
     public function edit(ContractSideType $sideType, Request $request)
     {
         $form=$this->createForm(ContractSideTypeFormType::class,$sideType);
         $form->handleRequest($request);
         if($form->isSubmitted() && $form->isValid())
         {
             $manager=$this->getDoctrine()->getManager();
             $manager->persist($sideType);
             $manager->flush();
             $this->addFlash("success","message.update_success"); 
             return $this->redirectToRoute("admin_contract_side_type");
         }
         return $this->render("admin/contract_side_type/edit.html.twig",[
                "form"=>$form->createView()
         ]);
     }  
    /**
     * @ROUTE("/{id}/delete", name="admin_contract_side_type_delete")
     */
    public function deleteSideType(Request $request, ContractSideType $sideType, EntityManagerInterface $manager)
    {
        $manager->remove($sideType);
        $manager->flush();

        $this->addFlash("success","message.delete_success");
        return $this->redirectToRoute("admin_contract_side_type");
    }



}
