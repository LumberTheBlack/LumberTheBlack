<?php

namespace App\Controller\Admin;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use App\Repository\ActRepository;
use App\Repository\FileReferenceRepository;
use App\Entity\Act;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use App\Form\ActFormType;
use Knp\Component\Pager\PaginatorInterface;

    /**
     * @Route("/admin/act")
     * @IsGranted("ROLE_ACT_MANAGER")
     */

class ActController extends AbstractController
{
    /**
     * @Route("/", name="admin_act")
     */
    public function index(Request $request,ActRepository $actRepository, PaginatorInterface $paginator)
    {
        $acts=$paginator->paginate(
            $actRepository->findAllOrderedByCreatedAt($request->query->get("q",null)),
            $request->query->get('page',1),
            10
        );

        return $this->render('admin/act/index.html.twig', [
            'acts' => $acts,
        ]);
    }
    /**
     *  @Route("/add", name="admin_act_add")
     */
     public function add(Request $request)
     {
         $act=new Act();
         $form=$this->createForm(ActFormType::class,$act);
         $form->handleRequest($request);
         if($form->isSubmitted() && $form->isValid())
         {

             $manager=$this->getDoctrine()->getManager();
             $manager->persist($act);
             $manager->flush();
             $this->addFlash("success","message.create_success"); 
             return $this->redirectToRoute("admin_act_edit",["id"=>$act->getId()]);
         }
         return $this->render("admin/act/add.html.twig",[
                "form"=>$form->createView()
         ]);
     }  
    /**
     *  @Route("/edit/{id}", name="admin_act_edit")
     */
     public function edit(Act $act, Request $request, FileReferenceRepository $fileReferenceRepository)
     {
         $form=$this->createForm(ActFormType::class,$act);
         $form->handleRequest($request);
         if($form->isSubmitted() && $form->isValid())
         {
             $manager=$this->getDoctrine()->getManager();
             $manager->persist($act);
             $manager->flush();
             $this->addFlash("success","message.update_success"); 
             return $this->redirectToRoute("admin_act");
         }
         return $this->render("admin/act/edit.html.twig",[
                "form"=>$form->createView(),
                "act"=>$act
         ]);
     }  
    /**
     * @ROUTE("/{id}/delete", name="admin_act_delete")
     */
    public function deleteAct(Request $request, Act $act, EntityManagerInterface $manager)
    {
        $files=$act->getImages();   
        foreach($files as $afile)
              $manager->remove($afile);
        $manager->remove($act);
        $manager->flush();

        $this->addFlash("success","message.delete_success");
        return $this->redirectToRoute("admin_act");
    }
    /**
     * @Route("/show/{id}", name="admin_act_show")
     */ 
     public function show(Act $act, FileReferenceRepository $fr)
     {
        return $this->render("admin/act/show.html.twig",[
            "act"=>$act,
        ]);
     }

}
