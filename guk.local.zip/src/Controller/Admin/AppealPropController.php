<?php

namespace App\Controller\Admin;

use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;

class AppealPropController extends AbstractController
{
    /**
     * @Route("/admin/appeal", name="admin_appeal")
     */
    public function index()
    {
        return $this->render('admin/appeal_prop/index.html.twig', [
            'controller_name' => 'AppealController',
        ]);
    }
    /**
     * @ROUTE("/admin/appeal/props/{className}/list", name="admin_appeal_props_list")
     */
    public function getAppealPropsByType(Request $request, $className)
    {
        $appealRepository= $this->getDoctrine()->getManager()->getRepository('App\\Entity\\'.$className);
        return $this->json(
           ['appeal_props_items'=> $appealRepository->findBy([],['name'=>'ASC'])],
           200,
           [],
           []
        );
    }
    /**
     * @ROUTE("/admin/appeal/props/{className}/new", name="admin_appeal_props_new")
     */
    public function addAppealProp(Request $request, $className, EntityManagerInterface $manager, SerializerInterface $serializer)
    {
       $ap='App\\Entity\\'.$className;
       $newAppealProp=new $ap();
       $serializer->deserialize(
           $request->getContent(),
           $ap,
           'json',
           ['object_to_populate'=>$newAppealProp]
           );
       $manager->persist($newAppealProp);
       $manager->flush();
       return $this->json(
           ['new_appeal_props_item'=>$newAppealProp],
           201
       );
    }
    /**
     * @ROUTE("/admin/appeal/props/{type_of_appeal_props}/edit/{id}",name="admin_appeal_props_edit")
     */
     public function editAppealProp(Request $request,$type_of_appeal_props,$id, EntityManagerInterface $em, SerializerInterface $serializer){
          $className='App\\Entity\\'.$type_of_appeal_props;
          $appealRepository= $em->getRepository($className);
          $ap=$appealRepository->findOneBy(['id'=>$id]);
          if($ap){
            $serializer->deserialize(
              $request->getContent(),
              $className,
              'json',
              ['object_to_populate'=>$ap]
            );
            $em->persist($ap);
            $em->flush();
            return $this->json(
              ['editAppealProp'=>$ap],
              201
            );
          } 
          return $this->json(
            ['editAppealProp'=>null],
            404
          );
     }
    /**
     * @ROUTE("/admin/appeal/props/{className}", name="admin__appeal_props");
     */
    public function adminAppealProps(Request $request, $className)
    {
        return $this->render('admin/appeal_prop/props.html.twig',
            [
                'type_of_appeal_props'=>$className,
            ]);
    }
    /**
     * @ROUTE("/admin/appeal/props/{type_of_appeal_props}/delete/{id}",methods="DELETE", name="admin_appeal_props_delete")
     */
    public function deleteAppealPropItem(Request $request, $type_of_appeal_props,$id, EntityManagerInterface $em){
           $appealRepository= $em->getRepository('App\\Entity\\'.$type_of_appeal_props);
           $ap=$appealRepository->findOneBy(['id'=>$id]);
           if($ap)$em->remove($ap);
           $em->flush();
           return new Response(null,204);
    }
}
