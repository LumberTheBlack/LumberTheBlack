<?php

namespace App\Controller\Admin;

use App\Entity\Appeal;
use App\Repository\UserRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class ExecutorController extends AbstractController
{
    /**
     * @param Request $request
     * @param Appeal $appeal
     * @Route("/admin/executor/{id}/edit", name="admin_executors_edit")
     */
    public function act(Request $request, Appeal $appeal)
    {
        return $this->render("/admin/executor/act.html.twig",[
            "appeal"=>$appeal
        ]);
    }
    /**
     * @Route("/admin/executor/{id}/get", name="admin_executor")
     */
    public function getExecutor(Request $request,Appeal $appeal, UserRepository $userRepository)
    {
        return $this->json(
            [
                "users"=>$userRepository->getActiveUser()->getQuery()->getResult(),
                "executors"=>$appeal->getExecutors()
            ],
            200,
            [],
            ["groups"=>["main"]]
        );
    }

    /**
     * @param Request $request
     * @param Appeal $appeal
     * @Route("/admin/executor/{id}/save", name="admin_executors_save")
     */
    public function save(Request $request, Appeal $appeal, EntityManagerInterface $manager, UserRepository $userRepository)
    {
         $data=json_decode($request->getContent());
         foreach($appeal->getExecutors() as $executor) $appeal->removeExecutor($executor);
         foreach ($data as $executor)
             $appeal->addExecutor($userRepository->find($executor->id));
         $manager->persist($appeal);
         $manager->flush();
         $this->addFlash("success","common.saved");
         return $this->json(["appeal"=>$appeal]);
    }
}
