<?php

namespace App\Controller\Admin;

use App\Entity\Appeal;
use App\Entity\Complainant;
use App\Entity\FileReference;
use App\Entity\FormOfAppeal;
use App\Form\AppealFormType;
use App\Normalizer\EntityNormalizer;
use App\Repository\AnswerRepository;
use App\Repository\CharacterOfAppealRepository;
use App\Repository\ComplainantRepository;
use App\Repository\FileReferenceRepository;
use App\Repository\FormOfAppealRepository;
use App\Repository\NomenclatureRepository;
use App\Repository\TypeOfAppealRepository;
use App\Service\UploaderHelper;
use Doctrine\ORM\EntityManagerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\PropertyInfo\Extractor\ReflectionExtractor;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\AbstractNormalizer;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\SerializerInterface;

/**
 * Class AppealController
 * @package App\Controller\Admin
 * @IsGranted("ROLE_MANAGER")
 */
class AppealController extends AbstractController
{
    /**
     * @Route("/admin/appeal/action", name="admin_appeal_add")
     */
    public function add(Request $request)
    {
        return $this->render('admin/appeal/add.html.twig',[

        ]);
    }

    /**
     * @param Request $request
     * @param Appeal $appeal
     * @return \Symfony\Component\HttpFoundation\Response
     * @Route("/admin/appeal/{id}/edit")
     */
    public function edit(Request $request, Appeal $appeal, EntityManagerInterface $manager)
    {
        $form=$this->createForm(AppealFormType::class, $appeal,['individual'=>$appeal->getComplainant()->isIndividual()]);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $manager->persist($appeal);
            $manager->flush();
            $this->addFlash("success","common.saved");
            return $this->redirectToRoute("app_appeal");
        }

        return $this->render("admin/appeal/edit.html.twig",[
            "form"=>$form->createView()
        ]);
    }

    /**
     * @param Request $request
     * @param EntityManagerInterface $manager
     * @param SerializerInterface $serializer
     * @Route("/admin/appeal/new", name="admin_appeal_new")
     */
    public function newAppeal(Request $request, EntityManagerInterface $manager,SerializerInterface $serializer,
                              FormOfAppealRepository $formOfAppealRepository, TypeOfAppealRepository $typeOfAppealRepository,
                              CharacterOfAppealRepository $characterOfAppealRepository, ComplainantRepository $complainantRepository,
                              NomenclatureRepository $nomenclatureRepository,
                              FileReferenceRepository $fileReferenceRepository
                              )
    {
        $appeal=new Appeal();
        $data=json_decode($request->getContent());
        $serializer->deserialize(
            $request->getContent(),
            Appeal::class,
            'json'
        );
        $appeal->setFormOfAppeal($formOfAppealRepository->find($data->formOfAppeal->id));
        $appeal->setCharacterOfAppeal($characterOfAppealRepository->find($data->characterOfAppeal->id));
        $appeal->setTypeOfAppeal($typeOfAppealRepository->find($data->typeOfAppeal->id));
        $appeal->setNomenclature($nomenclatureRepository->find($data->nomenclature->id));
        $appeal->setRegistrar($this->getUser());
        $appeal->setDataIn(new \DateTimeImmutable($data->dateIn));
        $appeal->setContent($data->content);
        $appeal->setExecutionTime(intval($data->executionTime));
        $complainant=$complainantRepository->findOneBy(["id"=>$data->complainant->id]);
        if(!$complainant->isIndividual()){
            $appeal->setDateDoc(new \DateTimeImmutable($data->dateDoc));
            $appeal->setInitialNumber($data->initialNumber);
        }
        $appeal->setComplainant($complainant);
        /**
         * @var FileReference[] $files
         */
        $files=$fileReferenceRepository->findFiles(array_column($data->files,"id"));
        foreach($files as $file)
          $file->setAppeal($appeal);
        $manager->persist($appeal);
        $manager->flush();

        $this->addFlash("success","common.added");
        return $this->json(["appeal"=>$appeal]);
    }
    /**
     * @Route("/admin/appeal/{id}/get", name="admin_appeal_get")
     */
    public function getAppeal(Appeal $appeal,FileReferenceRepository $fileReferenceRepository)
    {
        return $this->json(
            [
                "appeal"=>$appeal,
                "files"=>$fileReferenceRepository->findBy(["appeal"=>$appeal],["fileName"=>"ASC"])
            ],
            200,
            [],
            [
                "groups"=>["main"]
            ]
        );
    }
    /**
     * @param Request $request
     * @param EntityManagerInterface $manager
     * @param SerializerInterface $serializer
     * @Route("/admin/appeal/{id}/save", name="admin_appeal_save")
     */
    public function saveAppeal(Request $request,Appeal $appeal, EntityManagerInterface $manager,SerializerInterface $serializer,
                              FormOfAppealRepository $formOfAppealRepository, TypeOfAppealRepository $typeOfAppealRepository,
                              CharacterOfAppealRepository $characterOfAppealRepository, ComplainantRepository $complainantRepository,
                              NomenclatureRepository $nomenclatureRepository,
                              FileReferenceRepository $fileReferenceRepository
    )
    {
        $data=json_decode($request->getContent());
        $serializer->deserialize(
            $request->getContent(),
            Appeal::class,
            'json',
            [AbstractNormalizer::OBJECT_TO_POPULATE=>$appeal,"groups"=>["main"]]
        );
        $appeal->setFormOfAppeal($formOfAppealRepository->find($data->formOfAppeal->id));
        $appeal->setCharacterOfAppeal($characterOfAppealRepository->find($data->characterOfAppeal->id));
        $appeal->setTypeOfAppeal($typeOfAppealRepository->find($data->typeOfAppeal->id));
        $appeal->setNomenclature($nomenclatureRepository->find($data->nomenclature->id));
        //$appeal->setRegistrar($this->getUser());
        $appeal->setDataIn(new \DateTimeImmutable($data->dateIn));
        $appeal->setContent($data->content);
        $appeal->setExecutionTime(intval($data->executionTime));
        $complainant=$complainantRepository->findOneBy(["id"=>$data->complainant->id]);
        if(!$complainant->isIndividual()){
            $appeal->setDateDoc(new \DateTimeImmutable($data->dateDoc));
            $appeal->setInitialNumber($data->initialNumber);
        }
        $appeal->setComplainant($complainant);
        /**
         * @var FileReference[] $files
         */
        $files=$fileReferenceRepository->findFiles(array_column($data->files,"id"));
        foreach($files as $file)
            $file->setAppeal($appeal);
        $manager->persist($appeal);
        $manager->flush();

        $this->addFlash("success","common.saved");
        return $this->json(["appeal"=>$appeal]);
    }

    /**
     * @param Request $request
     * @param Appeal $appeal
     * @param AnswerRepository $answerRepository
     * @Route("/admin/appeal/{id}/delete", name="admin_appeal_delete")
     */
    public function deleteAppeal(Request $request, Appeal $appeal, AnswerRepository $answerRepository,
                                 FileReferenceRepository$fileReferenceRepository, EntityManagerInterface $manager, UploaderHelper $uploaderHelper)
    {
        $answers=$answerRepository->findBy(['appeal'=>$appeal]);
        $files=$fileReferenceRepository->findBy(['appeal'=>$appeal]);
        if($answers){
            foreach($answers as $answer){
                $answerFiles=$fileReferenceRepository->findBy(["answer"=>$answer]);
                foreach($answerFiles as $afile) $uploaderHelper->deleteUploadedFile($afile);
                $manager->remove($answer);
            }
        }
        if($files)
            foreach ($files as $file) {
               $uploaderHelper->deleteUploadedFile($file);
            }
        $manager->remove($appeal);
        $manager->flush();
        $this->addFlash('success','appeal.removed');

        return $this->redirectToRoute("app_appeal");
    }
}
