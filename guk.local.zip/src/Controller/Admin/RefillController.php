<?php

namespace App\Controller\Admin;

use App\Entity\Refill;
use App\Repository\RefillRepository;
use App\Repository\CartridgeRepository;
use App\Repository\EmployeeRepository;
use Doctrine\ORM\EntityManagerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Normalizer\AbstractNormalizer;
use Symfony\Component\Serializer\SerializerInterface;

class RefillController extends AbstractController
{
    /**
     * @Route("/admin/refill", name="admin_refill")
     * @IsGranted("ROLE_ADMIN")
     */
    public function index()
    {
        return $this->render('admin/refill/index.html.twig', [
        ]);
    }

    /**
     * @param Request $request
     * @param EntityManagerInterface $manager
     * @Route("/admin/refill/get/{search}", name="admin_refill_get")
     */
    public function getRefills(Request $request, $search=null, EntityManagerInterface $manager, RefillRepository $refillRepository)
    {
        //if($search!=null) return $this->json(["refills"=>$refillRepository->findBy(["sn"=>$search])]);
        return $this->json(['refills'=>$refillRepository->findLatest()]);
    }

    /**
     * @param Refill $refill
     * @param EntityManagerInterface $manager
     * @Route("/admin/refill/{id}/delete", methods={"DELETE"}, name="admin_refill_delete")
     */
    public function deleteRefill(Refill $refill, EntityManagerInterface $manager)
    {
        $manager->remove($refill);
        $manager->flush();

        return new Response(null,Response::HTTP_NO_CONTENT);
    }

    /**
     * @param Request $request
     * @param Refill|null $refill
     * @param EntityManagerInterface $manager
     * @param SerializerInterface $serializer
     * @param RefillRepository $refillRepository
     * @param CartridgeModelRepository $cartridgemodelRepository
     * @Route("/admin/refill/save/{id}", methods="POST", name="admin_refill_save")
     */
    public function saveRefill(Request $request, Refill $refill=null, EntityManagerInterface $manager,
                                 SerializerInterface $serializer, RefillRepository $refillRepository,
                                 CartridgeRepository $cartridgeRepository, EmployeeRepository $employeeRepository
                               )
    {
        $decodedData=json_decode($request->getContent());
       if($refill==null) {
           $refill=new Refill();
       }

       $serializer->deserialize(
           $request->getContent(),
           Refill::class,
           'json',
           [AbstractNormalizer::OBJECT_TO_POPULATE=>$refill]
       );
       $refill->setCartridge($cartridgeRepository->find($decodedData->cartridge->id));
       $refill->setEmployee($employeeRepository->find($decodedData->employee->id));
       $manager->persist($refill);
       $manager->flush();

       return $this->json(["refill"=>$refill]);
    }

    /**
     * @param Refill $refill
     * @param EntityManagerInterface $manager
     * @Route("/admin/refill/{id}/togglestatus", name="admin_refill_togglestatus")
     */
    public function toggleStatus(Refill $refill, EntityManagerInterface $manager)
    {
        $refill->setRefilledAt($refill->getRefilledAt()!=null?null:new \DateTimeImmutable());
        $manager->persist($refill);
        $manager->flush();

        return $this->json(["refill"=>$refill]);
    }
}
