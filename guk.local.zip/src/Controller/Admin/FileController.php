<?php

namespace App\Controller\Admin;

use App\Entity\Appeal;
use App\Entity\FileReference;
use App\Entity\Post;
use App\Entity\Contract;
use App\Entity\Act;
use App\Repository\FileReferenceRepository;
use App\Service\UploaderHelper;
use Doctrine\ORM\EntityManagerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Validator\Constraints\File;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Validator\ValidatorInterface;

/**
 * Class FileController
 * @package App\Controller\Admin
 * @Route("/file")
 *
 */
class FileController extends AbstractController
{
    /**
     * @Route("/api/upload/{id?null}", name="file_api_upload")
     */
    public function uploadFile(Request $request,Post $post=null,UploaderHelper $helper, ValidatorInterface $validator)
    {
        $file=$request->files->get("reference");
        if(!($file instanceOf UploadedFile)) return $this->json('Not uploadedFile object',400);
        $violations = $validator->validate(
            $file,
            [
                new NotBlank([
                    'message' => 'Please select a file to upload'
                ]),
                new File([
                    'maxSize' => '20M',
                    'mimeTypes' => [
                        'image/*',
                        'application/pdf',
                        'application/msword',
                        'application/vnd.ms-excel',
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                        'text/plain',
                        'application/rtf',
                        'application/vnd.oasis.opendocument.text',
                        'application/vnd.oasis.opendocument.spreadsheet',
                        'application/vnd.oasis.opendocument.formula',
                        'application/octet-stream',
                        'application/xml',
                        'text/xml'
                    ]
                ])
            ]
        );
        if ($violations->count() > 0) {
            return $this->json($violations, 400);
        }

        $fileReference=$helper->uploadFile($request->files->get("reference"),null,$post);
        return $this->json(
            ['newFileReference'=>$fileReference],
            201,
            [],
            ['groups'=>['main']]
        );
    }
    /**
     * @Route("/api/upload/contract/{id}", name="file_api_upload_contract")
     */
    public function uploadContractFile(Request $request,Contract $contract,UploaderHelper $helper, ValidatorInterface $validator)
    {
        $file=$request->files->get("reference");
        if(!($file instanceOf UploadedFile)) return $this->json('Not uploadedFile object',400);
        $violations = $validator->validate(
            $file,
            [
                new NotBlank([
                    'message' => 'Please select a file to upload'
                ]),
                new File([
                    'maxSize' => '20M',
                    'mimeTypes' => [
                        'application/pdf',
                    ]
                ])
            ]
        );
        if ($violations->count() > 0) {
            return $this->json($violations, 400);
        }
        $fileReference=$helper->uploadFile($request->files->get("reference"),null,$contract);
        return $this->json(
            ['newFileReference'=>$fileReference],
            201,
            [],
            ['groups'=>['main']]
        );
    }
    /**
     * @Route("/api/upload/act/{id}", name="file_api_upload_act")
     */
    public function uploadActFile(Request $request,Act $act,UploaderHelper $helper, ValidatorInterface $validator)
    {
        $file=$request->files->get("reference");
        if(!($file instanceOf UploadedFile)) return $this->json('Not uploadedFile object',400);
        $violations = $validator->validate(
            $file,
            [
                new NotBlank([
                    'message' => 'Please select a file to upload'
                ]),
                new File([
                    'maxSize' => '20M',
                    'mimeTypes' => [
                        'application/pdf',
                    ]
                ])
            ]
        );
        if ($violations->count() > 0) {
            return $this->json($violations, 400);
        }
        $fileReference=$helper->uploadFile($request->files->get("reference"),null,$act);
        return $this->json(
            ['newFileReference'=>$fileReference],
            201,
            [],
            ['groups'=>['main']]
        );
    }


    /**
     * @param Request $request
     * @Route("/api/{id}/list", name="file_api_list")
     */
    public function list($id, FileReferenceRepository $fileReferenceRepository)
    {
          return $this->json(
              ['files'=>$fileReferenceRepository->findBy(['appeal'=>$id],['fileName'=>'DESC'])],
              200,
              [],
              ['groups'=>['main']]
          );
    }
    /**
     * @param Request $request
     * @Route("/api/post/{id}/list", name="file_api_post_list")
     */
    public function listPostFile($id, FileReferenceRepository $fileReferenceRepository)
    {
        return $this->json(
            ['files'=>$fileReferenceRepository->findBy(['post'=>$id],['fileName'=>'DESC'])],
            200,
            [],
            ['groups'=>['main']]
        );
    }
    /**
     * @param Request $request
     * @Route("/api/contract/{id}/list", name="file_api_contract_list")
     */
    public function listContractFile($id, FileReferenceRepository $fileReferenceRepository)
    {
        return $this->json(
            ['files'=>$fileReferenceRepository->findBy(['contract'=>$id],['fileName'=>'DESC'])],
            200,
            [],
            ['groups'=>['main']]
        );
    }
    /**
     * @param Request $request
     * @Route("/api/act/{id}/list", name="file_api_act_list")
     */
    public function listActFile($id, FileReferenceRepository $fileReferenceRepository)
    {
        return $this->json(
            ['files'=>$fileReferenceRepository->findBy(['act'=>$id],['fileName'=>'DESC'])],
            200,
            [],
            ['groups'=>['main']]
        );
    }

    /**
     * @Route("/api/delete/{id}", methods="DELETE", name="file_api_delete")
     */
    public function removeUploadedFile(FileReference $fileReference, UploaderHelper $helper, EntityManagerInterface $em)
    {
        $helper->deleteUploadedFile($fileReference);
        $em->flush();
        return new Response(null,204);

    }
    /**
     * @Route("/api/deleteSelected", methods="DELETE", name="file_api_delete_selected")
     */
    public function removeSelectedUploadedFile(Request $request, UploaderHelper $helper, EntityManagerInterface $em, FileReferenceRepository $repository,SerializerInterface $serializer)
    {
        $data=json_decode($request->getContent(),true);
        foreach ($data as $datum) {
            $file=($repository->find($datum));
            if($file) {
                $helper->deleteUploadedFile($file);
                $em->flush();
            }
        }
        return new Response(null,204);

    }
    /**
     * @Route("/api/update/{id}", methods="POST", name="file_api_update")
     */
    public function updateFile(Request $request,FileReference $fileReference, SerializerInterface $serializer, EntityManagerInterface $em)
    {
        $serializer->deserialize(
            $request->getContent(),
            FileReference::class,
            'json',
            [   'object_to_populate'=>$fileReference,
                'groups'=>"main" ]
        );

        $em->persist($fileReference);
        $em->flush();
        return $this->json(
            $fileReference,
            200,
            [],
            [
                'groups'=>"main"
            ]
        );
     }

     /**
      * @Route("/untagged/clear", name="file_untagged_clear")
      */
    public function clearUntagged(EntityManagerInterface $manager, FileReferenceRepository $repository, UploaderHelper $helper)
    {
        $untagged=$repository->findUntagged();
        if(count($untagged)===0) {
            $this->addFlash("success","file.untaggedNotFound");
            return $this->redirectToRoute("homepage");
        }
        foreach ($untagged as $file){
           $helper->deleteUploadedFile($file);
        }
        $this->addFlash("success","file.untaggedRemoved");
        return $this->redirectToRoute("homepage");
     }
}
