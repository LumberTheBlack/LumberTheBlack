<?php

namespace App\Controller\Admin;

use App\Entity\Printer;
use App\Repository\ManufacturerRepository;
use App\Repository\PrinterRepository;
use Doctrine\ORM\EntityManagerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Entity;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Normalizer\AbstractNormalizer;
use Symfony\Component\Serializer\SerializerInterface;

class PrinterController extends AbstractController
{
    /**
     * @Route("/admin/printer", name="admin_printer")
     */
    public function index()
    {
        return $this->render('admin/printer/index.html.twig', [
        ]);
    }

    /**
     * @param Request $request
     * @Route("/admin/printer/save", methods="POST", name="admin_printer_save" )
     */
    public function savePrinter(Request $request, SerializerInterface $serializer, EntityManagerInterface $manager,
                                 PrinterRepository $printerRepository, ManufacturerRepository $manufacturerRepository)
    {
        $decodedData=json_decode($request->getContent());
        if(property_exists($decodedData,"id")) {
            $printer = $printerRepository->find($decodedData->id);
            $printer->setModel($decodedData->model);
            $printer->setManufacturer($manufacturerRepository->find($decodedData->manufacturer->id));
            $manager->persist($printer);
            $manager->flush();
            return $this->json(["printer"=>$printer]);
        }
        $printer=new Printer();
        $printer->setManufacturer($manufacturerRepository->find($decodedData->manufacturer->id));
        $printer->setModel($decodedData->model);
        $printerFound=$printerRepository->findOneBy(["model"=>$decodedData->model,"manufacturer"=>$printer->getManufacturer()]);
        if($printerFound) return $this->json(["printer"=>$printerFound],Response::HTTP_FOUND);
        $manager->persist($printer);
        $manager->flush();
        return $this->json(["printer"=>$printer]);
    }

    /**
     * @param Request $request
     * @param PrinterRepository $repository
     * @Route("/admin/printer/get/{search}", name="admin_printer_get")
     */
    public function getPrinters(Request $request, $search=null, PrinterRepository $repository)
    {
        if($search) return $this->json(["printers"=>$repository->findBy(["name"=>$search])]);
        return $this->json(["printers"=>$repository->findAll()]);
    }

    /**
     * @param Printer $printer
     * @param EntityManagerInterface $manager
     * @Route("/admin/printer/{id}/delete", methods="DELETE", name="admin_printer_delete")
     */
    public function deletePrinter(Printer $printer, EntityManagerInterface $manager)
    {
//        $employees=$employeeRepository->findBy(["printer"=>$printer]);
//        if(count($employees)>0)return $this->json("Used", Response::HTTP_IM_USED);
        $manager->remove($printer);
        $manager->flush();

        return new Response(null,Response::HTTP_NO_CONTENT);
    }
}
