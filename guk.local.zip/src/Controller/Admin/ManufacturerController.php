<?php

namespace App\Controller\Admin;

use App\Entity\Manufacturer;
use App\Repository\ManufacturerRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Normalizer\AbstractNormalizer;
use Symfony\Component\Serializer\SerializerInterface;

class ManufacturerController extends AbstractController
{
    /**
     * @Route("/admin/manufacturer", name="admin_manufacturer")
     */
    public function index()
    {
        return $this->render('admin/manufacturer/index.html.twig', [
        ]);
    }
    /**
     * @Route("/admin/manufacturer/save", name="admin_manufacturer_save")
     */
    public function save(Request $request,EntityManagerInterface $manager, SerializerInterface $serializer, ManufacturerRepository $repository)
    {
       $decodedData=json_decode($request->getContent());
        //  dd($decodedData);
       if(property_exists($decodedData,'id')){
            $manufacturer=$repository->find($decodedData->id);
       }
       else{
           $existManufacturer=$repository->findBy(["name"=>$decodedData->name]);
           if(count($existManufacturer)>0)return $this->json($existManufacturer,Response::HTTP_FOUND);
           $manufacturer=new Manufacturer();
       }
      $serializer->deserialize(
          $request->getContent(),
          Manufacturer::class,
          'json',
           [AbstractNormalizer::OBJECT_TO_POPULATE=>$manufacturer]
      );
      $manager->persist($manufacturer);
      $manager->flush();
      return $this->json(["manufacturer"=>$manufacturer]);
    }
    /**
     * @Route("/admin/manufacturer/get/{searchCondition}", name="admin_manufacturer_get")
     */
    public function getManufacturer(Request $request,$searchCondition=null, ManufacturerRepository $manufacturerRepository)
    {
        return $this->json(
            [
                "manufacturers"=>$searchCondition!=null?$manufacturerRepository->findBy(["name"=>$searchCondition]):$manufacturerRepository->findAll()
            ]
        );
    }

    /**
     * @Route("/admin/manufacturer/{id}/delete", methods="DELETE", name="admin_manufacturer_delete")
     */
    public function deleteManufacturer(Manufacturer $manufacturer, EntityManagerInterface $manager, ManufacturerRepository $repository)
    {
       //$positions=$positionRepository->findBy(["manufacturer"=>$manufacturer]);
       //if(count($positions)>0) return $this->json("Used",Response::HTTP_FORBIDDEN);
       $manager->remove($repository->find($manufacturer));
       $manager->flush();

       return new Response(null,Response::HTTP_NO_CONTENT);
    }
}
