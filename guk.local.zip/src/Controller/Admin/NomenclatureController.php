<?php

namespace App\Controller\Admin;

use App\Entity\Nomenclature;
use App\Form\NomenclatureFormType;
use App\Repository\NomenclatureRepository;
use Doctrine\ORM\EntityManagerInterface;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class NomenclatureController extends AbstractController
{
    /**
     * @Route("/admin/nomenclature", name="admin_nomenclature")
     */
    public function index(Request $request, NomenclatureRepository $repository, PaginatorInterface $paginator)
    {
        $paginatedResult=$paginator->paginate(
            $repository->findAllRecords(),
            $request->query->get('page',1)
        );

        return $this->render('admin/nomenclature/index.html.twig', [
            'nomenclatures' => $paginatedResult,
        ]);
    }
    /**
     * @Route("/admin/nomenclature/add", name="admin_nomenclature_add")
     */
    public function add(Request $request,EntityManagerInterface $em)
    {
        $form=$this->createForm(NomenclatureFormType::class);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $nomenclature=$form->getData();
            $em->persist($nomenclature);
            $em->flush();
            $this->addFlash("success","nomenclature.created");
            return $this->redirectToRoute("admin_nomenclature");
        }
        return $this->render(
            "admin/nomenclature/add.html.twig",
            [
                "form"=>$form->createView()
            ]
        );
    }

    /**
     * @Route("/admin/nomenclature/{id}/edit", name="admin_nomenclature_edit")
     */
    public function edit(Request $request, Nomenclature $nomenclature, EntityManagerInterface $em)
    {
        $form=$this->createForm(NomenclatureFormType::class,$nomenclature);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $em->persist($nomenclature);
            $em->flush();
            $this->addFlash("success","nomenclature.saved");
            return $this->redirectToRoute("admin_nomenclature");
        }
        return $this->render("admin/nomenclature/edit.html.twig",[
           "form"=>$form->createView()
        ]);
    }

    /**
     * @param Request $request
     * @param NomenclatureRepository $nomenclatureRepository
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     * @Route("/admin/nomenclature/list" , name="admin_nomenclature_list_api")
     */
    public function list(Request $request, NomenclatureRepository $nomenclatureRepository)
    {
        return $this->json(
            ["nomenclatures"=>$nomenclatureRepository->findAll()],
            200
        );
    }
}
