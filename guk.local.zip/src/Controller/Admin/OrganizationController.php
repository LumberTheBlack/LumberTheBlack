<?php

namespace App\Controller\Admin;

use App\Entity\Organization;
use App\Repository\OrganizationRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class OrganizationController extends AbstractController
{
    /**
     * @Route("/admin/organization/list/{search}", name="admin_organization_list")
     */
    public function list(Request $request,$search=null,OrganizationRepository $repository)
    {
        return $this->json(
            ["organizations"=>$search==null?$repository->findAllOrderByName():$repository->findBySearchCondition($search)],200,[],
            ["groups"=>["main"]]
        );
    }
    /**
     * @Route("/admin/organization/add/{name}", name="admin_organization_add")
     */
    public function add(Request $request,$name, EntityManagerInterface $manager, OrganizationRepository $repository)
    {
        $entities=$repository->findBy(["name"=>$name]);
        if($entities)
            return $this->json([
               "resp"=>[
                    "organization"=>null,
                    "status"=>Response::HTTP_FOUND
                ]
            ],Response::HTTP_FOUND);
        $org=new Organization($name);
        $manager->persist($org);
        $manager->flush();
        return $this->json([
              "resp"=>[
                "organization"=>$org,
                "status"=>Response::HTTP_CREATED
              ]
            ],
            Response::HTTP_CREATED
        );
    }
    /**
     * @Route("/admin/organization/{id}/delete", methods={"DELETE"},name="admin_organization_delete")
     */
    public function deleteOrganization(Organization $organization, EntityManagerInterface $manager)
    {
        if($organization->getLegals()->count()>0)
            return $this->json(["status"=>Response::HTTP_CONFLICT],Response::HTTP_CONFLICT);
        $manager->remove($organization);
        $manager->flush();
        return $this->json(["status"=>204],204);
    }

}
