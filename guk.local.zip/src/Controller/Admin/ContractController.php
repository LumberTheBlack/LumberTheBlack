<?php

namespace App\Controller\Admin;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use App\Repository\ContractRepository;
use App\Repository\FileReferenceRepository;
use App\Entity\Contract;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use App\Form\ContractFormType;
use Knp\Component\Pager\PaginatorInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;

/**
 * @Route("/admin/contract")
 * @IsGranted("ROLE_CONTRACT_MANAGER")
 */
class ContractController extends AbstractController
{
    /**
     * @Route("/", name="admin_contract")
     */
    public function index(Request $request,ContractRepository $contractRepository, PaginatorInterface $paginator)
    {
        $contracts=$paginator->paginate(
            $contractRepository->findAllOrderedByDDate($request->query->get("q",null)),
            $request->query->get('page',1),
            10
        );

        return $this->render('admin/contract/index.html.twig', [
            'contracts' => $contracts,
        ]);
    }
    /**
     *  @Route("/add", name="admin_contract_add")
     */
     public function add(Request $request)
     {
         $contract=new Contract();
         $form=$this->createForm(ContractFormType::class,$contract);
         $form->handleRequest($request);
         if($form->isSubmitted() && $form->isValid())
         {
             $manager=$this->getDoctrine()->getManager();
             $manager->persist($contract);
             $manager->flush();
             $this->addFlash("success","message.create_success"); 
             return $this->redirectToRoute("admin_contract_edit",["id"=>$contract->getId()]);
         }
         return $this->render("admin/contract/add.html.twig",[
                "form"=>$form->createView()
         ]);
     }  
    /**
     *  @Route("/edit/{id}", name="admin_contract_edit")
     */
     public function edit(Contract $contract, Request $request, FileReferenceRepository $fileReferenceRepository)
     {
         $form=$this->createForm(ContractFormType::class,$contract);
         $form->handleRequest($request);
         if($form->isSubmitted() && $form->isValid())
         {
             $manager=$this->getDoctrine()->getManager();
             $manager->persist($contract);
             $manager->flush();
             $this->addFlash("success","message.update_success"); 
             return $this->redirectToRoute("admin_contract");
         }
         return $this->render("admin/contract/edit.html.twig",[
                "form"=>$form->createView(),
                "contract"=>$contract
         ]);
     }  
    /**
     * @ROUTE("/{id}/delete", name="admin_contract_delete")
     */
    public function deleteSideType(Request $request, Contract $contract, EntityManagerInterface $manager)
    {
        $files=$contract->getImages();
        foreach($files as $afile)
              $manager->remove($afile);
        $manager->remove($contract);
        $manager->flush();

        $this->addFlash("success","message.delete_success");
        return $this->redirectToRoute("admin_contract");
    }
    /**
     * @Route("/show/{id}", name="admin_contract_show")
     */ 
     public function show(Contract $contract, FileReferenceRepository $fr)
     {
        return $this->render("admin/contract/show.html.twig",[
            "contract"=>$contract,
            "files"=>$fr->findBy(["contract"=>$contract],["fileName"=>"ASC"])
        ]);
     }

}
