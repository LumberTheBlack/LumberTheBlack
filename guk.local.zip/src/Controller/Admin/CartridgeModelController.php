<?php

namespace App\Controller\Admin;

use App\Entity\CartridgeModel;
use App\Repository\CartridgeModelRepository;
use App\Repository\PrinterRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Normalizer\AbstractNormalizer;
use Symfony\Component\Serializer\SerializerInterface;

class CartridgeModelController extends AbstractController
{
    /**
     * @Route("/admin/cartridgemodel", name="admin_cartridgemodel")
     */
    public function index()
    {
        return $this->render('admin/cartridgemodel/index.html.twig', [
        ]);
    }

    /**
     * @param Request $request
     * @param EntityManagerInterface $manager
     * @Route("/admin/cartridgemodel/get/{search}", name="admin_cartridgemodel_get")
     */
    public function getCartridgeModels(Request $request, $search=null, EntityManagerInterface $manager, CartridgeModelRepository $cartridgemodelRepository)
    {
        if($search!=null) return $this->json(["cartridgemodels"=>$cartridgemodelRepository->findBy(["name"=>$search])]);
        return $this->json(['cartridgemodels'=>$cartridgemodelRepository->findAll()]);
    }

    /**
     * @param CartridgeModel $cartridgemodel
     * @param EntityManagerInterface $manager
     * @Route("/admin/cartridgemodel/{id}/delete", methods={"DELETE"}, name="admin_cartridgemodel_delete")
     */
    public function deleteCartridgeModel(CartridgeModel $cartridgemodel, EntityManagerInterface $manager)
    {
        $manager->remove($cartridgemodel);
        $manager->flush();

        return new Response(null,Response::HTTP_NO_CONTENT);
    }

    /**
     * @param Request $request
     * @param CartridgeModel|null $cartridgemodel
     * @param EntityManagerInterface $manager
     * @param SerializerInterface $serializer
     * @param CartridgeModelRepository $cartridgemodelRepository
     * @param PrinterRepository $printerRepository
     * @Route("/admin/cartridgemodel/save/{id}", methods="POST", name="admin_cartridgemodel_save")
     */
    public function saveCartridgeModel(Request $request, CartridgeModel $cartridgemodel=null, EntityManagerInterface $manager,
                                 SerializerInterface $serializer, CartridgeModelRepository $cartridgemodelRepository, PrinterRepository $printerRepository)
    {
        $decodedData=json_decode($request->getContent());
       if($cartridgemodel==null) {
           if(count($cartridgemodelRepository->findBy(["name"=>$decodedData->name,"printer"=>$decodedData->printer->id]))>0)
              return $this->json([],Response::HTTP_FOUND);
           $cartridgemodel=new CartridgeModel();
       }

       $serializer->deserialize(
           $request->getContent(),
           CartridgeModel::class,
           'json',
           [AbstractNormalizer::OBJECT_TO_POPULATE=>$cartridgemodel]
       );
       $cartridgemodel->setPrinter($printerRepository->find($decodedData->printer->id));
       $manager->persist($cartridgemodel);
       $manager->flush();

       return $this->json(["cartridgemodel"=>$cartridgemodel]);
    }
}
