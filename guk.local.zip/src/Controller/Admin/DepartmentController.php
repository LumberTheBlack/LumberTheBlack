<?php

namespace App\Controller\Admin;

use App\Entity\Department;
use App\Repository\DepartmentRepository;
use App\Repository\PositionRepository;
use Doctrine\ORM\EntityManagerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Entity;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Normalizer\AbstractNormalizer;
use Symfony\Component\Serializer\SerializerInterface;

class DepartmentController extends AbstractController
{
    /**
     * @Route("/admin/department", name="admin_department")
     */
    public function index()
    {
        return $this->render('admin/department/index.html.twig', [
        ]);
    }
    /**
     * @Route("/admin/department/save", name="admin_department_save")
     */
    public function save(Request $request,EntityManagerInterface $manager, SerializerInterface $serializer, DepartmentRepository $repository)
    {
       $decodedData=json_decode($request->getContent());
        //  dd($decodedData);
       if(property_exists($decodedData,'id')){
            $department=$repository->find($decodedData->id);
       }
       else{
           $existDepartment=$repository->findBy(["name"=>$decodedData->name]);
           if(count($existDepartment)>0)return $this->json($existDepartment,Response::HTTP_FOUND);
           $department=new Department();
       }
      $serializer->deserialize(
          $request->getContent(),
          Department::class,
          'json',
           [AbstractNormalizer::OBJECT_TO_POPULATE=>$department]
      );
      $manager->persist($department);
      $manager->flush();
      return $this->json(["department"=>$department]);
    }
    /**
     * @Route("/admin/department/get/{searchCondition}", name="admin_department_get")
     */
    public function getDepartment(Request $request,$searchCondition=null, DepartmentRepository $departmentRepository)
    {
        return $this->json(
            [
                "departments"=>$searchCondition!=null?$departmentRepository->findBy(["name"=>$searchCondition]):$departmentRepository->findAll()
            ]
        );
    }

    /**
     * @Route("/admin/department/{id}/delete", methods="DELETE", name="admin_department_delete")
     */
    public function deleteDepartment(Department $department, EntityManagerInterface $manager, DepartmentRepository $repository,PositionRepository $positionRepository)
    {
       $positions=$positionRepository->findBy(["department"=>$department]);
       if(count($positions)>0) return $this->json("Used",Response::HTTP_FORBIDDEN);
       $manager->remove($repository->find($department));
       $manager->flush();

       return new Response(null,Response::HTTP_NO_CONTENT);
    }
}
