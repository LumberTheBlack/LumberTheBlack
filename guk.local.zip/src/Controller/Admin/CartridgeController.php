<?php

namespace App\Controller\Admin;

use App\Entity\Cartridge;
use App\Repository\CartridgeRepository;
use App\Repository\CartridgeModelRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Normalizer\AbstractNormalizer;
use Symfony\Component\Serializer\SerializerInterface;

class CartridgeController extends AbstractController
{
    /**
     * @Route("/admin/cartridge", name="admin_cartridge")
     */
    public function index()
    {
        return $this->render('admin/cartridge/index.html.twig', [
        ]);
    }

    /**
     * @param Request $request
     * @param EntityManagerInterface $manager
     * @Route("/admin/cartridge/get/{search}", name="admin_cartridge_get")
     */
    public function getCartridges(Request $request, $search=null, EntityManagerInterface $manager, CartridgeRepository $cartridgeRepository)
    {
        if($search!=null) return $this->json(["cartridges"=>$cartridgeRepository->findBySn($search)]);
        return $this->json(['cartridges'=>$cartridgeRepository->findAll()]);
    }

    /**
     * @param Cartridge $cartridge
     * @param EntityManagerInterface $manager
     * @Route("/admin/cartridge/{id}/delete", methods={"DELETE"}, name="admin_cartridge_delete")
     */
    public function deleteCartridge(Cartridge $cartridge, EntityManagerInterface $manager)
    {
        $manager->remove($cartridge);
        $manager->flush();

        return new Response(null,Response::HTTP_NO_CONTENT);
    }

    /**
     * @param Request $request
     * @param Cartridge|null $cartridge
     * @param EntityManagerInterface $manager
     * @param SerializerInterface $serializer
     * @param CartridgeRepository $cartridgeRepository
     * @param CartridgeModelRepository $cartridgemodelRepository
     * @Route("/admin/cartridge/save/{id}", methods="POST", name="admin_cartridge_save")
     */
    public function saveCartridge(Request $request, Cartridge $cartridge=null, EntityManagerInterface $manager,
                                 SerializerInterface $serializer, CartridgeRepository $cartridgeRepository, CartridgeModelRepository $cartridgemodelRepository)
    {
        $decodedData=json_decode($request->getContent());
       if($cartridge==null) {
           if(count($cartridgeRepository->findBy(["sn"=>$decodedData->sn,"model"=>$decodedData->model->id]))>0)
              return $this->json([],Response::HTTP_FOUND);
           $cartridge=new Cartridge();
       }

       $serializer->deserialize(
           $request->getContent(),
           Cartridge::class,
           'json',
           [AbstractNormalizer::OBJECT_TO_POPULATE=>$cartridge]
       );
       $cartridge->setModel($cartridgemodelRepository->find($decodedData->model->id));
       $manager->persist($cartridge);
       $manager->flush();

       return $this->json(["cartridge"=>$cartridge]);
    }
}
