<?php

namespace App\Controller\Admin;

use App\Entity\Position;
use App\Repository\DepartmentRepository;
use App\Repository\EmployeeRepository;
use App\Repository\PositionRepository;
use Doctrine\ORM\EntityManagerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Entity;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Normalizer\AbstractNormalizer;
use Symfony\Component\Serializer\SerializerInterface;

class PositionController extends AbstractController
{
    /**
     * @Route("/admin/position", name="admin_position")
     */
    public function index()
    {
        return $this->render('admin/position/index.html.twig', [
        ]);
    }

    /**
     * @param Request $request
     * @Route("/admin/position/save", methods="POST", name="admin_position_save" )
     */
    public function savePosition(Request $request, SerializerInterface $serializer, EntityManagerInterface $manager,
                                 PositionRepository $positionRepository, DepartmentRepository $departmentRepository)
    {
        $decodedData=json_decode($request->getContent());
        if(property_exists($decodedData,"id")) {
            $position = $positionRepository->find($decodedData->id);
            $position->setName($decodedData->name);
            $position->setDepartment($departmentRepository->findping ($decodedData->department->id));
            $manager->persist($position);
            $manager->flush();
            return $this->json(["position"=>$position]);
        }
        $position=new Position();
        $position->setDepartment($departmentRepository->find($decodedData->department->id));
        $position->setName($decodedData->name);
        $positionFound=$positionRepository->findOneBy(["name"=>$decodedData->name,"department"=>$position->getDepartment()]);
        if($positionFound) return $this->json(["position"=>$positionFound],Response::HTTP_FOUND);
        $manager->persist($position);
        $manager->flush();
        return $this->json(["position"=>$position]);
    }

    /**
     * @param Request $request
     * @param PositionRepository $repository
     * @Route("/admin/position/get/{search}", name="admin_position_get")
     */
    public function getPositions(Request $request, $search=null, PositionRepository $repository)
    {
        if($search) return $this->json(["positions"=>$repository->findBy(["name"=>$search])]);
        return $this->json(["positions"=>$repository->findAll()]);
    }

    /**
     * @param Position $position
     * @param EntityManagerInterface $manager
     * @Route("/admin/position/{id}/delete", methods="DELETE", name="admin_position_delete")
     */
    public function deletePosition(Position $position, EntityManagerInterface $manager, EmployeeRepository $employeeRepository)
    {
        $employees=$employeeRepository->findBy(["position"=>$position]);
        if(count($employees)>0)return $this->json("Used", Response::HTTP_IM_USED);
        $manager->remove($position);
        $manager->flush();

        return new Response(null,Response::HTTP_NO_CONTENT);
    }
}
