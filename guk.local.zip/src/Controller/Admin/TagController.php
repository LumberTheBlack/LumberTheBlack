<?php

namespace App\Controller\Admin;

use App\Repository\TagRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/admin/tag", name="admin_tag")
 * @IsGranted("ROLE_ADMIN")
 */
class TagController extends AbstractController
{
    /**
     * @Route("/api/search")
     */
    public function getTags(Request $request, TagRepository $tags)
    {
        $items=$tags->findAll();
        return $this->json(
            ['tags'=>$items],
            200,
            [],
            ['groups'=>["main"]]
        );
    }
}
