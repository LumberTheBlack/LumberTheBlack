<?php

namespace App\Controller\Admin;

use App\Entity\Answer;
use App\Entity\Appeal;
use App\Repository\AnswerRepository;
use App\Repository\FileReferenceRepository;
use App\Service\UploaderHelper;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Normalizer\AbstractNormalizer;
use Symfony\Component\Serializer\SerializerInterface;

class AnswerController extends AbstractController
{
    /**
     * @Route("/admin/answer/{id}/act", name="admin_answer")
     */
    public function act(Request $request, Appeal $appeal)
    {
        return $this->render('admin/answer/act.html.twig', [
            'appeal' => $appeal,
        ]);
    }
    /**
     * @param Request $request
     * @param EntityManagerInterface $manager
     * @param SerializerInterface $serializer
     * @Route("/admin/answer/{id}/new", name="admin_answer_new")
     */
    public function newAnswer(Request $request,Appeal $appeal, EntityManagerInterface $manager,SerializerInterface $serializer,
                              FileReferenceRepository $fileReferenceRepository
    )
    {
        $answer=new Answer();
        $data=json_decode($request->getContent());
        $serializer->deserialize(
            $request->getContent(),
            Answer::class,
            'json'
        );
        $answer->setRegistrar($this->getUser());
        $answer->setAnswerDate(new \DateTimeImmutable($data->answerDate));
        $answer->setContent($data->content);
        $answer->setAppeal($appeal);
        /**
         * @var FileReference[] $files
         */
        $files=$fileReferenceRepository->findFiles(array_column($data->files,"id"));
        foreach($files as $file)
            $file->setAnswer($answer);
        $manager->persist($answer);
        $manager->flush();

        $this->addFlash("success","common.added");
        return $this->json(["answer"=>$answer]);
    }
    /**
     * @Route("/admin/answer/{id}/get", name="admin_answer_get")
     */
    public function getAnswer(Answer $answer, FileReferenceRepository $fileReferenceRepository)
    {
        return $this->json(
            [
                "answer"=>$answer,
                "files"=>$fileReferenceRepository->findBy(["answer"=>$answer],["fileName"=>"ASC"])
            ],
            200,
            [],
            [
                "groups"=>["main"]
            ]
        );
    }
    /**
     * @param Request $request
     * @param EntityManagerInterface $manager
     * @param SerializerInterface $serializer
     * @Route("/admin/answer/{id}/save", name="admin_answer_save")
     */
    public function saveAppeal(Request $request,Answer $answer,SerializerInterface $serializer,
                               EntityManagerInterface $manager, FileReferenceRepository $fileReferenceRepository
    )
    {
        $data=json_decode($request->getContent());
        $serializer->deserialize(
            $request->getContent(),
            Answer::class,
            'json',
            [AbstractNormalizer::OBJECT_TO_POPULATE=>$answer,"groups"=>["main"]]
        );
        $answer->setRegistrar($this->getUser());
        $answer->setAnswerDate(new \DateTimeImmutable($data->answerDate));
        $answer->setContent($data->content);
        $answer->setApproveAt();
        $answer->setReturnAt();
        /**
         * @var FileReference[] $files
         */
        $files=$fileReferenceRepository->findFiles(array_column($data->files,"id"));
        foreach($files as $file)
            $file->setAnswer($answer);
        $manager->persist($answer);
        $manager->flush();

        $this->addFlash("success","common.saved");
        return $this->json(["appeal"=>$answer]);
    }

    /**
     * @param Request $request
     * @param Answer $answer
     * @param FileReferenceRepository $fileReferenceRepository
     * @param EntityManagerInterface $manager
     * @ROUTE("/admin/answer/{id}/delete", name="admin_answer_delete")
     */
    public function deleteAnswer(Request $request, Answer $answer, FileReferenceRepository $fileReferenceRepository, EntityManagerInterface $manager, UploaderHelper $uploaderHelper)
    {
        $appeal=$answer->getAppeal();
        $files=$fileReferenceRepository->findBy(["answer"=>$answer]);
        if($files)
            foreach ($files as $file) {
                $uploaderHelper->deleteUploadedFile($file);
            }
        $manager->remove($answer);
        $manager->flush();

        $this->addFlash("success","answer.deleted");
        return $this->redirectToRoute("app_appeal_show",["id"=>$appeal->getId()]);
    }

    /**
     * @param Request $request
     * @param EntityManagerInterface $manager
     * @ROUTE("/admin/answer/{id}/status", name="admin_answer_status_change")
     */
    public function setAnswerStatus(Request $request,Answer $answer, EntityManagerInterface $manager)
    {
    //   dd($request);
        $answerStatus=$request->query->get('answerStatus');
            if($answerStatus==1) {
                $answer->setApproveAt(new \DateTime());
                $answer->setReturnAt();
            }elseif($answerStatus==2) {
                $answer->setReturnAt(new \DateTime());
                $answer->setApproveAt();
            }else{
                $answer->setApproveAt();
                $answer->setReturnAt();
            }
            $manager->flush();
        return $this->redirectToRoute("app_appeal_show",["id"=>$answer->getAppeal()->getId()]);
    }
}
