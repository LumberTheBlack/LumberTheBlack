<?php

namespace App\Controller\Admin;

use App\Entity\Complainant;
use App\Entity\Legal;
use App\Entity\Residence;
use App\Repository\AddressObjectRepository;
use App\Repository\AppealRepository;
use App\Repository\ComplainantRepository;
use App\Repository\ComplainantTypeRepository;
use App\Repository\LegalRepository;
use App\Repository\OrganizationRepository;
use App\Repository\ResidenceRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use App\Form\ComplainantFormType;
use Knp\Component\Pager\PaginatorInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;

/**
 * Security("is_granted('ROLE_ADMIN') or is_granted('ROLE_MANAGER')")
 * @IsGranted("ROLE_MANAGER")
 */

class ComplainantController extends AbstractController
{
    /**
     * @Route("/admin/complainant", name="admin_complainant")
     */
    public function index(Request $request,PaginatorInterface $paginator, ComplainantRepository $repository)
    {
       $pagination=$paginator->paginate(
               $repository->findWith($request->query->get("q",null)),
               $request->query->get("page",1)
       );
       return $this->render("admin/complainant/index.html.twig",[
          "complainants"=>$pagination
       ]);
    }
    /**
     * @Route("/admin/complainant/list/{individual}/{condition}", name="admin_complainant_list")
     */
    public function list(Request $request,$individual=1,$condition=null, EntityManagerInterface $manager,
                         ComplainantRepository $complainantRepository, LegalRepository $legalRepository)
    {
        if($individual)
            $items=$condition?$complainantRepository->findByFio($condition,$individual):$complainantRepository->findAllOrderByFio($individual);
        else
            $items=$condition?$legalRepository->findByFio($condition):$legalRepository->findAllOrderByFio();
        return $this->json([
            "complainants"=>$items
        ],200,[],["groups"=>["main"]]);
    }
    /**
     * @Route("/admin/complainant/new", name="admin_complainant_new")
     */
    public function newComplainant(Request $request,EntityManagerInterface $manager, SerializerInterface $serializer,
                                   ComplainantTypeRepository $complainantTypeRepository,
                                   ResidenceRepository $residenceRepository, AddressObjectRepository $addressObjectRepository,
                                   OrganizationRepository $organizationRepository,
                                   ComplainantRepository $complainantRepository
                                   )
    {
        $complainant=new Complainant();
        $data=json_decode($request->getContent(),true);
        $complainant->setFio($data['fio']);
        $complainant->setType($complainantTypeRepository->findOneBy(["id"=>$data["individual"]?1:2]));

        if($data["address"]["flat"]["id"]!==null){
            $complainant->setAddress($residenceRepository->findOneBy(["id"=>$data["address"]["flat"]["id"]]));
            //NEED CHECK
            if($complainantRepository->RecordExists($complainant)){
                return $this->json(
                    ["resp"=>[
                        "complainant"=>null,
                        "status"=>Response::HTTP_FOUND
                    ]],Response::HTTP_FOUND
                );
            }
        }
        if(!$data["address"]["withFlat"] && $data["address"]["residence"]["id"]!==null) {
            $complainant->setAddress($residenceRepository->findOneBy(["id"=>$data["address"]["residence"]["id"]]));
            //NEED CHECK
            if($complainantRepository->RecordExists($complainant)){
                return $this->json(
                    ["resp"=>[
                        "complainant"=>null,
                        "status"=>Response::HTTP_FOUND
                    ]],Response::HTTP_FOUND
                );
            }
        }
        if($data["address"]["withFlat"] && $data["address"]["residence"]["id"]!==null && $data["address"]["flat"]["id"]===null) {
            $flat=new Residence($data["address"]["flat"]["name"]);
            $flat->setOwner($residenceRepository->findOneBy(["id"=>$data["address"]["residence"]["id"]]));
            $complainant->setAddress($flat);
        }
        if($data["address"]["residence"]["id"]===null){
            $residence=new Residence($data["address"]["residence"]["name"]);
            $residence->setParent($addressObjectRepository->findOneBy(["guid"=>$data["address"]["ao"]["guid"]]));
            $complainant->setAddress($residence);
            if($data["address"]["withFlat"]){
                $flat=new Residence($data["address"]["flat"]["name"]);
                $flat->setOwner($residence);
                $complainant->setAddress($flat);
            }
        }
        $manager->persist($complainant);

        if(!$data["individual"]){
            $legal=new Legal();
            $legal->setOrganization($organizationRepository->findOneBy(["id"=>$data["organization"]["id"]]));
            $legal->setPosition($data['position']);
            $legal->setComplainant($complainant);
            $manager->persist($legal);
            $manager->flush();

            return $this->json(["resp"=>[
                "complainant"=>$legal,
                "status"=>Response::HTTP_CREATED
            ]],201,[],["groups"=>["main"]]);
        }
        $manager->flush();

        return $this->json(["resp"=>[
            "complainant"=>$complainant,
            "status"=>Response::HTTP_CREATED
        ]],201,[],["groups"=>["main"]]);
    }
    /**
     * @Route("/admin/complainant/{id}/delete", methods={"DELETE"},name="admin_complainant_delete")
     */
    public function deleteComplainant(Complainant $complainant, EntityManagerInterface $manager, AppealRepository $appealRepository)
    {
        if(count($appealRepository->findBy(["complainant"=>$complainant]))>0)
            return $this->json(["status"=>Response::HTTP_CONFLICT],Response::HTTP_CONFLICT);
        $manager->remove($complainant);
        $manager->flush();
        return $this->json(["status"=>204],204);
    }
    /**
     * @Route("/admin/legal/{id}/delete", methods={"DELETE"},name="admin_legal_delete")
     */
    public function deleteLegal(Legal $legal,EntityManagerInterface $manager, AppealRepository $appealRepository)
    {
        if(count($appealRepository->findBy(["complainant"=>$legal->getComplainant()]))>0){
            return $this->json(["status"=>Response::HTTP_CONFLICT],Response::HTTP_CONFLICT);
        }
        $complainant=$legal->getComplainant();
        $manager->remove($legal);
        $manager->remove($complainant);
        $manager->flush();
        return $this->json(["status"=>204],204);
    }
    /**
     * @Route("/admin/complainant/{id}/edit", name="admin_complainant_edit")
     */
     public function editComplainant(Request $request, Complainant $complainant, EntityManagerInterface $manager)
     {
         $form=$this->createForm(ComplainantFormType::class,$complainant);
         $form->handleRequest($request);
         if($form->isSubmitted() && $form->isValid()){
             $manager->flush();
             $this->addFlash("success","common.saved");
         }
         return $this->render("admin/complainant/edit.html.twig",[
               "form"=>$form->createView(),
               "complainant"=>$complainant
         ]);
     }

}
