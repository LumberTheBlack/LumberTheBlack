<?php

namespace App\Controller;

use App\Entity\Answer;
use App\Repository\FileReferenceRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class AnswerController extends AbstractController
{
    /**
     * @Route("/answer/{id}/show", name="app_answer_show")
     */
    public function show(Request $request, Answer $answer, FileReferenceRepository $fileReferenceRepository)
    {
        return $this->render('answer/show.html.twig', [
            'answer' => $answer,
            'files'=>$fileReferenceRepository->findBy(["answer"=>$answer],["fileName"=>'ASC'])
        ]);
    }
}
