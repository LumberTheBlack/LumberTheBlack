<?php

namespace App\Controller;

use App\Repository\RefillRepository;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class RefillController extends AbstractController
{
    /**
     * @Route("/refill", name="refill")
     */
    public function index(Request $request,RefillRepository $refillRepository, PaginatorInterface $paginator)
    {
        $refills=$paginator->paginate(
            $request->query->has('q')&&$request->query->get("q")!=null?$refillRepository->findByOrderedByCreatedAt($request->query->get("q")):$refillRepository->findAllOrderedByCreatedAt(),
            $request->query->get("page",1)
            );
        $chartData=$refillRepository->findAllGroupByMonth(); 
        $chartData2=$refillRepository->findAllGroupByDepartment();
        $chartData3=$refillRepository->findAllGroupByOwner();
//        dd(array_column($chartData,"createdYearMonth")); 
        return $this->render('refill/index.html.twig', [
            'refills' => $refills,
            'data_x'=>json_encode(array_column($chartData,"createdYearMonth")),
            'data_y'=>json_encode(array_column($chartData,"summary")),
            'data2_x'=>json_encode(array_column($chartData2,"Department")),
            'data2_y'=>json_encode(array_column($chartData2,"summary")),
            'data3_x'=>json_encode(array_column($chartData3,"Employee")),
            'data3_y'=>json_encode(array_column($chartData3,"summary"))
        ]);
    }
}
