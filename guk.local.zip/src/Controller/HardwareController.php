<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\Request;
use App\Repository\HardwareRepository;


class HardwareController extends AbstractController
{
    /**
     * @Route("/hardware", name="hardware")
     */
    public function index(Request $request,HardwareRepository $hardwareRepository, PaginatorInterface $paginator)
    {
        $hardwares=$paginator->paginate(
            $hardwareRepository->findAll(),
            $request->query->get("page",1)
            );

        return $this->render('hardware/index.html.twig', [
            'hardwares' => $hardwares,
            'hardwaresGroupBy' =>[ "hardware.os"=>$hardwareRepository->getGroupBy("os","Version"),
                                   "hardware.cpuManufacturer"=>$hardwareRepository->getGroupBy("cpu"),
                                   "hardware.baseboardManufacturer"=>$hardwareRepository->getGroupBy("baseboard"),
                                   "hardware.memorySize"=>$hardwareRepository->getGroupBy("mem")
                                 ]
        ]);
    }
}
