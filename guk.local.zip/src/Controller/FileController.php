<?php

namespace App\Controller;

use App\Entity\FileReference;
use App\Service\UploaderHelper;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\HeaderUtils;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

class FileController extends AbstractController
{
    /**
     * @Route("/file/{id}/download", name="app_file_download", methods={"GET"})
     */
    public function downloadFile(Request $request, FileReference $fileRef)
    {
        //dump($this->getParameter('uploads_base_url').DIRECTORY_SEPARATOR.$fileRef->getFilePath());
        $response = new StreamedResponse(function() use ($fileRef) {
            $outputStream = fopen('php://output', 'wb');
//dd($this->getParameter('uploads_base_url').DIRECTORY_SEPARATOR.$fileRef->getFilePath());
            $fileStream = fopen($this->getParameter('uploads_base_url').DIRECTORY_SEPARATOR.$fileRef->getFilePath(),'rb');
            stream_copy_to_stream($fileStream, $outputStream);
        });
        $response->headers->set('Content-Type', $fileRef->getMimeType());
        // FORCING BROWSER TO DOWNLOAD FILE
        $disposition = HeaderUtils::makeDisposition(
            $request->query->has('inline')?HeaderUtils::DISPOSITION_INLINE:HeaderUtils::DISPOSITION_ATTACHMENT,
            $fileRef->getOriginalFilename()
        );
        $response->headers->set('Content-Disposition', $disposition);
        return $response;
    }
}
