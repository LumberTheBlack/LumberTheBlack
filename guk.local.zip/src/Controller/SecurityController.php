<?php

namespace App\Controller;

use App\Entity\User;
use App\Form\ChangePasswordFormType;
use App\Form\RegistrationFormType;
use App\Form\RoleType;
use App\Repository\UserRepository;
use App\Security\LoginFormAuthenticator;
use Doctrine\ORM\EntityManagerInterface;
use Knp\Component\Pager\PaginatorInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Symfony\Component\Security\Guard\GuardAuthenticatorHandler;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;

class SecurityController extends AbstractController
{
    /**
     * @Route("/login", name="app_login")
     */
    public function login(AuthenticationUtils $authenticationUtils): Response
    {
        // if ($this->getUser()) {
        //     return $this->redirectToRoute('target_path');
        // }

        // get the login error if there is one
        $error = $authenticationUtils->getLastAuthenticationError();
        // last username entered by the user
        $lastUsername = $authenticationUtils->getLastUsername();

        return $this->render('security/login.html.twig', ['last_username' => $lastUsername, 'error' => $error]);
    }

    /**
     * @Route("/logout", name="app_logout")
     */
    public function logout()
    {
        throw new \LogicException('This method can be blank - it will be intercepted by the logout key on your firewall.');
    }

    /**
     * @ROUTE("/security/management", name="security_management")
     * @IsGranted("ROLE_ADMIN")
     */
    public function manageUser(Request $request, UserRepository $userRepository, PaginatorInterface $paginator)
    {
        $qb=$userRepository->getAllUser();
        $paginated_users=$paginator->paginate(
            $qb,
            $request->query->get("page",1)
        );
        return $this->render("security/management.html.twig",[
            "users"=>$paginated_users
        ]);
    }

    /**
     * @param Request $request
     * @param EntityManagerInterface $manager
     * @ROUTE("/security/management/{id}/role/add", name="security_management_role_add")
     * @IsGranted("ROLE_ADMIN")
     */
    public function addRole(Request $request, User $user, EntityManagerInterface $manager)
    {
        $form=$this->createForm(RoleType::class,null,["roles"=>$user->getRoleMember()]);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $roles=$user->getRoles();
            $user->setRoles(explode(",",$form["role"]->getData()));
            $manager->persist($user);
            $manager->flush();
            $this->addFlash("success","security.User roles is updated");
            return $this->redirectToRoute("security_management");
        }
        return $this->render("security/managementRole.html.twig",[
            "form"=>$form->createView()
        ]);
    }

    /**
     * @param Request $request
     * @param User $user
     * @param EntityManagerInterface $manager
     * @return Response
     * @Route("/security/user/{id}/edit", name="security_user_edit")
     * @IsGranted("ROLE_ADMIN")
     */
    public function edit(Request $request, User $user, EntityManagerInterface $manager, UserPasswordEncoderInterface $passwordEncoder)
    {
        $form=$this->createForm(RegistrationFormType::class,$user);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $user->setPassword(
                $passwordEncoder->encodePassword(
                    $user,
                    $form->get('plainPassword')->getData()
                )
            );
            $manager->persist($user);
            $manager->flush();
            $this->addFlash("success","security.userSaved");
            return $this->redirectToRoute("security_management");
        }
        return $this->render("security/edit.html.twig",[
            "form"=>$form->createView()
        ]);
    }
    /**
     * @Route("/security/user/{id}/delete", name="security_user_delete")
     * @IsGranted("ROLE_ADMIN")
     */
    public function deleteUser(User $user, EntityManagerInterface $manager)
    {
        if($user->getAppeals()->count()>0){
            $this->addFlash("error","security.userHaveTaggedObject");
            return $this->redirectToRoute("security_management");
        }
        $manager->remove($user);
        $manager->flush();
        $this->addFlash("success","security.userRemoved");
        return $this->redirectToRoute("security_management");
    }
    /**
     * @ROUTE("/security/user/password/reset", name="security_user_password_reset")
     * @IsGranted("ROLE_USER")
     */
    public function resetUserPassword(Request $request,UserPasswordEncoderInterface $passwordEncoder)
    {
        $user=$this->getUser();
        $form=$this->createForm(ChangePasswordFormType::class,null,['notResetPassword'=>false]);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $user->setPassword($passwordEncoder->encodePassword($user,$form['plainPassword']->getData()));
            $em=$this->getDoctrine()->getManager();
            $em->flush();
            $this->addFlash("success","security.password_is_changed");
            return $this->redirectToRoute('app_appeal');
        }
        return $this->render('security/changePassword.html.twig',['form' => $form->createView()]);
    }
}
