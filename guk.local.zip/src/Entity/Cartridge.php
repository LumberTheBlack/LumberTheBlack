<?php

namespace App\Entity;

use App\Repository\CartridgeRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CartridgeRepository::class)
 */
class Cartridge
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $sn;

    /**
     * @ORM\ManyToOne(targetEntity=CartridgeModel::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $model;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSn(): ?string
    {
        return $this->sn;
    }

    public function setSn(string $sn): self
    {
        $this->sn = $sn;

        return $this;
    }

    public function getModel(): ?CartridgeModel
    {
        return $this->model;
    }

    public function setModel(?CartridgeModel $model): self
    {
        $this->model = $model;

        return $this;
    }
}
