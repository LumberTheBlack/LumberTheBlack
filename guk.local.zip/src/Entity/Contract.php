<?php

namespace App\Entity;

use App\Repository\ContractRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ContractRepository::class)
 */
class Contract
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $number;

    /**
     * @ORM\Column(type="date")
     */
    private $dDate;

    /**
     * @ORM\Column(type="text")
     */
    private $subject;

    /**
     * @ORM\Column(type="float")
     */
    private $summa;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $contragent;

    /**
     * @ORM\OneToMany(targetEntity=FileReference::class, mappedBy="contract")
     */
    private $images;

    /**
     * @ORM\ManyToOne(targetEntity=ContractSideType::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $sideType;

    public function __construct()
    {
        $this->images = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNumber(): ?string
    {
        return $this->number;
    }

    public function setNumber(string $number): self
    {
        $this->number = $number;

        return $this;
    }

    public function getDDate(): ?\DateTimeInterface
    {
        return $this->dDate;
    }

    public function setDDate(\DateTimeInterface $dDate): self
    {
        $this->dDate = $dDate;

        return $this;
    }

    public function getSubject(): ?string
    {
        return $this->subject;
    }

    public function setSubject(string $subject): self
    {
        $this->subject = $subject;

        return $this;
    }

    public function getSumma(): ?float
    {
        return $this->summa;
    }

    public function setSumma(float $summa): self
    {
        $this->summa = $summa;

        return $this;
    }

    public function getContragent(): ?string
    {
        return $this->contragent;
    }

    public function setContragent(string $contragent): self
    {
        $this->contragent = $contragent;

        return $this;
    }

    /**
     * @return Collection|FileReference[]
     */
    public function getImages(): Collection
    {
        return $this->images;
    }

    public function addImage(FileReference $image): self
    {
        if (!$this->images->contains($image)) {
            $this->images[] = $image;
            $image->setContract($this);
        }

        return $this;
    }

    public function removeImage(FileReference $image): self
    {
        if ($this->images->contains($image)) {
            $this->images->removeElement($image);
            // set the owning side to null (unless already changed)
            if ($image->getContract() === $this) {
                $image->setContract(null);
            }
        }

        return $this;
    }

    public function getSideType(): ?ContractSideType
    {
        return $this->sideType;
    }

    public function setSideType(?ContractSideType $sideType): self
    {
        $this->sideType = $sideType;

        return $this;
    }
}
