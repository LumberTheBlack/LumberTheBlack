<?php

namespace App\Entity;

use App\Repository\RefillRepository;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Timestampable\Traits\TimestampableEntity;

/**
 * @ORM\Entity(repositoryClass=RefillRepository::class)
 */
class Refill
{
    use TimestampableEntity;
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity=Cartridge::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $cartridge;

    /**
     * @ORM\Column(type="date", nullable=true)
     */
    private $refilledAt;

    /**
     * @ORM\ManyToOne(targetEntity=Employee::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $employee;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCartridge(): ?Cartridge
    {
        return $this->cartridge;
    }

    public function setCartridge(?Cartridge $cartridge): self
    {
        $this->cartridge = $cartridge;

        return $this;
    }

    public function getRefilledAt(): ?\DateTimeInterface
    {
        return $this->refilledAt;
    }

    public function setRefilledAt(?\DateTimeInterface $refilledAt): self
    {
        $this->refilledAt = $refilledAt;

        return $this;
    }

    public function getEmployee(): ?Employee
    {
        return $this->employee;
    }

    public function setEmployee(?Employee $employee): self
    {
        $this->employee = $employee;

        return $this;
    }
}
