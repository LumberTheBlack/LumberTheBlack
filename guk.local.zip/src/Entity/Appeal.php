<?php

namespace App\Entity;

use App\Repository\AppealRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Timestampable\Traits\TimestampableEntity;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=AppealRepository::class)
 */
class Appeal
{
    use TimestampableEntity;
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     * @Groups("main")
     */
    private $id;

    /**
     * @ORM\Column(type="date")
     * @Groups("main")
     */
    private $DataIn;

    /**
     * @ORM\Column(type="text", nullable=true)
     * @Groups("main")
     */
    private $content;

    /**
     * @ORM\ManyToOne(targetEntity=TypeOfAppeal::class)
     * @ORM\JoinColumn(nullable=false)
     * @Groups("main")
     */
    private $typeOfAppeal;

    /**
     * @ORM\ManyToOne(targetEntity=CharacterOfAppeal::class)
     * @ORM\JoinColumn(nullable=false)
     * @Groups("main")
     */
    private $characterOfAppeal;

    /**
     * @ORM\ManyToOne(targetEntity=FormOfAppeal::class)
     * @ORM\JoinColumn(nullable=false)
     * @Groups("main")
     */
    private $formOfAppeal;

    /**
     * @ORM\Column(type="date", nullable=true)
     * @Groups("main")
     */
    private $DateDoc;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     * @Groups("main")
     */
    private $initialNumber;

    /**
     * @ORM\ManyToOne(targetEntity=User::class)
     * @ORM\JoinColumn(nullable=false)
     * @Groups("main")
     */
    private $registrar;

    /**
     * @ORM\Column(type="integer")
     * @Groups("main")
     */
    private $executionTime;

    /**
     * @ORM\ManyToMany(targetEntity=User::class)
     * @Groups("main")
     */
    private $executors;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     * @Groups("main")
     */
    private $number;


    /**
     * @ORM\ManyToOne(targetEntity=Complainant::class)
     * @ORM\JoinColumn(nullable=false)
     * @Groups("main")
     */
    private $complainant;

    /**
     * @ORM\ManyToOne(targetEntity=Nomenclature::class)
     * @ORM\JoinColumn(nullable=false)
     * @Groups("main")
     */
    private $nomenclature;

    public function __construct()
    {
        $this->executors = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDataIn(): ?\DateTimeInterface
    {
        return $this->DataIn;
    }

    public function setDataIn(\DateTimeInterface $DataIn): self
    {
        $this->DataIn = $DataIn;

        return $this;
    }

    public function getContent(): ?string
    {
        return $this->content;
    }

    public function setContent(?string $content): self
    {
        $this->content = $content;

        return $this;
    }

    public function getTypeOfAppeal(): ?TypeOfAppeal
    {
        return $this->typeOfAppeal;
    }

    public function setTypeOfAppeal(?TypeOfAppeal $typeOfAppeal): self
    {
        $this->typeOfAppeal = $typeOfAppeal;

        return $this;
    }

    public function getCharacterOfAppeal(): ?CharacterOfAppeal
    {
        return $this->characterOfAppeal;
    }

    public function setCharacterOfAppeal(?CharacterOfAppeal $characterOfAppeal): self
    {
        $this->characterOfAppeal = $characterOfAppeal;

        return $this;
    }

    public function getFormOfAppeal(): ?FormOfAppeal
    {
        return $this->formOfAppeal;
    }

    public function setFormOfAppeal(?FormOfAppeal $formOfAppeal): self
    {
        $this->formOfAppeal = $formOfAppeal;

        return $this;
    }

    public function getDateDoc(): ?\DateTimeInterface
    {
        return $this->DateDoc;
    }

    public function setDateDoc(\DateTimeInterface $DateDoc): self
    {
        $this->DateDoc = $DateDoc;

        return $this;
    }

    public function getInitialNumber(): ?string
    {
        return $this->initialNumber;
    }

    public function setInitialNumber(string $initialNumber): self
    {
        $this->initialNumber = $initialNumber;

        return $this;
    }

    public function getRegistrar(): ?User
    {
        return $this->registrar;
    }

    public function setRegistrar(?User $registrar): self
    {
        $this->registrar = $registrar;

        return $this;
    }

    public function getExecutionTime(): ?int
    {
        return $this->executionTime;
    }

    public function setExecutionTime(int $executionTime): self
    {
        $this->executionTime = $executionTime;

        return $this;
    }

    /**
     * @return Collection|User[]
     */
    public function getExecutors(): Collection
    {
        return $this->executors;
    }

    public function addExecutor(User $executor): self
    {
        if (!$this->executors->contains($executor)) {
            $this->executors[] = $executor;
        }

        return $this;
    }

    public function removeExecutor(User $executor): self
    {
        if ($this->executors->contains($executor)) {
            $this->executors->removeElement($executor);
        }

        return $this;
    }

    public function getNumber(): ?string
    {
        return $this->number?$this->number:($this->getNomenclature()->getIndexDoc()."/".$this->getId().'/1');
    }

    public function setNumber(string $number): self
    {
        $this->number = $number;

        return $this;
    }


    public function getComplainant(): ?Complainant
    {
        return $this->complainant;
    }

    public function setComplainant(?Complainant $complainant): self
    {
        $this->complainant = $complainant;

        return $this;
    }

    public function getNomenclature(): ?Nomenclature
    {
        return $this->nomenclature;
    }

    public function setNomenclature(?Nomenclature $nomenclature): self
    {
        $this->nomenclature = $nomenclature;

        return $this;
    }
}
