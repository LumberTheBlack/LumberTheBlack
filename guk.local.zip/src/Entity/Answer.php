<?php

namespace App\Entity;

use App\Repository\AnswerRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Timestampable\Traits\TimestampableEntity;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=AnswerRepository::class)
 */
class Answer
{
    use TimestampableEntity;
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     * @Groups("main")
     */
    private $id;

    /**
     * @ORM\Column(type="text", nullable=true)
     * @Groups("main")
     */
    private $content;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     * @Groups("main")
     */
    private $number;

    /**
     * @ORM\Column(type="date")
     * @Groups("main")
     */
    private $answerDate;

      /**
     * @ORM\ManyToOne(targetEntity=Appeal::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $appeal;

    /**
     * @ORM\ManyToOne(targetEntity=User::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $Registrar;


    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $returnAt;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $approveAt;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getContent(): ?string
    {
        return $this->content;
    }

    public function setContent(?string $content): self
    {
        $this->content = $content;

        return $this;
    }

    public function getNumber(): ?string
    {
        return $this->number?$this->number:($this->getAppeal()->getNumber()."/".$this->getId());
    }

    public function setNumber(string $number): self
    {
        $this->number = $number;

        return $this;
    }

    public function getAnswerDate(): ?\DateTimeInterface
    {
        return $this->answerDate;
    }

    public function setAnswerDate(\DateTimeInterface $answerDate): self
    {
        $this->answerDate = $answerDate;

        return $this;
    }

    public function getAppeal(): ?Appeal
    {
        return $this->appeal;
    }

    public function setAppeal(?Appeal $appeal): self
    {
        $this->appeal = $appeal;

        return $this;
    }

    public function getRegistrar(): ?User
    {
        return $this->Registrar;
    }

    public function setRegistrar(?User $Registrar): self
    {
        $this->Registrar = $Registrar;

        return $this;
    }

    public function getReturnAt(): ?\DateTimeInterface
    {
        return $this->returnAt;
    }

    public function setReturnAt(\DateTimeInterface $returnAt=null): self
    {
        $this->returnAt = $returnAt;

        return $this;
    }

    public function getApproveAt(): ?\DateTimeInterface
    {
        return $this->approveAt;
    }

    public function setApproveAt(?\DateTimeInterface $approveAt=null): self
    {
        $this->approveAt = $approveAt;

        return $this;
    }

    public function isApproved()
    {
        return $this->approveAt!=null?($this->returnAt!=null?$this->approveAt>$this->returnAt:true):false;
    }

    public function isReturned()
    {
        return $this->returnAt!=null?($this->approveAt!=null?$this->returnAt>$this->approveAt:true):false;
    }

    public function isReviewed()
    {
        return $this->approveAt==null && $this->returnAt==null;
    }
}
