<?php

namespace App\Entity;

use App\Repository\NomenclatureRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=NomenclatureRepository::class)
 * @UniqueEntity(
 *     fields={"name"},
 *     message="nomenclature.alreadyexists"
 *     )
 */
class Nomenclature
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     * @Groups("main")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups("main")
     */
    private $indexDoc;

    /**
     * @ORM\Column(type="text", unique=true)
     * @Groups("main")
     */
    private $name;

    /**
     * @ORM\Column(type="text")
     */
    private $term;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $note;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getIndexDoc(): ?string
    {
        return $this->indexDoc;
    }

    public function setIndexDoc(string $indexDoc): self
    {
        $this->indexDoc = $indexDoc;

        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getTerm(): ?string
    {
        return $this->term;
    }

    public function setTerm(string $term): self
    {
        $this->term = $term;

        return $this;
    }

    public function getNote(): ?string
    {
        return $this->note;
    }

    public function setNote(?string $note): self
    {
        $this->note = $note;

        return $this;
    }


    public function __toString()
    {
        // TODO: Implement __toString() method.
        return $this->getIndexDoc()." [".$this->getName()."]";
    }
}
