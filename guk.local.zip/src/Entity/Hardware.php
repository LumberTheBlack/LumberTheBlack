<?php

namespace App\Entity;

use App\Repository\HardwareRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=HardwareRepository::class)
 */
class Hardware
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $host;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $ip;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $mac;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $cpu;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $mem;

    /**
     * @ORM\Column(type="text")
     */
    private $disks;

    /**
     * @ORM\Column(type="text")
     */
    private $bios;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $os;

    /**
     * @ORM\Column(type="text")
     */
    private $baseboard;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getHost(): ?string
    {
        return $this->host;
    }

    public function setHost(string $host): self
    {
        $this->host = $host;

        return $this;
    }

    public function getIp(): ?string
    {
        return $this->ip;
    }

    public function setIp(string $ip): self
    {
        $this->ip = $ip;

        return $this;
    }

    public function getMac(): ?string
    {
        return $this->mac;
    }

    public function setMac(string $mac): self
    {
        $this->mac = $mac;

        return $this;
    }

    public function getCpu(): ?string
    {
        return $this->cpu;
    }

    public function setCpu(string $cpu): self
    {
        $this->cpu = $cpu;

        return $this;
    }

    public function getMem(): ?string
    {
        return $this->mem;
    }

    public function setMem(string $mem): self
    {
        $this->mem = $mem;

        return $this;
    }

    public function getDisks(): ?string
    {
        return $this->disks;
    }

    public function setDisks(string $disks): self
    {
        $this->disks = $disks;

        return $this;
    }

    public function getBios(): ?string
    {
        return $this->bios;
    }

    public function setBios(string $bios): self
    {
        $this->bios = $bios;

        return $this;
    }

    public function getOs(): ?string
    {
        return $this->os;
    }

    public function setOs(string $os): self
    {
        $this->os = $os;

        return $this;
    }

    public function getBaseboard(): ?string
    {
        return $this->baseboard;
    }

    public function setBaseboard(string $baseboard): self
    {
        $this->baseboard = $baseboard;

        return $this;
    }
}
