<?php

namespace App\Entity;

use App\Repository\LegalRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=LegalRepository::class)
 */
class Legal
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     * @Groups("main")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity=Complainant::class, cascade={"persist"})
     * @ORM\JoinColumn(nullable=false)
     * @Groups("main")
     */
    private $complainant;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups("main")
     */
    private $position;

    /**
     * @ORM\ManyToOne(targetEntity=Organization::class, inversedBy="legals")
     * @ORM\JoinColumn(nullable=false)
     * @Groups("main")
     */
    private $organization;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getComplainant(): ?Complainant
    {
        return $this->complainant;
    }

    public function setComplainant(?Complainant $complainant): self
    {
        $this->complainant = $complainant;

        return $this;
    }

    public function getPosition(): ?string
    {
        return $this->position;
    }

    public function setPosition(string $position): self
    {
        $this->position = $position;

        return $this;
    }

    public function getOrganization(): ?Organization
    {
        return $this->organization;
    }

    public function setOrganization(?Organization $organization): self
    {
        $this->organization = $organization;

        return $this;
    }
}
