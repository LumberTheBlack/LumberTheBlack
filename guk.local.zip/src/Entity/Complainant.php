<?php

namespace App\Entity;

use App\Repository\ComplainantRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=ComplainantRepository::class)
 */
class Complainant
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     * @Groups({"main","appeal"})
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups({"main","appeal"})
     */
    private $fio;

    /**
     * @ORM\ManyToOne(targetEntity=Residence::class,cascade={"persist"})
     * @ORM\JoinColumn(nullable=false)
     * @Groups("main")
     */
    private $address;
    /**
     * @ORM\ManyToOne(targetEntity=ComplainantType::class)
     * @ORM\JoinColumn(nullable=false)
     * @Groups("main")
     */
    private $type;
    private $addressPresentation;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getFio(): ?string
    {
        return $this->fio;
    }

    public function setFio(string $fio): self
    {
        $this->fio = $fio;

        return $this;
    }

    public function getAddress(): ?Residence
    {
        return $this->address;
    }
    public function setAddress(?Residence $address): self
    {
        $this->address = $address;

        return $this;
    }

    public function getType(): ?ComplainantType
    {
        return $this->type;
    }

    public function setType(?ComplainantType $type): self
    {
        $this->type = $type;

        return $this;
    }

    public function __toString()
    {
        // TODO: Implement __toString() method.
        return $this->getFio();
    }

    public function isIndividual(){
        return $this->getType()->getId()===1;
    }
}
