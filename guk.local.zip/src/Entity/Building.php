<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;


/**
 * @ORM\Entity(repositoryClass="App\Repository\BuildingRepository")
 */
class Building
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     * @Groups("main")
     */
    private $id;

    /**
     * @ORM\Column(type="integer")
     */
    private $pid;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Outside")
     * @ORM\JoinColumn(nullable=false)
     */
    private $outside;

    /**
     * @ORM\Column(type="integer")
     */
    private $number;
    /**
     * @Groups("main")
     */
    private $name;

    /**
     * @ORM\Column(type="string", length=2, nullable=true)
     */
    private $litera;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\BuildingType")
     * @ORM\JoinColumn(nullable=false)
     */
    private $type;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPid(): ?int
    {
        return $this->pid;
    }

    public function setPid(int $pid): self
    {
        $this->pid = $pid;

        return $this;
    }

    public function getOutside(): ?Outside
    {
        return $this->outside;
    }

    public function setOutside(?Outside $outside): self
    {
        $this->outside = $outside;

        return $this;
    }

    public function getNumber(): ?int
    {
        return $this->number;
    }

    public function setNumber(int $number): self
    {
        $this->number = $number;

        return $this;
    }

    public function getLitera(): ?string
    {
        return $this->litera;
    }

    public function setLitera(?string $litera): self
    {
        $this->litera = $litera;

        return $this;
    }

    public function getType(): ?BuildingType
    {
        return $this->type;
    }

    public function setType(?BuildingType $type): self
    {
        $this->type = $type;

        return $this;
    }
    public function getName()
    {
        return $this->getOutside()->getName()." {$this->getOutside()->getType()->getName()}, ".$this->getNumber().$this->getLitera();
    }
}
