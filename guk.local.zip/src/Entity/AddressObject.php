<?php

namespace App\Entity;

use App\Repository\AddressObjectRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=AddressObjectRepository::class)
 * @ORM\Table(name="address_objects",uniqueConstraints={@ORM\UniqueConstraint(name="guid_idx", columns={"guid"})})

 */
class AddressObject
{
    /**
     * //@ORM\Id()
     * //@ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Id()
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\Column(type="guid")
     * @Groups("main")
     */
    private $guid;

    /**
     * //ORM\Column(type="guid")
     * @ORM\ManyToOne(targetEntity="AddressObject")
     * @ORM\JoinColumn(name="parent_guid", referencedColumnName="guid")
     * @Groups("main")
     */
    private $parentGuid;

    /**
     * @ORM\Column(type="guid")
     */
    private $parentGuidMun;

    /**
     * @ORM\Column(type="integer")
     * @Groups("main")
     */
    private $aoLevel;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $code;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups("main")
     */
    private $shortName;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups("main")
     */
    private $formalName;

    /**
     * @ORM\Column(type="guid")
     */
    private $aoGuid;



    public function getId(): ?int
    {
        return $this->id;
    }


    public function getGuid(): ?string
    {
        return $this->guid;
    }

    public function setGuid(string $guid): self
    {
        $this->guid = $guid;

        return $this;
    }

    public function getParentGuid(): ?AddressObject
    {
        return $this->parentGuid;
    }



    public function getParentGuidMun(): ?string
    {
        return $this->parentGuidMun;
    }

    public function setParentGuidMun(string $parentGuidMun): self
    {
        $this->parentGuidMun = $parentGuidMun;

        return $this;
    }

    public function getAoLevel(): ?int
    {
        return $this->aoLevel;
    }

    public function setAoLevel(int $aoLevel): self
    {
        $this->aoLevel = $aoLevel;

        return $this;
    }

    public function getCode(): ?string
    {
        return $this->code;
    }

    public function setCode(?string $code): self
    {
        $this->code = $code;

        return $this;
    }

    public function getShortName(): ?string
    {
        return $this->shortName;
    }

    public function setShortName(string $shortName): self
    {
        $this->shortName = $shortName;

        return $this;
    }

    public function getFormalName(): ?string
    {
        return $this->formalName;
    }

    public function setFormalName(string $formalName): self
    {
        $this->formalName = $formalName;

        return $this;
    }

    public function getAoGuid(): ?string
    {
        return $this->aoGuid;
    }

    public function setAoGuid(string $aoGuid): self
    {
        $this->aoGuid = $aoGuid;

        return $this;
    }
}
