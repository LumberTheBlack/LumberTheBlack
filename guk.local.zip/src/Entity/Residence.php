<?php

namespace App\Entity;

use App\Repository\ResidenceRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=ResidenceRepository::class)
 */
class Residence
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     * @Groups("main")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity=AddressObject::class)
     * @ORM\JoinColumn(referencedColumnName="guid")
     * @Groups("main")
     */
    private $parent;

    /**
     * @ORM\ManyToOne(targetEntity=Residence::class, cascade={"persist"})
     * @Groups("main")
     */
    private $owner;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups("main")
     */
    private $name;

    public function __construct(string $name)
    {
        $this->name=$name;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getParent(): ?AddressObject
    {
        return $this->parent;
    }

    public function setParent(?AddressObject $parent): self
    {
        $this->parent = $parent;

        return $this;
    }

    public function getOwner(): ?self
    {
        return $this->owner;
    }

    public function setOwner(?self $owner): self
    {
        $this->owner = $owner;

        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }
    function recurs_addr(AddressObject $ao){
        if($ao->getParentGuid())
            return $this->recurs_addr($ao->getParentGuid()).", ".$ao->getFormalName()." ".$ao->getShortName();
        return $ao->getFormalName()." ".$ao->getShortName();
    }

    public function __toString()
    {
        $ao=$this->getOwner()!==null?$this->getOwner()->getParent():$this->getParent();
        return $this->recurs_addr($ao)." №".($this->getOwner()!==null?$this->getOwner()->getName().", пом.".$this->getName():$this->getName());
    }
}
