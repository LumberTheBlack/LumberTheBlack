<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\BalanceRepository")
 */
class Balance
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="float")
     */
    private $saldo;

    /**
     * @ORM\OneToOne(targetEntity="App\Entity\PersonalAccount", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $personalAccount;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSaldo(): ?float
    {
        return $this->saldo;
    }

    public function setSaldo(float $saldo): self
    {
        $this->saldo = $saldo;

        return $this;
    }

    public function getPersonalAccount(): ?PersonalAccount
    {
        return $this->personalAccount;
    }

    public function setPersonalAccount(PersonalAccount $personalAccount): self
    {
        $this->personalAccount = $personalAccount;

        return $this;
    }
}
