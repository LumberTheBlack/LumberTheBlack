<?php

namespace App\Entity;

use App\Repository\OrganizationRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=OrganizationRepository::class)
 */
class Organization
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     * @Groups("main")
     */
    private $id;

    /**
     * @ORM\Column(type="string", unique=true, length=255)
     * @Groups("main")
     */
    private $name;

    /**
     * @ORM\OneToMany(targetEntity=Legal::class, mappedBy="organization")
     */
    private $legals;

    public function __construct(string $name)
    {
        $this->legals = new ArrayCollection();
        $this->name=$name;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    /**
     * @return Collection|Legal[]
     */
    public function getLegals(): Collection
    {
        return $this->legals;
    }

    public function addLegal(Legal $legal): self
    {
        if (!$this->legals->contains($legal)) {
            $this->legals[] = $legal;
            $legal->setOrganization($this);
        }

        return $this;
    }

    public function removeLegal(Legal $legal): self
    {
        if ($this->legals->contains($legal)) {
            $this->legals->removeElement($legal);
            // set the owning side to null (unless already changed)
            if ($legal->getOrganization() === $this) {
                $legal->setOrganization(null);
            }
        }

        return $this;
    }
    public function __toString()
    {
        return $this->getName();
    }
}
