<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass="App\Repository\FileReferenceRepository")
 */
class FileReference
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     * @Groups({"main","identifier"})
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups("main")
     *
     */
    private $fileName;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups("main")
     */
    private $originalFileName;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $path;

    /**
     * @ORM\Column(type="integer")
     * @Groups("main")
     */
    private $size;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $mimeType;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     * @Groups({"main"})
     */
    private $createdAt;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     * @Groups({"main"})
     */
    private $caption;

    /**
     * @ORM\ManyToOne(targetEntity=Answer::class)
     */
    private $answer;

    /**
     * @ORM\ManyToOne(targetEntity=Appeal::class)
     */
    private $appeal;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Post", inversedBy="media", cascade={"persist"})
     */
    private $post;

    /**
     * @ORM\ManyToOne(targetEntity=Contract::class, inversedBy="images")
     */
    private $contract;

    /**
     * @ORM\ManyToOne(targetEntity=Act::class, inversedBy="images")
     */
    private $act;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getFileName(): ?string
    {
        return $this->fileName;
    }

    public function setFileName(string $fileName): self
    {
        $this->fileName = $fileName;

        return $this;
    }

    public function getOriginalFileName(): ?string
    {
        return $this->originalFileName;
    }

    public function setOriginalFileName(string $originalFileName): self
    {
        $this->originalFileName = $originalFileName;

        return $this;
    }

    public function getPath(): ?string
    {
        return $this->path;
    }

    public function setPath(?string $path): self
    {
        $this->path = $path;

        return $this;
    }

    public function getSize(): ?int
    {
        return $this->size;
    }

    public function setSize(int $size): self
    {
        $this->size = $size;

        return $this;
    }

    public function getMimeType(): ?string
    {
        return $this->mimeType;
    }

    public function setMimeType(string $mimeType): self
    {
        $this->mimeType = $mimeType;

        return $this;
    }

    public function getFilePath()
    {
        return $this->getPath().DIRECTORY_SEPARATOR.$this->getFileName();
    }

    public function setCreatedAt(\DateTime $createdAt)
    {
        $this->createdAt=$createdAt;
        return $this;
    }
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    public function getCaption(): ?string
    {
        return $this->caption?$this->caption:$this->originalFileName;
    }

    /**
     * @param null|string $caption
     * @return FileReference
     */
    public function setCaption(?string $caption): self
    {
        $this->caption = $caption;

        return $this;
    }

    public function getAnswer(): ?Answer
    {
        return $this->answer;
    }

    public function setAnswer(?Answer $answer): self
    {
        $this->answer = $answer;

        return $this;
    }

    public function getAppeal(): ?Appeal
    {
        return $this->appeal;
    }

    public function setAppeal(?Appeal $appeal): self
    {
        $this->appeal = $appeal;

        return $this;
    }
    public function getPost(): ?Post
    {
        return $this->post;
    }

    public function setPost(?Post $post): self
    {
        $this->post = $post;

        return $this;
    }

    public function getContract(): ?Contract
    {
        return $this->contract;
    }

    public function setContract(?Contract $contract): self
    {
        $this->contract = $contract;

        return $this;
    }

    public function getAct(): ?Act
    {
        return $this->act;
    }

    public function setAct(?Act $act): self
    {
        $this->act = $act;

        return $this;
    }

}
