<?php
namespace App\Security;

use App\Entity\Answer;
use App\Entity\User;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Authorization\Voter\Voter;

class AnswerVoter extends Voter
{
    // these strings are just invented: you can use anything
    const VIEW = 'view';
    const EDIT = 'edit';

    protected function supports(string $attribute, $subject)
    {
        // if the attribute isn't one we support, return false
        if (!in_array($attribute, [self::VIEW, self::EDIT])) {
            return false;
        }

        // only vote on `Post` objects
        if (!$subject instanceof Answer) {
            return false;
        }

        return true;
    }

    protected function voteOnAttribute(string $attribute, $subject, TokenInterface $token)
    {
        $user = $token->getUser();

        if (!$user instanceof User) {
            // the user must be logged in; if not, deny access
            return false;
        }

        // you know $subject is a Post object, thanks to `supports()`
        /** @var Answer $answer */
        $answer = $subject;

        switch ($attribute) {
            case self::VIEW:
                return $this->canView($answer, $user);
            case self::EDIT:
                return $this->canEdit($answer, $user);
        }

        throw new \LogicException('This code should not be reached!');
    }

    private function canView(Answer $answer, User $user)
    {
        return true;
    }

    private function canEdit(Answer $answer, User $user)
    {
        return $user === $answer->getRegistrar();
    }
}