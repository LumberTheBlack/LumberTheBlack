<?php
/**
 * Created by PhpStorm.
 * User: udin
 * Date: 08.04.2020
 * Time: 8:26
 */

namespace App\Service;


use App\Entity\FileReference;
use App\Entity\Post;
use App\Entity\Contract;
use App\Entity\Act;
use Container5ixa70h\getTypeOfAppealRepositoryService;
use Doctrine\ORM\EntityManagerInterface;
use Gedmo\Sluggable\Util\Urlizer;
use Symfony\Component\Asset\Context\RequestStackContext;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class UploaderHelper
{
    const UPLOADS_PATH="uploads";
    const GALLERY_IMAGE_PATH="gallery";

    /**
     * @var string
     */
    private $uploadPath;
    private $subFolder;
    /**
     * @var RequestStackContext
     */
    private $requestStackContext;
    /**
     * @var EntityManagerInterface
     */
    private $em;

    public function __construct(string $uploadPath, RequestStackContext $requestStackContext, EntityManagerInterface $em)
    {
        $this->uploadPath = $uploadPath;
        $this->subFolder=date("Y").DIRECTORY_SEPARATOR.date('m').DIRECTORY_SEPARATOR.date('d');
        $this->requestStackContext = $requestStackContext;
        $this->em = $em;
    }

    public function uploadFile(UploadedFile $file,$prefix=null,$owner=null)
    {
        $destination=$this->uploadPath.($prefix?$prefix:"").DIRECTORY_SEPARATOR.$this->subFolder;
        $originalFileName=transliterator_transliterate('Any-Latin; Latin-ASCII; Lower()',pathinfo($file->getClientOriginalName(),PATHINFO_FILENAME));
        $newFileName=Urlizer::urlize($originalFileName,'-').'-'.uniqid().'.'.$file->guessExtension();
        $mimeType=$file->getMimeType(); $fileSize=$file->getSize();
        $originalFileName.=".".$file->guessExtension();
        $file->move(
            $destination,
            $newFileName);
        $fileReference=new FileReference();
        $fileReference->setFileName($newFileName);
        $fileReference->setOriginalFileName($originalFileName);
        $fileReference->setMimeType($mimeType);
        $fileReference->setPath($this->subFolder);
        $fileReference->setSize($fileSize);
        if($owner!=null){
          if($owner instanceOf Post)  
             $fileReference->setPost($owner);
          if($owner instanceOf Contract)  
             $fileReference->setContract($owner);
          if($owner instanceOf Act)  
             $fileReference->setAct($owner);
        }
        $this->em->persist($fileReference);
        $this->em->flush($fileReference);
        $this->em->clear();
        return $fileReference;
     }

    public function uploadGalleryImage(UploadedFile $file)
    {
        return $this->uploadFile($file,self::GALLERY_IMAGE_PATH);
     }

    public function getSubFolder():string
    {
        return $this->subFolder;
     }

    public function getPublicPath(string $path): string
    {
       return $this->requestStackContext->getBasePath().DIRECTORY_SEPARATOR.self::UPLOADS_PATH.DIRECTORY_SEPARATOR.$path;
     }

    /**
     * @param FileReference $fileReference
     * @return string
     */
    public function deleteUploadedFile($fileReference)
    {
        $this->em->remove($fileReference);
        $this->em->flush();

        $fs=new Filesystem();
        $file=$this->uploadPath.DIRECTORY_SEPARATOR.$fileReference->getFilePath();
        try{
            $fs->remove($file);
            return $file." removed success";
        }catch(IOExceptionInterface $exception){
            return "Failed to remove file ". $exception->getPath();
        }
     }
}