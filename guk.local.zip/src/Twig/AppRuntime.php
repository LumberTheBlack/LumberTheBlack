<?php
/**
 * Created by PhpStorm.
 * User: udin
 * Date: 08.04.2020
 * Time: 11:05
 */

namespace App\Twig;


use App\Entity\AddressObject;
use App\Entity\Answer;
use App\Entity\Appeal;
use App\Entity\Complainant;
use App\Repository\AnswerRepository;
use App\Service\UploaderHelper;
use Symfony\Component\Validator\Constraints\Date;
use Twig\Extension\RuntimeExtensionInterface;

class AppRuntime implements RuntimeExtensionInterface
{
    /**
     * @var UploaderHelper
     */
    private $uploaderHelper;
    private $residence;

    public function __construct(UploaderHelper $uploaderHelper)
    {
        $this->uploaderHelper = $uploaderHelper;
    }

    public function getUploadedPath($path)
    {
        return $this->uploaderHelper->getPublicPath($path);
    }
    function recurs_addr(AddressObject $ao){
        if($ao->getParentGuid())
            return $this->recurs_addr($ao->getParentGuid()).", ".$ao->getFormalName()." ".$ao->getShortName();
        return $ao->getFormalName()." ".$ao->getShortName();
    }
    public function getFullAddress(Complainant $complainant){
        $address=$complainant->getAddress();
        $ao=$address->getOwner()!==null?$address->getOwner()->getParent():$address->getParent();
        return $this->recurs_addr($ao)." №".($address->getOwner()!==null?$address->getOwner()->getName().", пом.".$address->getName():$address->getName());
    }

    public function warningTerm(\DateTime $date, int $executionTime=30, \DateTime $compareWith=null)
    {
        if(!$compareWith)$compareWith=new \DateTime();
        $datePlusExecutionTime=clone $date; $datePlusExecutionTime->add(new \DateInterval('P'.$executionTime.'D'));
        $diffInDays=date_diff($compareWith,$datePlusExecutionTime)->days;
        return $compareWith>$datePlusExecutionTime?(-1*$diffInDays):$diffInDays;
    }
}