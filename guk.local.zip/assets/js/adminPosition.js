import React from 'react';
import {render} from 'react-dom';
import Position from "./components/position";

$(document).ready(function(){
    render(
        <Position/>,
        document.getElementById("position")
    );
});