import React from 'react';
import {render} from 'react-dom';
import Tags from './Tags';
import '../css/post.css';

$(document).ready(function(){
    const stringTags=$('.js-tags-data').val();
    var tags=render(
        <Tags
            tags={''!==stringTags?stringTags.split(','):[]}
            maxTags={4}
        />,
        document.getElementById('post_tags_container')
    );
    $('form').on('submit',function(e){
       var tagsData=$('.js-tags-data');
       tagsData.val(tags.state.tags);
    });
});

