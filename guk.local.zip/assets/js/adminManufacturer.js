import React from 'react';
import {render} from "react-dom";
import Manufacturer from "./components/Manufacturer";

$(document).ready(function(){
    render(
        <Manufacturer/>,
        document.getElementById("manufacturer")
    );
});