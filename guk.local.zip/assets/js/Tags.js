import React,{Component} from 'react';
import TagsInput from 'react-tagsinput';
import Autosuggest from 'react-autosuggest';
import { defaultTheme } from 'react-autosuggest/dist/theme';
import {getTags} from './api_tag/tag_api';

 var tagSuggestions=[];

export default class Tags extends Component{
    constructor(props){
        super(props);
        this.state={
            tags: this.props.tags?this.props.tags:[],
            suggestions:[]
        };
        this.handleChange=this.handleChange.bind(this);
    }
    componentDidMount(){
        getTags().then((data)=>{
            this.setState({
                suggestions:data?data:[]
            });
        });
    }
    handleChange(tags){
        this.setState({tags: tags});
    }
    render(){
        tagSuggestions=this.state.suggestions;
        function autocompleteRenderInput ({addTag, ...props}) {
            const handleOnChange = (e, {newValue, method}) => {
                if (method === 'enter') {
                    e.preventDefault()
                } else {
                    props.onChange(e);
                }
            };

            const inputValue = (props.value && props.value.trim().toLowerCase()) || '';
            const inputLength = inputValue.length;
            let suggestions = tagSuggestions.filter((tag)=>{
                return tag.name.toLowerCase().slice(0,inputLength)===inputValue;
            });

            return (
                <Autosuggest
                    ref={props.ref}
                    suggestions={suggestions}
                    shouldRenderSuggestions={(value) => value && value.trim().length > 0}
                    getSuggestionValue={(suggestion) => suggestion.name}
                    renderSuggestion={(suggestion) => <span>{suggestion.name}</span>}
                    inputProps={{...props, onChange: handleOnChange}}
                    onSuggestionSelected={(e, {suggestion}) => {
                        addTag(suggestion.name)
                    }}
                    onSuggestionsClearRequested={() => {}}
                    onSuggestionsFetchRequested={() => {}}
                    theme={defaultTheme}
                />
            );
        }
        return(
            <TagsInput
                renderInput={autocompleteRenderInput}
                value={this.state.tags}
                onChange={this.handleChange}
                inputProps={ {className: 'react-tagsinput-input', placeholder:'+ тег'} }
                onlyUnique={true}
            />
        );
    }
}