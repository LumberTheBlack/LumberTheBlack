import React from 'react';
import {render} from 'react-dom';
import Employee from "./components/Employee";

$(document).ready(function(){
    render(
       <Employee/>,
        document.getElementById("employee")
    );
});