import bsCustomFileInput from 'bs-custom-file-input';

$(document).ready(
    function(){
        bsCustomFileInput.init();
    }
);
