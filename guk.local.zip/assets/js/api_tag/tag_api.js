export function getTags(value){
    return fetchJson('/admin/tag/api/search').then(
        (data)=>{return data.tags}
    );
}
function fetchJson(url, options) {
    return fetch(url,
        Object.assign({credentials: 'same-origin',    }, options)
    )
        .then(response => {              //return response.json() - if return empty response gens error
            return response.text()
                .then(text=>text?JSON.parse(text):'');     //// decode JSON, but avoid problems with empty responses
        });
}