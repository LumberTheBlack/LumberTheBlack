import React from 'react';
import {render} from 'react-dom';
import Cartridge from "./components/Cartridge";

$(document).ready(function(){
    render(
       <Cartridge/>,
        document.getElementById("cartridge")
    );
});