import React from 'react';
import {render} from 'react-dom';

import Refill from './components/Refill';

$(document).ready(function(){
    render(
        <Refill/>,
        document.getElementById("refill")
    );
});