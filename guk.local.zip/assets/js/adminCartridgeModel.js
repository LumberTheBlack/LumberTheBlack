import React from 'react';
import {render} from 'react-dom';
import CartridgeModel from "./components/CartridgeModel";

$(document).ready(function(){
    render(
       <CartridgeModel/>,
        document.getElementById("cartridge-model")
    );
});