import React from 'react';
import {render} from 'react-dom';
import ChartJsComponent from './components/ChartJsComponent';

$(document).ready(function(){
    $('.chart_js').each(function(){
      render(
            <ChartJsComponent
               data_x={$(this).data("x")}
               data_y={$(this).data("y")}
               label={$(this).data("label")}
               title={$(this).data("title")}
               bg_color={$(this).data("bg_color")}
               chartType={$(this).data("chart_type")}
            />,
            $(this)[0]
      );
   });
});