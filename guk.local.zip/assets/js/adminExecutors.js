import React from 'react';
import {render} from 'react-dom';
import ExecutorsForm from "./components/ExecutorsForm";

$(document).ready(function(){
    const appeal=$("#executors-container").data("appeal");
    render(
        <ExecutorsForm
            appeal={appeal}
        />,
        document.getElementById("executors-container")
    );
});