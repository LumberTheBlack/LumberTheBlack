import React from 'react';
import {render} from "react-dom";
import Printer from "./components/Printer";

$(document).ready(function(){
    render(
        <Printer/>,
        document.getElementById("printer")
    );
});