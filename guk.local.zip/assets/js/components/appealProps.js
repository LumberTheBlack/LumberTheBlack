import React,{Component} from 'react';
import {saveAppealProp,createAppealProps, getAppealProps, deleteAppealProps} from '../api/appeal_api';
import AppealPropsForm from "./appealPropsForm";
import FlashMessage from "./FlashMessage";

export default class AppealProps extends Component{
    constructor(props){
        super(props);
        this.state={
            appealProps:[],
            focused: null,
            isLoaded: false,
            isSaving: false,
            statusMessage:{message:'', status:'success'}
        };

        this.handleFocused=this.handleFocused.bind(this);
        this.addAppealPropsItem=this.addAppealPropsItem.bind(this);
        this.handleDeleteItem=this.handleDeleteItem.bind(this);
        this.setMessage=this.setMessage.bind(this);
        this.editAppealProps=this.editAppealProps.bind(this);
    }
    componentDidMount(){
        getAppealProps(this.props.appealPropsType)
            .then((data)=>{
                this.setState({
                    appealProps: data?data:[],
                    isLoaded: true,
                });
            });
    }
    handleFocused(apItem){
        this.setState((prevState)=>{
           return {focused: apItem};
        });
    }
    addAppealPropsItem(name){
        this.setState({isSaving:true});
        createAppealProps(this.props.appealPropsType,{name: name}).then(
            (data)=>{
                this.setState(prevState=>{
                    const items=[...prevState.appealProps,data.new_appeal_props_item];
                    return {appealProps: items, isSaving:false};
                });
                this.setMessage("Запись успешно сохранена.");
            }
        );
    }
    editAppealProps(editItem){
        saveAppealProp(this.props.appealPropsType,editItem).then(
              (data)=>{
                   this.setState((prevState=>{
                        prevState.appealProps.map((apItem)=>{
                             if(apItem.id===editItem.id)apItem.name=editItem.name;
                             return apItem;
                        });
                        return {appealProps: prevState.appealProps, focused:null};
                   }));
                   this.setMessage("Запись успешно обновлена.");
              }
        );   
    }
    handleDeleteItem(event,aProps){
          if(!confirm('Уверены, что это нужно удалить?')) return;
          deleteAppealProps(this.props.appealPropsType,aProps.id).then(
              ()=>{
                  this.setState((prevState)=>{
                      return {
                          appealProps: prevState.appealProps.filter(item=>item.id!==aProps.id)
                      };
                  });
              }
          );
          this.setMessage('Запись успешно удалена.')
    }
    setMessage(message="",status="success"){
        this.setState({
            statusMessage: {message:message, status:status}
        });
    }

    render(){
        const appealPropsItems=this.state.appealProps.map(
            (aProps)=>{
                return(
                  <div className="d-flex" key={aProps.id}>
                    <div className={"p-2 border-top border-success flex-grow-1"+(this.state.focused && this.state.focused.id===aProps.id?' text-white bg-success':' text-success')}
                        onClick={(event)=>{this.handleFocused(aProps)}}
                        >
                          {aProps.name}
                      </div>
                      <button className="btn fas fa-trash text-danger" onClick={(event)=>{this.handleDeleteItem(event,aProps)}}>
                      </button>
                  </div>
                );
            }
        );
        if(!this.state.isLoaded)
            return(
                <div>
                    <i className={"fa fa-spinner fa-pulse"}></i> Загружаем сведения...
                </div>);
        return(
            <div className="shadow rounded p-2">
                <AppealPropsForm
                    key={this.state.focused?this.state.focused.id:999999}
                    appealProperty={this.state.focused}
                    addAppealProps={this.addAppealPropsItem}
                    editAppealProps={this.editAppealProps}
                />
                 {appealPropsItems}

                 {this.state.statusMessage.message && (
                    <FlashMessage
                        statusMessage={this.state.statusMessage}
                        clearMessage={this.setMessage}
                    />
                  )}
            </div>
        );
    }

}