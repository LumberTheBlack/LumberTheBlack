import React,{Component} from 'react';
import DatePicker from 'react-datetime';
import moment from 'moment';
import ComplainantListForm from './ComplainantListForm';
import AppealPropsInput from "./appealPropsInput";
import NomenclatureInput from "./nomenclatureInput";
import FileReferenceList from './fileList';
import Portal from './Portal';
import {createAppeal, getAppealById, saveAppeal} from "../api/appeal_api";

export default class AppealForm extends Component{
    constructor(props){
        super(props);
        this.state={
            id:props.appeal?props.appeal:null,
            complainant:null,
            dateIn: new Date(),
            typeOfAppeal:null,
            characterOfAppeal:null,
            formOfAppeal:null,
            dateDoc: new Date(),
            initialNumber:"",
            executionTime: 30,
            nomenclature:null,
            number:"",
            files:[],
            content:'',
            isLoading:true,
            isSubmitted:false
        };
        this.handleSelectComplainant=this.handleSelectComplainant.bind(this);
        this.handleChangeDateIn=this.handleChangeDateIn.bind(this);
        this.handleSetAppealProps=this.handleSetAppealProps.bind(this);
        this.handleChangeDateDoc=this.handleChangeDateDoc.bind(this);
        this.handleChangeInitialNumber=this.handleChangeInitialNumber.bind(this);
        this.handleChangeExecutionTime=this.handleChangeExecutionTime.bind(this);
        this.handleSetNomenclature=this.handleSetNomenclature.bind(this);
        this.handleSetFiles=this.handleSetFiles.bind(this);
        this.handleChangeContent=this.handleChangeContent.bind(this);
        this.isSaveButtonEnabled=this.isSaveButtonEnabled.bind(this);
        this.handleSubmit=this.handleSubmit.bind(this);
    }
    componentDidMount(){
        if(this.state.id)getAppealById(this.state.id).then(data=>{
            const appeal=data.appeal;
            this.setState({
                complainant:appeal.complainant,
                dateIn:moment(appeal.DataIn),
                typeOfAppeal:appeal.typeOfAppeal,
                characterOfAppeal:appeal.characterOfAppeal,
                formOfAppeal:appeal.formOfAppeal,
                dateDoc: appeal.DateDoc?moment(appeal.DateDoc):new Date(),
                initialNumber:appeal.initialNumber?appeal.initialNumber:"",
                executionTime: appeal.executionTime,
                nomenclature:appeal.nomenclature,
                number:appeal.number,
                files:data.files.length>0?data.files:[],
                content:appeal.content,
                isLoading:false
            });
        })
        else this.setState({isLoading:false});
    }
    handleSelectComplainant(complainant){
        this.setState({
            complainant:complainant
        });
    }
    handleChangeDateIn(date){
        this.setState({
            dateIn:date
        });
    }
    handleChangeDateDoc(date){
        this.setState({
            dateDoc:date
        });
    }
    handleSetAppealProps(apType,value){
        this.setState(()=>{
            if(apType=="TypeOfAppeal")
                return{typeOfAppeal:value};
            if(apType=="CharacterOfAppeal")
                return{characterOfAppeal:value};
            return{formOfAppeal:value};
        });
    }
    handleChangeInitialNumber(event){
        this.setState({
            initialNumber:event.target.value
        });
    }
    handleChangeExecutionTime(event){
        this.setState({
            executionTime:parseInt(event.target.value)
        });
    }
    handleSetNomenclature(value){
        this.setState(prevState=>{
          return {
            nomenclature:value,
            number:prevState.id?value.indexDoc+"/"+prevState.id+"/1":""
          }
        });
    }
    handleSetFiles(files){
        this.setState({
            files:files
        });
    }
    handleChangeContent(event){
        this.setState({
            content:event.target.value
        });
    }
    isSaveButtonEnabled(){
        const {individual}=this.props;
        const {
            complainant,
            typeOfAppeal,
            characterOfAppeal,
            formOfAppeal,
            initialNumber,
            nomenclature,
            content,
            executionTime,
            isSubmitted
        }=this.state;
        var enabled=(
            complainant!==null &&
            typeOfAppeal!==null &&
            characterOfAppeal!==null &&
            formOfAppeal!==null &&
            nomenclature!==null &&
            content!=='' &&
            !isNaN(executionTime)
        );
            if(!individual)
             enabled=enabled && initialNumber!=="";
        return enabled && !isSubmitted;
    }
    handleChangeNumber(event){
        this.setState({
            number:event.target.value
        });
    }
    handleSubmit(event){
        event.preventDefault();
        this.setState({isSubmitted:true});
        var appeal=this.state;
        if(appeal.id===null) {
            delete appeal.id;
            createAppeal(this.state).then(data => {
                // console.log({RESPONSE:data.appeal});
                window.location.href = "/appeal";
            });
        }else saveAppeal(this.state).then(data => {
            window.location.href="/appeal/"+appeal.id+"/show";
        });
    }
    render(){
        const {individual,complainant_parent}=this.props;
        const {id,isLoading}=this.state;
        const maxSize=5242880;
        //console.log({STATE:this.state});
        return(
          <div>
              {isLoading && (<span><i className={"fas fa-spinner fa-spin"}></i> Загружаем ...</span>)}
              {!isLoading  &&(<div>
                <div className={"d-flex"}>
                       <input type={"text"}
                           value={this.state.complainant!==null?this.state.complainant.fio:""}
                           placeholder={"Укажите заявителя"}
                           readOnly={true}
                           className={"form-control mr-auto"}
                       />
                       <ComplainantListForm
                        parent={complainant_parent}
                        setComplainant={this.handleSelectComplainant}
                        individual={individual}
                       />
                </div>
                <form onSubmit={(event)=>{this.handleSubmit(event)}}>
                    <label>
                        <p><strong>Дата поступления обращения</strong></p>
                        <DatePicker
                            onChange={this.handleChangeDateIn}
                            value={this.state.dateIn}
                            locale={"ru-RU"}
                            dateFormat={"DD.MM.YYYY"}
                            timeFormat={false}
                        />
                    </label>
                    <AppealPropsInput
                        appealPropsType={"TypeOfAppeal"}
                        placeholder={"вид обращения"}
                        setAppealProps={this.handleSetAppealProps}
                        defaultValue={this.state.typeOfAppeal}
                    />
                    <AppealPropsInput
                        appealPropsType={"CharacterOfAppeal"}
                        placeholder={"характер обращения"}
                        setAppealProps={this.handleSetAppealProps}
                        defaultValue={this.state.characterOfAppeal}
                    />
                    <AppealPropsInput
                        appealPropsType={"FormOfAppeal"}
                        placeholder={"форму обращения"}
                        setAppealProps={this.handleSetAppealProps}
                        defaultValue={this.state.formOfAppeal}
                    />
                    {!individual && (
                        <div className={"d-flex"}>
                            <label>
                                <p><strong>Дата документа</strong></p>
                                <DatePicker
                                    onChange={this.handleChangeDateDoc}
                                    value={this.state.dateDoc}
                                    locale={"ru-RU"}
                                    dateFormat={"DD.MM.YYYY"}
                                    timeFormat={false}
                                />
                            </label>
                            <label>
                                <p><strong>Исходящий номер документа</strong></p>
                                <input
                                    type={"text"}
                                    className={"form-control"}
                                    value={this.state.initialNumber}
                                    onChange={event=>{this.handleChangeInitialNumber(event)}}
                                />
                            </label>
                        </div>
                    )}
                    <div className={"d-flex"}>
                    <label>
                        <p><strong>Срок исполнения, в днях</strong></p>
                        <input
                            className={"form-control"}
                            placeholder={"Срок исполнения, в днях"}
                            type={"number"}
                            min={"0"}
                            value={this.state.executionTime}
                            onChange={(event)=>{this.handleChangeExecutionTime(event)}}
                        />
                    </label>
                    </div>
                    <div className={"d-flex"}>
                    <label>
                        <p><strong>Номенклатура</strong></p>
                        <NomenclatureInput
                            msg={"Выберите номенклатуру"}
                            setNomenclature={this.handleSetNomenclature}
                            defaultValue={this.state.nomenclature}
                        />
                    </label>
                   </div>
                   {id && (
                     <div>
                      <label>
                        <p><strong>Входящий номер</strong></p>
                        <input
                            type={"text"}
                            value={this.state.number}
                            onChange={(event)=>{this.handleChangeNumber(event)}}
                        />
                      </label>
                     </div>
                   )}
                   <div>
                    <label>
                        <p><strong>Состав обращения (по сути, кратко)</strong></p>
                        <textarea
                            value={this.state.content}
                            onChange={(event)=>{this.handleChangeContent(event)}}
                            cols={"50"}
                            rows={"8"}
                        />
                    </label>
                   </div>
                    <Portal>
                    <FileReferenceList
                        postId={null}
                        setFiles={this.handleSetFiles}
                        defaultFiles={this.state.files}
                        initializeDropzone={this.props.initializeDropzone}
                    />
                    </Portal>
                    <div className={"d-flex justify-content-center mt-2"}>
                        <button
                            type={"submit"}
                            className={"btn btn-outline-primary fas fa-save"}
                            disabled={!this.isSaveButtonEnabled()}
                        >
                            Сохранить
                        </button>
                        <a
                            href={"/appeal"}
                            className={"btn btn-outline-secondary fas fa-close"}
                        >
                            Закрыть
                        </a>
                    </div>
                </form>
            </div>)}
          </div>
        );
    }
}
