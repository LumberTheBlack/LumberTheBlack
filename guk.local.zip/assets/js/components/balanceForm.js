import React,{Component} from 'react';
import {debounce} from "throttle-debounce";
import {getAddressObject} from "../api/address_object_api";
import Autosuggest from 'react-autosuggest';
import {getBalance, getBuildingByCondition} from "../api/balance_api";
const AutosuggestHighlightMatch=require('autosuggest-highlight/match');
const AutosuggestHighlightParse=require('autosuggest-highlight/parse');


function renderSuggestion(suggestion, { query }) {
    const matches = AutosuggestHighlightMatch(suggestion.name, query);
    const parts = AutosuggestHighlightParse(suggestion.name, matches);

    return (
        <span>
                {parts.map((part, index) => {
                    const className = part.highlight ? 'react-autosuggest__suggestion-match' : null;
                    return (
                        <span className={className} key={index}>
                            {part.text}
                        </span>
                    );
                })}
            </span>
    );
}
export default class BalanceForm extends Component{
    constructor(props){
        super(props);
        this.state={
            value:"",
            selected:null,
            suggestions:[],
            balances:[],
            isLoading: false
        };
        this.changeQuery=this.changeQuery.bind(this);
        this.onSuggestionsClearRequested=this.onSuggestionsClearRequested.bind(this);
        this.onSuggestionsFetchRequested=debounce(2000,this.onSuggestionsFetchRequested.bind(this));
        this.getSuggestionValue=this.getSuggestionValue.bind(this);
        this.handleSubmit=this.handleSubmit.bind(this);
    }
    changeQuery(event,{newValue}){
        this.setState({ value: newValue});
    }
    onSuggestionsFetchRequested ({value,reason}){
        if(reason!=='input-changed') return;
        const {level,parent}=this.state;
        this.setState({
            isLoading:true,
            selected:null
        });

        getBuildingByCondition(value).then(data=>{
           // console.log(data.buildings);
            this.setState({
                suggestions:data.buildings,
                isLoading:false
            });}
        );
    }

    // Autosuggest will call this function every time you need to clear suggestions.
    onSuggestionsClearRequested(){
        this.setState({
            suggestions: []
        });
    }
    getSuggestionValue(suggestion){
        const publicValue=suggestion.name;
        this.setState({
            value:publicValue,
            selected:suggestion
        });
        return publicValue;
    }
    handleSubmit(event){
        event.preventDefault();
        this.setState({isLoading:true});
        getBalance(this.state.selected.id).then(data=>{
          this.setState({balances:data.balance,isLoading:false});
        });
    }
    render(){
        const {value,suggestions,isLoading,selected}=this.state;
        const inputProps = {
            placeholder: 'Начните набирать имя улицы или номер здания',
            value: value,
            onChange: this.changeQuery,
            className: 'form-control',
            disabled: isLoading
        };
        const balances=this.state.balances.map(balance=>{

            var array_fio=balance.personalAccount.owner.split(" ").map((chunk,index)=>{
                if(index<1)
                return "__"+chunk.substr(1);
                return chunk.substr(0,1)+".";
            });
            return(
                <tr key={balance.id}>
                    <td>{balance.personalAccount.room.name}</td>
                    <td>{balance.personalAccount.pid}</td>
                    <td>{balance.personalAccount.room.property.name}</td>
                    <td>{array_fio.join(" ")}</td>
                    <td><i className={balance.saldo>0?"text-danger fas fa-flag":"text-success"}> {balance.saldo}</i></td>
                </tr>
            );
        });
        return(
          <div>
            <form className="row" onSubmit={(event)=>{this.handleSubmit(event)}}>
                 <div className="col d-flex flex-row justify-content-between">
                   <div className="flex-fill"> 
                    <Autosuggest
                    key={"root"}
                    suggestions={suggestions}
                    inputProps={inputProps}
                    onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
                    onSuggestionsClearRequested={this.onSuggestionsClearRequested}
                    getSuggestionValue={this.getSuggestionValue}
                    renderSuggestion={renderSuggestion}
                    />
                   </div>
                    <button className="input-group-append btn btn-info fa fa-search" type={"submit"} disabled={selected===null}></button>
                </div>
            </form>
              {isLoading &&(
                  <span>
                      <i className="fa fa-spinner fa-spin"></i> Идет поиск...
                  </span>
              )}
              {balances && balances.length>0 && (
                  <table className={"table table-sm table-hover"}>
                      <tbody>
                      {balances}
                      </tbody>
                  </table>
              )}
          </div>
        );
    }
}