import React,{Component} from 'react';
import {getManufacturer, saveManufacturer, deleteManufacturer} from '../api/manufacturer_api';
import {confirmAlert} from "react-confirm-alert";
import {statusOk} from "../api/common";
import LoadingComponent from './LoadingComponent';

export default class Manufacturer extends Component{
    constructor(props){
        super(props);
        this.state={
            manufacturers:[],
            selected:null,
            isLoading:true,
            newManufacturer:"",
            statusMessage:{message:"", status:"success", duration: 4000}
        };
        this.setSelected=this.setSelected.bind(this);
        this.handleChange=this.handleChange.bind(this);
        this.saveManufacturer=this.saveManufacturer.bind(this);
        this.setConfirmYes=this.setConfirmYes.bind(this);
        this.deleteManufacturer=this.deleteManufacturer.bind(this);
        this.clearMessage=this.clearMessage.bind(this);
        this.setMessage=this.setMessage.bind(this);
    }
    componentDidMount(){
        getManufacturer().then(
            (data)=>{
                this.setState({
                    manufacturers: data.content.manufacturers,
                    isLoading: false
                });
            }
        );
    }
    setSelected(id){
        this.setState(prevState=>{
            return {
                selected:id,
                newManufacturer:prevState.manufacturers.find(manufacturer=>manufacturer.id==id).name
            };
        });
        if(this.props.onSelect)this.props.onSelect(this.state.manufacturers.find(manufacturer=>manufacturer.id==id));
    }
    setConfirmYes(yes){
        this.setState({
            confirmYes:yes
        });
    }
    handleChange(event){
        event.preventDefault();
        this.setState({
            newManufacturer:event.target.value
        });
    }
    deleteManufacturer(id){
        confirmAlert({
            title: 'Подтвердите действие',
            message: 'Вы уверены, что хотите удалить это?',
            buttons: [
                {
                    label: 'Да',
                    onClick: () => {
                        deleteManufacturer(id).then(
                           data=>{
                              if(data.status==204) {
                                  this.setState(prevState => {
                                      return {
                                          manufacturers: prevState.manufacturers.filter(manufacturer => manufacturer.id != id),
                                          selected: id == prevState.selected ? null : prevState.selected
                                      };
                                  });
                                  this.setMessage("Запись успешно удалена");
                              }else this.setMessage("Ошибка удаления - объект используется","danger");
                           }
                        );
                    }
                },
                {
                    label: 'Нет',
                    onClick: () => {}
                }
            ]
        });
    }
    saveManufacturer(event){
        const {selected,manufacturers,newManufacturer}=this.state;
        event.preventDefault();
        if(selected!=null){
          saveManufacturer({id:selected, name:newManufacturer}).then(
            data=>{
                if(statusOk(data.status)) {
                    this.setState(prevState => {
                        const manufacturers = prevState.manufacturers.filter(value => value.id != selected);
                        const manufacturer = data.content.manufacturer;
                        return {
                            manufacturers: [...manufacturers, manufacturer],
                            selected: null
                        };
                    });
                    this.setMessage("Запись успешно сохранена.");
                }else this.setMessage("Не удалось сохранить, код ошибки "+data.status,"danger");
            }
          );
        }else {
            saveManufacturer({name:newManufacturer}).then(
                data=>{
                    const manufacturer=data.content.manufacturer;
                   if(statusOk(data.status) && data.status!=302) {
                       this.setState(prevState => {
                           return {
                               manufacturers: [...prevState.manufacturers, manufacturer],
                               selected: null
                           };
                       });
                       this.setMessage("Запись успешно сохранена.");
                   }else this.setMessage("Не удалось сохранить, код ошибки "+data.status,"danger");
                }
            );
        }
    }
    render(){
        const {manufacturers,selected,isLoading,newManufacturer,statusMessage}=this.state;
        const manufacturerList=manufacturers.map((manufacturer)=>{
            return (
               <div key={manufacturer.id} className={"d-flex"}>
                   <div
                       className={"flex-fill border-0 list-group-item"+(manufacturer.id==selected?" active":"")}
                       onClick={event=>this.setSelected(manufacturer.id)}
                   >
                       {manufacturer.name}
                   </div>
                   <button className={"ml-auto btn btn-sm fa fa-trash text-danger"} onClick={event=>this.deleteManufacturer(manufacturer.id)}></button>
               </div>
            );
        });
        return(
            <LoadingComponent isLoading={isLoading} statusMessage={statusMessage} clearMessage={this.clearMessage}>
                <h1>Производители орг. техники</h1>

                <div className="input-group">
                    <input
                        type={"text"}
                        className="form-control"
                        value={newManufacturer}
                        onChange={(event)=>{this.handleChange(event)}}
                    />
                    <button
                        className={"btn btn-secondary fa fa-save input-group-append"}
                        onClick={(event)=>{this.saveManufacturer(event)}}
                    ></button>
                </div>
                <div className={"list-group"}>
                    {manufacturerList}
                </div>
            </LoadingComponent>
        );
    }
    setMessage(msg,status="success"){
        this.setState({
            statusMessage:{message:msg, status:status}
        });
    }
    clearMessage(){
        this.setState({
            statusMessage:{message:"", status:"success"}
        });
    }

}