import React,{Component} from 'react';
import {getDepartment, saveDepartment, deleteDepartment} from '../api/department_api';
import {confirmAlert} from "react-confirm-alert";
import {statusOk} from "../api/common";
import LoadingComponent from './LoadingComponent';

export default class Department extends Component{
    constructor(props){
        super(props);
        this.state={
            departments:[],
            selected:null,
            isLoading:true,
            newDepartment:"",
            confirmYes:false,
            statusMessage:{message:"", status:"success", duration: 4000}
        };
        this.setSelected=this.setSelected.bind(this);
        this.handleChange=this.handleChange.bind(this);
        this.saveDepartment=this.saveDepartment.bind(this);
        this.setConfirmYes=this.setConfirmYes.bind(this);
        this.deleteDepartment=this.deleteDepartment.bind(this);
        this.clearMessage=this.clearMessage.bind(this);
        this.setMessage=this.setMessage.bind(this);
    }
    componentDidMount(){
        getDepartment().then(
            (data)=>{
                this.setState({
                    departments: data.content.departments,
                    isLoading: false
                });
            }
        );
    }
    setSelected(id){
        this.setState(prevState=>{
            return {
                selected:id,
                newDepartment:prevState.departments.find(department=>department.id==id).name
            };
        });
        if(this.props.onSelect)this.props.onSelect(this.state.departments.find(department=>department.id==id));
    }
    setConfirmYes(yes){
        this.setState({
            confirmYes:yes
        });
    }
    handleChange(event){
        event.preventDefault();
        this.setState({
            newDepartment:event.target.value
        });
    }
    deleteDepartment(id){
        confirmAlert({
            title: 'Подтвердите действие',
            message: 'Вы уверены, что хотите удалить это?',
            buttons: [
                {
                    label: 'Да',
                    onClick: () => {
                        deleteDepartment(id).then(
                           data=>{
                              if(data.status==204) {
                                  this.setState(prevState => {
                                      return {
                                          departments: prevState.departments.filter(department => department.id != id),
                                          selected: id == prevState.selected ? null : prevState.selected
                                      };
                                  });
                                  this.setMessage("Запись успешно удалена");
                              }else this.setMessage("Ошибка удаления - объект используется","danger");
                           }
                        );
                    }
                },
                {
                    label: 'Нет',
                    onClick: () => {}
                }
            ]
        });
    }
    saveDepartment(event){
        const {selected,departments,newDepartment}=this.state;
        event.preventDefault();
        if(selected!=null){
          saveDepartment({id:selected, name:newDepartment}).then(
            data=>{
                if(statusOk(data.status)) {
                    this.setState(prevState => {
                        const departments = prevState.departments.filter(value => value.id != selected);
                        const department = data.content.department;
                        return {
                            departments: [...departments, department],
                            selected: null
                        };
                    });
                    this.setMessage("Запись успешно сохранена.");
                }else this.setMessage("Не удалось сохранить, код ошибки "+data.status,"danger");
            }
          );
        }else {
            saveDepartment({name:newDepartment}).then(
                data=>{
                    const department=data.content.department;
                   if(statusOk(data.status) && data.status!=302) {
                       this.setState(prevState => {
                           return {
                               departments: [...prevState.departments, department],
                               selected: null
                           };
                       });
                       this.setMessage("Запись успешно сохранена.");
                   }else this.setMessage("Не удалось сохранить, код ошибки "+data.status,"danger");
                }
            );
        }
    }
    render(){
        const {departments,selected,isLoading,newDepartment,statusMessage}=this.state;
        const departmentList=departments.map((department)=>{
            return (
               <div key={department.id} className={"d-flex"}>
                   <div
                       className={"flex-fill border-0 list-group-item"+(department.id==selected?" active":"")}
                       onClick={event=>this.setSelected(department.id)}
                   >
                       {department.name}
                   </div>
                   <button className={"ml-auto btn btn-sm fa fa-trash text-danger"} onClick={event=>this.deleteDepartment(department.id)}></button>
               </div>
            );
        });
        return(
            <LoadingComponent isLoading={isLoading} statusMessage={statusMessage} clearMessage={this.clearMessage}>
                <h1>Подразделения</h1>

                <div className="input-group">
                    <input
                        type={"text"}
                        className="form-control"
                        value={newDepartment}
                        onChange={(event)=>{this.handleChange(event)}}
                    />
                    <button
                        className={"btn btn-secondary fa fa-save input-group-append"}
                        onClick={(event)=>{this.saveDepartment(event)}}
                    ></button>
                </div>
                <div className={"list-group"}>
                    {departmentList}
                </div>
            </LoadingComponent>
        );
    }
    setMessage(msg,status="success"){
        this.setState({
            statusMessage:{message:msg, status:status}
        });
    }
    clearMessage(){
        this.setState({
            statusMessage:{message:"", status:"success"}
        });
    }

}