import React,{Component} from 'react'
import {getAppealProps} from "../api/appeal_api";

export default class AppealPropsInput extends Component{
    constructor(props){
        super(props);
        this.state={
            selectedValue:props.defaultValue?props.defaultValue.id:"",
            options:[],
            isLoading:true
        };
        this.handleChange=this.handleChange.bind(this);
    }
    componentDidMount(){
        const {appealPropsType}=this.props;
        getAppealProps(appealPropsType)
            .then((data)=>{
                this.setState({
                    options: data?data:[],
                    isLoading: false,
                    selectedValue:this.props.defaultValue?this.props.defaultValue.id:""
                });
            });
    }
    handleChange(event){
        const {appealPropsType}=this.props;
        const value=this.state.options.find(item=>item.id===+event.target.value);

        this.setState({
            selectedValue:value.id
        });
        this.props.setAppealProps(appealPropsType,value);
    }
    render(){
        const {isLoading,selectedValue}=this.state;
        const {placeholder}=this.props;
        const options=this.state.options.map(item=>{
            return(<option key={item.id} value={item.id}>{item.name}</option>);
        });
        const msg="Выберите "+placeholder;

        return(
            <div>
                <select
                    value={this.state.selectedValue} onChange={(event)=>{this.handleChange(event)}}
                    className={"form-control"}
                >
                    <option key={"placeholder"} value={""} disabled={true}>{msg}</option>
                    {options}
                </select>
                {isLoading && (<div><i className={"fas fa-spinner fa-spin"}></i> Загружаем...</div>)}
            </div>
        );
    }

}