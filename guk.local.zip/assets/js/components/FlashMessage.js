import React,{Component} from 'react';

export default class FlashMessage extends Component{
    constructor(props){
        super(props);
        this.MessageTimeoutHandle=0;
        this.state={
            isVisible:true
        };
        this.doClearTimeOut=this.doClearTimeOut.bind(this)
    }
    doClearTimeOut(){
        clearTimeout(this.MessageTimeoutHandle);
    }
    componentDidMount(){
        this.doClearTimeOut(this.MessageTimeoutHandle);

        this.MessageTimeoutHandle=setTimeout(()=>{
            this.setState({isVisible: false});
            if(this.props.clearMessage)this.props.clearMessage();
        }, this.props.duration?this.props.duration:3000);
    }
    componentWillUnmount(){
        this.doClearTimeOut();
    }

    render(){
       return(
         <div>
             {this.state.isVisible && (
                 <div className={"alert alert-"+this.props.statusMessage.status+" text-center"}>
                     {this.props.statusMessage.message}
                     </div>
             )}
         </div>
       );
    }
}