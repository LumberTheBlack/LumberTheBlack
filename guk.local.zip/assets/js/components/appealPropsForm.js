import React,{Component} from 'react';
import {createAppealProps} from "../api/appeal_api";

export default class AppealPropsForm extends Component{
    constructor(props){
        super(props);
        this.state={
            id: props.appealProperty?props.appealProperty.id:null,
            name: props.appealProperty?props.appealProperty.name:""
        };
        this.handleFormSubmit=this.handleFormSubmit.bind(this);
        this.handleAppealPropertyChange=this.handleAppealPropertyChange.bind(this);
    }
    handleFormSubmit(event){
        event.preventDefault();
        if(this.state.id===null){
         this.props.addAppealProps(this.state.name);
         this.setState({id: null, name:""});
        }else{
         this.props.editAppealProps({id:this.state.id,name:this.state.name});
        }
    }
    handleAppealPropertyChange(event){
        this.setState({
            name: event.target.value,
        });
    }
    render(){
        return(
            <form className="form-inline mb-2"
                  onSubmit={this.handleFormSubmit}>
                <input type="text"
                       className="form-control"
                       value={this.state.name}
                       onChange={this.handleAppealPropertyChange}
                />
                <button type="submit" className="btn btn-primary"><i className={"fa fa-save"}></i></button>
            </form>
        );
    }
}