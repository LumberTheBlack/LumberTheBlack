import React,{Component} from 'react';
import {getUsersNExecutors, saveExecutors} from "../api/executors_api";

export default class ExecutorsForm extends Component{
    constructor(props){
        super(props);
        this.state={
            executors:[],
            selected:[],
            isLoading:true
        };
        this.handleCheck=this.handleCheck.bind(this);
        this.handleSubmit=this.handleSubmit.bind(this);
    }
    componentDidMount(){
        getUsersNExecutors(this.props.appeal).then(data=>{
            this.setState({
                executors:data.users,
                selected:data.executors,
                isLoading: false,
                submitted: false
            });
        });
    }
    handleCheck(user){
        if(!this.state.submitted)
        this.setState(
            (prevState)=>{
                if(prevState.selected.some(item=>item.id===user.id))
                    return {
                    selected: prevState.selected.filter(selectedUser=>selectedUser.id!==user.id)
                    };
                else
                    return {
                      selected: [...prevState.selected,user]
                    };
            }
        );
    }
    handleSubmit(event){
        event.preventDefault();
        this.setState({
            submitted:true
        });
        saveExecutors(this.state.selected,this.props.appeal).then(data=>{
               window.location.href="/appeal/"+this.props.appeal+"/show";
            }
        );

    }
    render(){
        const {executors,selected,isLoading,submitted}=this.state;

        const users=executors.map(user=>{
            return(
                <tr key={user.id} onClick={(event)=>{this.handleCheck(user)}}>
                    <td className={"text-info fa fa-user"}><strong> {user.fio}</strong></td>
                    <td><input type="checkbox"
                           className="checkbox mx-2"
                           checked={selected.some(item=>item.id===user.id)}
                           disabled={submitted}
                    />
                    </td>
                </tr>
            );
        });
        return(
          <div>
            {isLoading && (<span><i className={"fa fa-spinner fa-spin"}></i> Загружаем...</span>)}
            {!isLoading &&(
               <form onSubmit={(event)=>{this.handleSubmit(event)}}>
                   <table className={"table table-borderless table-hover table-responsive"}>
                     <tbody>
                       {users}
                     </tbody>
                   </table>
                   <button type={"submit"} className={"btn btn-outline-info mx-auto"} disabled={submitted}>
                       {submitted && (<i className={"fa fa-spinner fa-spin"}></i>)} Сохранить
                   </button>
               </form>
            )}
          </div>
        );
    }
}