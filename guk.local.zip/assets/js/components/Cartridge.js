import React, {Component} from 'react';
import LoadingComponent from "./LoadingComponent";
import DialogModal from "./DialogModal";
import CartridgeModel from "./CartridgeModel";
import {getCartridges, saveCartridge, deleteCartridge} from "../api/cartridges_api";
import {statusOk} from "../api/common";
import {confirmAlert} from "react-confirm-alert";
import {debounce} from 'throttle-debounce';


export default class Cartridge extends Component{
    constructor(props){
        super(props);
        this.state={
            sn:"",
            model:null,
            cartridges:[],
            selected:null,
            isLoading: true,
            search:'',
            statusMessage:{message:"", status:"success", duration: 4000}
        };
        this.clearMessage=this.clearMessage.bind(this);
        this.setMessage=this.setMessage.bind(this);
        this.handleSelectCartridgeModel=this.handleSelectCartridgeModel.bind(this);
        this.handleSubmit=this.handleSubmit.bind(this);
        this.checkReady=this.checkReady.bind(this);
        this.handleChangeName=this.handleChangeName.bind(this);
        this.handleSelect=this.handleSelect.bind(this);
        this.handleDeleteCartridge=this.handleDeleteCartridge.bind(this);
        this.handleSearchSubmit=this.handleSearchSubmit.bind(this);
        this.handleSearchChange=this.handleSearchChange.bind(this);
    }
    componentDidMount(){
        getCartridges().then(data=>{
            const cartridges=data.content.cartridges;
            this.setState({
                cartridges:cartridges.length>0?cartridges:[],
                isLoading:false
            });
        });
    }
    render(){
        const {isLoading,statusMessage,cartridges,selected,sn,model,search}=this.state;
        const isReady=this.checkReady();
        const cartridgeList=cartridges.map(e=>{
            return(
                <div className={"d-flex"} key={e.id}>
                    <div
                        className={"p-1 cursor-pointer flex-fill"+(selected==e.id?" bg-primary text-white":"")}
                        onClick={event=>this.handleSelect(e.id)}
                    >
                        {e.sn} /{e.model.name} {e.model.printer.manufacturer.name}/
                    </div>
                    <button className={"ml-auto btn btn-sm fa fa-trash text-danger"} onClick={event=>this.handleDeleteCartridge(e.id)}></button>
                </div>
            );
        });

        return(
            <LoadingComponent isLoading={isLoading} statusMessage={statusMessage} clearMessage={this.clearMessage}>
                <h1>Картриджи</h1>
                <div className={"d-flex"}>
                    <input type={"text"}
                           className={"form-control"}
                           readOnly={true} placeholder={"модель картриджа"} value={model!=null?model.name:""}/>
                    <DialogModal
                        parent={this.props.parentDom?this.props.parentDom:"#cartridge"}
                        btnClass={"btn btn-secondary"}
                        btnLabel={"..."}
                        onSelect={this.handleSelectCartridgeModel}
                    >
                       <CartridgeModel parentDom={"#cartridge-model"} onSelect={this.handleSelectCartridgeModel}/>
                    </DialogModal>
                </div>
                <form className={"form"} onSubmit={(event)=>{this.handleSubmit(event)}}>
                    <input
                        className={"form-control"}
                        type={"text"}
                        value={sn}
                        onChange={(event)=>{this.handleChangeName(event)}}
                    />
                    <button type={"submit"} disabled={!isReady} className={"btn btn-outline-info"}> Сохранить</button>
                </form>
                    <input
                        className={"form-control fa fa-search"}
                        onChange={(event)=>{this.handleSearchChange(event)}}
                        onKeyDown={(event)=>{this.handleSearchSubmit(event)}}
                        value={search}
                        placeholder={"Найти..."}
                    />
                <div className={"mt-1"}>
                    {cartridgeList}
                </div>
            </LoadingComponent>
        );
    }
    handleSubmit(event){
        const {selected,sn,model}=this.state;

        event.preventDefault();
        saveCartridge(selected?{id:selected,sn:sn,model:model}:{sn:sn,model:model}).then(data=>{
            if(statusOk(data.status)&& data.status!=302){
                this.setState(prevState=>{
                    return{
                        cartridges: prevState.selected?[...prevState.cartridges.filter(e=>e.id!=prevState.selected),data.content.cartridge]:[...prevState.cartridges,data.content.cartridge],
                        selected: null
                    };
                });
                this.setMessage("Запись сохранена успешно");
            }else this.setMessage("Ошибка создания записи, код "+data.status,"danger");
        });
    }
    handleDeleteCartridge(id){
        confirmAlert({
            title: 'Подтвердите действие',
            message: 'Вы уверены, что хотите удалить это?',
            buttons: [
                {
                    label: 'Да',
                    onClick: () => {
                        deleteCartridge(id).then(data=>{
                            if(data.status==204){
                                this.setState(prevState=>{
                                    return{
                                        cartridges: prevState.cartridges.filter(e=>e.id!=id),
                                        selected: prevState.selected==id?null:prevState.selected
                                    }
                                });
                                this.setMessage("Запись успешно удалена");
                            }else this.setMessage("Ошибка удалениия записи, код "+data.status,"danger");
                        });
                    }
                },
                {
                    label: 'Нет',
                    onClick: () => {}
                }
            ]
        });
    }
    handleChangeName(event){
        this.setState({
            sn:event.target.value
        });
    }
    handleSelect(id){
        this.setState(prevState=>{
            const cartridge=prevState.cartridges.find(e=>e.id==id);

            return{
                selected:id,
                sn: cartridge.sn,
                model: cartridge.model
            };
        });
        if(this.props.onSelect)this.props.onSelect(this.state.cartridges.find(e=>e.id==id));
    }
    checkReady(){
        const {model, sn}=this.state;
        return model!=null && sn.length>0;
    }
    handleSelectCartridgeModel(model){
        this.setState({
            model:model
        });
    }
    setMessage(msg,status="success"){
        this.setState({
            statusMessage:{message:msg, status:status}
        });
    }
    clearMessage(){
        this.setState({
            statusMessage:{message:"", status:"success"}
        });
    }
    handleSearchSubmit(event){
        event.persist();
        const {search}=this.state;
        if(event.key!=='Enter') return;
        getCartridges(search).then(
            data=>{
                if(statusOk(data.status)){
                    this.setState({
                        cartridges:data.content.cartridges,

                    });
                }
            }
        );
    }
    handleSearchChange(event){
        this.setState({
            search:event.target.value
        });
    }
}