import React,{Component} from 'react';
import FlashMessage from './FlashMessage';
import ReactModal from 'react-modal';
import { deleteComplainant, getComplainant} from "../api/complainant_api";
import ComplainantForm from "./ComplainantForm";


export default class ComplainantListForm extends Component {
    constructor(props){
        super(props);
        ReactModal.setAppElement(props.parent);
        this.state={
            showModal:false,
            complainants:[],
            newComplainant:{},
            isLoading: false,
            focused:null,
            statusMessage:{message:"",status:"success"},
            search:'',
            isListMode:true
        };
        this.handleCloseModal=this.handleCloseModal.bind(this);
        this.handleOpenModal=this.handleOpenModal.bind(this);
        this.handleComplainantFocused=this.handleComplainantFocused.bind(this);
        this.handleChangeSearchCondition=this.handleChangeSearchCondition.bind(this);
        this.handleSubmitSearchCondition=this.handleSubmitSearchCondition.bind(this);
        this.handleSelect=this.handleSelect.bind(this);
        this.clearMessage=this.clearMessage.bind(this);
        this.setMessage=this.setMessage.bind(this);
        this.handleAddComplainant=this.handleAddComplainant.bind(this);
        this.addComplainant=this.addComplainant.bind(this);
        this.getComplainantDescription=this.getComplainantDescription.bind(this);
        this.getFullAddress=this.getFullAddress.bind(this);
    }

    handleOpenModal(){
        this.setState({
            isLoading: true
        });
        getComplainant(null,this.props.individual).then(
            (data)=>{
                //console.log({status:"DEBUG GET COMPLAINANTS",data:data});
                this.setState({
                    complainants: data,
                    isLoading: false
                });
            }
        );
        this.setState({
            showModal:true
        });
    }
    handleCloseModal(){
        this.setState({
            showModal:false,
            complainants:[],
            focused:null
        });
    }
    setMessage(msg,status="success"){
        this.setState({
            statusMessage:{message:msg, status:status}
        });
    }
    clearMessage(){
        this.setState({
            statusMessage:{message:"", status:"success"}
        });
    }
    handleChangeSearchCondition(event){
        this.setState({
            search: event.target.value
        });
    }
    handleSubmitSearchCondition(event){
        event.preventDefault();
        this.setState({isLoading:true});
        getComplainant(this.state.search,this.props.individual).then(
            data=>{
                this.setState({
                    complainants: data,
                    isLoading: false
                });
            }
        );
    }
    handleComplainantFocused(event,id){
        this.setState({
            focused: id
        });
    }
    handleDeleteComplainant(event,id){
        if(!confirm('Уверены, что это нужно удалить?')) return;
        const {individual}=this.props;
        deleteComplainant(id,individual).then(data=>{
            if(data.status===409)this.setMessage("Ошибка удаления - заявитель связан с другими объектами","danger");
            else{
                this.setState(prevState=>{
                    return {complainants:prevState.complainants.filter(complainant=>complainant.id!==id)};
                });
                this.setState({
                    focused: null
                });
                this.setMessage("Заявитель удален успешно.")
            }
        });
    }
    handleAddComplainant(event){
        this.setState({
            isListMode:false
        });
    }
    handleSelect(event){
        if(this.props.setComplainant){
            const {individual}=this.props;
            const object=this.state.complainants.filter(complainant=>complainant.id===this.state.focused)[0];
            this.props.setComplainant(individual?object:object.complainant);
        }
        this.handleCloseModal();
    }
    addComplainant(newComplainant){
        this.setState(prevState=>{
                  //const complainants=prevState.complainants;
                  //complainants.push(newComplainant);
                  return {
                    complainants:[...prevState.complainants,newComplainant]
                  };
            }
        );
        this.setMessage("Заявитель успешно добавлен");
    }
    getFullAddress(ao){
        if(ao.parentGuid)
            return this.getFullAddress(ao.parentGuid)+", "+ao.formalName+" "+ao.shortName;
        return ao.formalName+" "+ao.shortName;
    }
    getComplainantDescription(object){
        const complainant=this.props.individual?object:object.complainant;
        const ao=complainant.address.owner!==null?complainant.address.owner.parent:complainant.address.parent;
        var description=(!this.props.individual?object.organization.name+" / "+object.position:"");
        description=description+"  "+this.getFullAddress(ao);
        if(complainant.address.owner!==null)
            description=description+", "+complainant.address.owner.name+", помещение "+complainant.address.name;
        else
            description=description+", "+complainant.address.name;
        return description;
    }
    render(){
      //  console.log(this.state.complainants);
        const {individual}=this.props;
        const list=this.state.complainants.map((itemObj)=>{
            var item=individual?itemObj:itemObj.complainant;
            return (
                <div className={"d-flex"} key={item.id}>
                    <div
                        className={"list-group-item list-group-item-action"+(this.state.focused===itemObj.id?" active":"")}
                        onClick={(event)=>{this.handleComplainantFocused(event,itemObj.id)}}
                    >
                        {item.fio}
                        <small><strong>{" ("+this.getComplainantDescription(itemObj)+")"}</strong></small>
                    </div>
                    <button
                        className={"btn fa fa-trash text-danger"}
                        onClick={(event)=>{this.handleDeleteComplainant(event,itemObj.id)}}
                    />
                </div>);
        });
        return(
            <div>
                <button
                    onClick={this.handleOpenModal}
                    className={"btn btn-info"}
                >...</button>
                <ReactModal
                    isOpen={this.state.showModal}
                    contentLabel="onRequestClose Example"
                    onRequestClose={this.handleCloseModal}
                >
                   <div>
                    <h2>Заявители</h2>
                    <div>
                    <form className={"row align-items-center mx-1 mb-1"} onSubmit={(event)=>{this.handleSubmitSearchCondition(event)}}>
                        <input onChange={(event)=>{this.handleChangeSearchCondition(event)}}
                        name={"search"}
                        type={"text"}
                        className={"col px-auto"}
                        value={this.state.search}
                        />
                        <button type={"submit"} onClick={(event)=>{this.handleSubmitSearchCondition(event)}}
                        className={"margin-auto btn btn-info fa fa-search"}
                        disabled={this.state.search===""}
                        />
                    </form>
                   </div>
                       <ComplainantForm
                           parent={"#complainant_container"}
                           individual={individual}
                           handleAddComplainant={this.addComplainant}
                       />
                    {list.length===0 && !this.state.isLoading && <div><i>Ничео не найдено</i></div>}
                    {this.state.isLoading && <div><i className={"fas fa-spinner fa-spin"}></i> Идет поиск...</div>}

                    <div className="mb-2 overflow-auto height50vh list-group"> {list} </div>

                    <div className={"d-flex justify-content-center"}>
                        <button
                            className={"btn btn-primary"}
                            disabled={this.state.focused===null}
                            onClick={(event)=>{this.handleSelect(event)}}
                        >Выбрать</button>
                        <button className={"btn btn-secondary"} onClick={this.handleCloseModal}>Закрыть</button>

                    </div>
                   </div>

                   {this.state.statusMessage.message && (
                        <FlashMessage
                        duration={4000}
                        statusMessage={this.state.statusMessage}
                        clearMessage={this.clearMessage}
                        />
                   )}
                   </ReactModal>
            </div>
            );
    }
}