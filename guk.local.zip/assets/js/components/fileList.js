import React,{Component} from 'react';
import {getFileReferences,deleteFileReference,deleteSelectedFileReference,UpdateFileReference} from '../api/file_api';
import FileForm from "./fileForm";

export default class FileReferenceList extends Component{
    constructor(props){
        super(props);
        this.state= {
            files: props.defaultFiles && props.defaultFiles.length>0?props.defaultFiles.map(fileReference=>{
                    return Object.assign({},fileReference,{isSelected: true});
                }
            ):[],
            focused:null,
            successMessage: '',
            isLoaded:false,
            isAllFilesSelected: true,
        };
        this.props.initializeDropzone(this);
        this.handleAddFileReference=this.handleAddFileReference.bind(this);
        this.handleDeleteFileReference=this.handleDeleteFileReference.bind(this);
        this.toggleCheck=this.toggleCheck.bind(this);
        this.handleCheck=this.handleCheck.bind(this);
        this.handleDeleteSelectedFileReference=this.handleDeleteSelectedFileReference.bind(this);
        this.handleFocused=this.handleFocused.bind(this);
        this.handleUpdate=this.handleUpdate.bind(this);
    }
    componentDidMount(){
        if(!this.props.postId){
            this.setState({isLoaded:true})
            return;
        }
        getFileReferences(this.props.postId,this.props.postObject)
            .then((data)=>{
                this.setState({
                    files: data?data.map(fileReference=>{
                            return Object.assign({},fileReference,{isSelected: true});
                        }
                    ):[],
                    isLoaded: true,
                });
            });
    }
    handleAddFileReference(newFileReference){
        this.setState(
            prevState=>{
                const newFiles=[...prevState.files,Object.assign({},newFileReference,{isSelected: true})];
                if(this.props.setFiles)this.props.setFiles(newFiles);
                return {files: newFiles};
            }
        );
    }
    handleDeleteFileReference(fileReferenceId,event){
        if(!confirm('Уверены, что это нужно удалить?')) return;
        deleteFileReference(fileReferenceId).then(
            ()=>{
                this.setState(
                    (prevState)=>{
                        const focused=prevState.files.filter(fr=>fr.id===prevState.focused)[0];
                        const files=prevState.files.filter(fileReference=>fileReference.id!==fileReferenceId);
                        if(this.props.setFiles)this.props.setFiles(files);
                        return {
                            files:files,
                            focused: (focused && focused.id===fileReferenceId?null:prevState.focused)
                        };
                    }
                );
            }
        );

    }
    handleDeleteSelectedFileReference(event){
        if(!confirm('Уверены, что это нужно удалить?')) return;
        const files=this.state.files.filter(fileReference=>fileReference.isSelected).map(fileRef=>{
            return fileRef.id;
        });
        deleteSelectedFileReference(files).then(()=>{
             this.setState((prevState)=>{
                 const focused=prevState.files.filter(fr=>fr.id===prevState.focused)[0];
                 const newFiles=prevState.files.filter(fileReference=>!fileReference.isSelected);
                 if(this.props.setFiles)this.props.setFiles(newFiles);

                 return{
                     files: newFiles,
                     focused: (focused && focused.isSelected?null:prevState.focused)
                 };
             });
        });
    }
    toggleCheck(){
        this.setState(
            (prevState)=>{
                return {
                    isAllFilesSelected: !(prevState.isAllFilesSelected),
                    files: prevState.files.map(fileReference=>{
                        fileReference.isSelected=!prevState.isAllFilesSelected;
                        return fileReference;
                    })
                };
            }
        );
    }
    handleCheck(id){
       this.setState(
            (prevState)=>{
                return {
                  files: prevState.files.map(fileReference=>{
                     if(fileReference.id===id) fileReference.isSelected=!fileReference.isSelected;
                     return fileReference;
                  })
                };
            }
        );
    }
    handleFocused(id){
        this.setState({
                focused: id
        });
    }
    handleUpdate(fReference){
        UpdateFileReference(fReference).then(
            (fileReference)=>{
                this.setState((prevState)=>{
                   const newFiles=prevState.files.filter(fileRef=>fileRef.id!==fileReference.id);
                   newFiles.push(Object.assign({},fileReference,{isSelected: true}));
                    if(this.props.setFiles)this.props.setFiles(newFiles);

                    return {
                      files: newFiles
                  };
                });
            });
    }

    render(){
        const fileElements=this.state.files.map((fileReference)=>{
            return(
                <div className={this.state.focused===fileReference.id?"d-flex mb-3 justify-content-between align-items-center bg-light":"d-flex mb-3 justify-content-between align-items-center"}
                     key={fileReference.id}
                     onClick={(event)=>{this.handleFocused(fileReference.id)}}>
                    <div className="mr-auto p-2"><strong>{fileReference.caption}</strong> [{fileReference.size} байт]</div>
                    <div className="p-2">{(new Date(fileReference.createdAt)).toLocaleDateString()}</div>
                    <div className="p-2">
                        <button onClick={(event)=>{this.handleDeleteFileReference(fileReference.id,event)}}
                            className="btn btn-link">
                            <span className="fa fa-trash"></span>
                        </button>
                    </div>
                    <div className="p-2">
                        <input type="checkbox"
                               className="checkbox"
                               checked={fileReference.isSelected}
                               onChange={()=>{this.handleCheck(fileReference.id)}}
                        />
                    </div>
                 </div>
            );
        });
        if(!this.state.isLoaded)
         return(
             <span>
                     <i className="fas fa-spinner fa-spin"></i> Загрузка...
             </span>
         );
        if(fileElements.length===0)
          return(
              <span>
                <i className="fa fa-ban"></i> Нет прикрепленных файлов
            </span>
          );
        return (
            <div>
            <div className="d-flex justify-content-between align-items-center border-bottom border-primary">
                <div className="mr-auto p-2 text-primary">
                    {this.state.focused && (
                        <FileForm
                            key={this.state.focused}
                            OnUpdateFile={this.handleUpdate}
                            file={this.state.files.filter(fileReference=>fileReference.id===this.state.focused)[0]}
                        />
                    )}
                </div>
                <div className="p-2">
                    <button onClick={(event)=>{this.handleDeleteSelectedFileReference(event)}}
                            className="btn btn-link">
                            <span className="fa fa-trash"></span>
                    </button>
                </div>
                <div className="p-2">
                    <input type="checkbox"
                               className="checkbox"
                               id="allFiles"
                               checked={this.state.isAllFilesSelected}
                               onChange={()=>{this.toggleCheck()}}/>
                </div>
            </div>
              {fileElements}
          </div>
        );
    }
}