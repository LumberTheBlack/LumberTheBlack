import React,{Component} from 'react';

export default class FileForm extends Component{
    constructor(props){
        super(props);
        this.state={
            caption: props.file.caption,
            changed: false
        };
        this.handleChange=this.handleChange.bind(this);
        this.handleUpdate=this.handleUpdate.bind(this);
    }
    handleChange(event){
        const newCaption=event.target.value;
        this.setState(prevState=>{
            return {
                caption: newCaption,
                changed: this.props.file.caption.toLowerCase()!==newCaption.toLowerCase()
            };
        });
    }
    handleUpdate(event){
        event.preventDefault();
        this.props.file.caption=this.state.caption;
        this.props.OnUpdateFile(this.props.file);

    }
    render(){
        return(
            <div className="form-inline">
                <input type="text"
                       value={this.state.caption}
                       onChange={this.handleChange}
                />
                {this.state.changed && (
                    <button type="submit"
                            value="submit"
                        className="btn btn-link"
                            onClick={(event)=>{{this.handleUpdate(event)}}}
                    >
                        <i className="fa fa-save"></i>
                    </button>)
                }
            </div>
        );
    }
}