import moment from 'moment';
import React, {Component} from 'react';
import LoadingComponent from "./LoadingComponent";
import DialogModal from "./DialogModal";
import {getRefills, saveRefill, deleteRefill, toggleRefillStatus} from "../api/refill_api";
import {statusOk} from "../api/common";
import {confirmAlert} from "react-confirm-alert";
import Employee from "./Employee";
import Cartridge from "./Cartridge";


export default class Refill extends Component{
    constructor(props){
        super(props);
        this.state={
            employee:null,
            cartridge:null,
            refills:[],
            selected:null,
            isLoading: true,
            statusMessage:{message:"", status:"success", duration: 4000}
        };
        this.clearMessage=this.clearMessage.bind(this);
        this.setMessage=this.setMessage.bind(this);
        this.handleSelectCartridge=this.handleSelectCartridge.bind(this);
        this.handleSelectEmployee=this.handleSelectEmployee.bind(this);
        this.handleSubmit=this.handleSubmit.bind(this);
        this.checkReady=this.checkReady.bind(this);
        this.handleSelect=this.handleSelect.bind(this);
        this.handleDeleteRefill=this.handleDeleteRefill.bind(this);
        this.handleToggleRefillStatus=this.handleToggleRefillStatus.bind(this);
    }
    componentDidMount(){
        getRefills().then(data=>{
            const refills=data.content.refills;
            this.setState({
                refills:refills.length>0?refills:[],
                isLoading:false
            });
        });
    }
    render(){
        const {isLoading,statusMessage,refills,selected,cartridge,employee}=this.state;
        const isReady=this.checkReady();
        const refillList=refills.map(e=>{
            const d=new Date(e.createdAt);
            return(
                <div className={"d-flex align-items-center"} key={e.id}>
                    <div className={"d-flex flex-column align-items-center mr-2 p-2 text-light rounded-pill"+(e.refilledAt!=null?" bg-success":" bg-dark")}>
                        <span><strong>{moment(d).format("DD.MM.YYYY")}</strong></span>
                        <span><strong>{moment(d).format("hh:mm:ss")}</strong></span>
                    </div>
                    <div
                        className={"p-1 cursor-pointer flex-fill"+(selected==e.id?" bg-primary text-white":"")}
                        onClick={event=>this.handleSelect(e.id)}
                    >
                        {e.cartridge.sn} /{e.cartridge.model.name} {e.cartridge.model.printer.manufacturer.name}/ {e.employee.fio}
                        {e.refilledAt!=null && (<small className={"mx-1 badge badge-success fa fa-check"}><i>Заправлено {moment(e.refilledAt).format("DD.MM.YYYY")}</i></small>)}
                    </div>
                    <input type="checkbox"
                           className="checkbox mx-2"
                           checked={e.refilledAt!=null}
                           onChange={(event)=>{this.handleToggleRefillStatus(e.id)}}
                    />
                    <button className={"ml-auto btn btn-sm fa fa-trash text-danger"} onClick={event=>this.handleDeleteRefill(e.id)}></button>
                </div>
            );
        });

        return(
            <LoadingComponent isLoading={isLoading} statusMessage={statusMessage} clearMessage={this.clearMessage}>
                <h1>Заправки</h1>
                <div className={"d-flex"}>
                    <input type={"text"}
                           className={"form-control"}
                           readOnly={true} placeholder={"Картридж"} value={cartridge!=null?cartridge.sn+"/"+cartridge.model.name+" "+cartridge.model.printer.model+" "+cartridge.model.printer.manufacturer.name:""}/>
                    <DialogModal
                        parent={this.props.parentDom?this.props.parentDom:"#refill"}
                        btnClass={"btn btn-secondary"}
                        btnLabel={"..."}
                        onSelect={this.handleSelectCartridge}
                    >
                       <Cartridge parentDom={"#cartridge"} onSelect={this.handleSelectCartridge}/>
                    </DialogModal>
                </div>
                <div className={"d-flex"}>
                    <input type={"text"}
                           className={"form-control"}
                           readOnly={true} placeholder={"Сотрудник"} value={employee!=null?employee.fio:""}/>
                    <DialogModal
                        parent={this.props.parentDom?this.props.parentDom:"#refill"}
                        btnClass={"btn btn-secondary"}
                        btnLabel={"..."}
                        onSelect={this.handleSelectEmployee}
                    >
                       <Employee parentDom={"#employee"} onSelect={this.handleSelectEmployee}/>
                    </DialogModal>
                </div>

                <form className={"form d-flex flex-row-reverse"} onSubmit={(event)=>{this.handleSubmit(event)}}>
                    <button type={"submit"} disabled={!isReady} className={"btn btn-outline-info"}> Сохранить</button>
                </form>
                <div className={"mt-2 border-top border-success pt-1"}>
                    {refillList}
                </div>
            </LoadingComponent>
        );
    }
    handleSubmit(event){
        const {selected,cartridge,employee}=this.state;

        event.preventDefault();
        saveRefill(selected?{id:selected,employee:employee,cartridge:cartridge}:{employee:employee,cartridge:cartridge}).then(data=>{
            if(statusOk(data.status)&& data.status!=302){
                this.setState(prevState=>{
                    return{
                        refills: prevState.selected?[...prevState.refills.filter(e=>e.id!=prevState.selected),data.content.refill]:[...prevState.refills,data.content.refill],
                        selected: null
                    };
                });
                this.setMessage("Запись сохранена успешно");
            }else this.setMessage("Ошибка создания записи, код "+data.status,"danger");
        });
    }
    handleDeleteRefill(id){
        confirmAlert({
            title: 'Подтвердите действие',
            message: 'Вы уверены, что хотите удалить это?',
            buttons: [
                {
                    label: 'Да',
                    onClick: () => {
                        deleteRefill(id).then(data=>{
                            if(data.status==204){
                                this.setState(prevState=>{
                                    return{
                                        refills: prevState.refills.filter(e=>e.id!=id),
                                        selected: prevState.selected==id?null:prevState.selected
                                    }
                                });
                                this.setMessage("Запись успешно удалена");
                            }else this.setMessage("Ошибка удалениия записи, код "+data.status,"danger");
                        });
                    }
                },
                {
                    label: 'Нет',
                    onClick: () => {}
                }
            ]
        });
    }
    handleSelect(id){
        this.setState(prevState=>{
            const refill=prevState.refills.find(e=>e.id==id);

            return{
                selected:id,
                cartridge: refill.cartridge,
                employee: refill.employee
            };
        });
    }
    checkReady(){
        const {cartridge, employee}=this.state;
        return cartridge!=null && employee!=null;
    }
    handleSelectCartridge(cartridge){
        this.setState({
            cartridge:cartridge
        });
    }
    handleSelectEmployee(employee){
        this.setState({
            employee:employee
        });
    }
    setMessage(msg,status="success"){
        this.setState({
            statusMessage:{message:msg, status:status}
        });
    }
    clearMessage(){
        this.setState({
            statusMessage:{message:"", status:"success"}
        });
    }
    handleToggleRefillStatus(id){
        const refill=this.state.refills.find(e=>e.id==id);

        toggleRefillStatus(id).then(
            data=>{
                if(statusOk(data.status)){
                    this.setState(prevState=>{
                        return {
                            refills:prevState.refills.map(e=>{
                                if(e.id==id) return data.content.refill;
                                return e;
                            })
                        };
                    });
                }
            }
        );
    }
}