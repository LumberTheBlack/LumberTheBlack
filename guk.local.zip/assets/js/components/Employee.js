import React, {Component} from 'react';
import LoadingComponent from "./LoadingComponent";
import DialogModal from "./DialogModal";
import Position from "./position";
import {getEmployees, saveEmployee} from "../api/employees_api";
import {statusOk} from "../api/common";
import deleteEmployee from "../api/employees_api";
import {confirmAlert} from "react-confirm-alert";
import {deletePosition} from "../api/position_api";

export default class Employee extends Component{
    constructor(props){
        super(props);
        this.state={
            fio:"",
            position:null,
            employees:[],
            selected:null,
            isLoading: true,
            statusMessage:{message:"", status:"success", duration: 4000}
        };
        this.clearMessage=this.clearMessage.bind(this);
        this.setMessage=this.setMessage.bind(this);
        this.handleSelectPosition=this.handleSelectPosition.bind(this);
        this.handleSubmit=this.handleSubmit.bind(this);
        this.checkReady=this.checkReady.bind(this);
        this.handleChangeFio=this.handleChangeFio.bind(this);
        this.handleSelect=this.handleSelect.bind(this);
        this.handleDeleteEmployee=this.handleDeleteEmployee.bind(this);
    }
    componentDidMount(){
        getEmployees().then(data=>{
            const employees=data.content.employees;
            this.setState({
                employees:employees.length>0?employees:[],
                isLoading:false
            });
        });
    }
    render(){
        const {isLoading,statusMessage,employees,selected,fio,position}=this.state;
        const isReady=this.checkReady();
        const employeeList=employees.map(e=>{
            return(
                <div className={"d-flex"} key={e.id}>
                    <div
                        className={"p-1 cursor-pointer flex-fill"+(selected==e.id?" bg-primary text-white":"")}
                        onClick={event=>this.handleSelect(e.id)}
                    >
                        {e.fio} /{e.position.name} {e.position.department.name}/
                    </div>
                    <button className={"ml-auto btn btn-sm fa fa-trash text-danger"} onClick={event=>this.handleDeleteEmployee(e.id)}></button>
                </div>
            );
        });

        return(
            <LoadingComponent isLoading={isLoading} statusMessage={statusMessage} clearMessage={this.clearMessage}>
                <h1>Сотрудники</h1>
                <div className={"d-flex"}>
                    <input type={"text"}
                           className={"form-control"}
                           readOnly={true} placeholder={"должность"} value={position!=null?position.name:""}/>
                    <DialogModal
                        parent={this.props.parentDom?this.props.parentDom:"#employee"}
                        btnClass={"btn btn-secondary"}
                        btnLabel={"..."}
                        onSelect={this.handleSelectPosition}
                    >
                       <Position parentDom={"#employee-position"} onSelect={this.handleSelectPosition}/>
                    </DialogModal>
                </div>
                <form className={"form"} onSubmit={(event)=>{this.handleSubmit(event)}}>
                    <input
                        className={"form-control"}
                        type={"text"}
                        value={fio}
                        onChange={(event)=>{this.handleChangeFio(event)}}
                    />
                    <button type={"submit"} disabled={!isReady} className={"btn btn-outline-info"}> Сохранить</button>
                </form>
                <div className={"mt-1"}>
                    {employeeList}
                </div>
            </LoadingComponent>
        );
    }
    handleSubmit(event){
        const {selected,fio,position}=this.state;

        event.preventDefault();
        saveEmployee(selected?{id:selected,fio:fio,position:position}:{fio:fio,position:position}).then(data=>{
            if(statusOk(data.status)&& data.status!=302){
                this.setState(prevState=>{
                    return{
                        employees: prevState.selected?[...prevState.employees.filter(e=>e.id!=prevState.selected),data.content.employee]:[...prevState.employees,data.content.employee],
                        selected: null
                    };
                });
                this.setMessage("Запись сохранена успешно");
            }else this.setMessage("Ошибка создания записи, код "+data.status,"danger");
        });
    }
    handleDeleteEmployee(id){
        confirmAlert({
            title: 'Подтвердите действие',
            message: 'Вы уверены, что хотите удалить это?',
            buttons: [
                {
                    label: 'Да',
                    onClick: () => {
                        deleteEmployee(id).then(data=>{
                            if(data.status==204){
                                this.setState(prevState=>{
                                    return{
                                        employees: prevState.employees.filter(e=>e.id!=id),
                                        selected: prevState.selected==id?null:prevState.selected
                                    }
                                });
                                this.setMessage("Запись успешно удалена");
                            }else this.setMessage("Ошибка удалениия записи, код "+data.status,"danger");
                        });
                    }
                },
                {
                    label: 'Нет',
                    onClick: () => {}
                }
            ]
        });
    }
    handleChangeFio(event){
        this.setState({
            fio:event.target.value
        });
    }
    handleSelect(id){
        this.setState(prevState=>{
            const employee=prevState.employees.find(e=>e.id==id);

            return{
                selected:id,
                fio: employee.fio,
                position: employee.position
            };
        });
        if(this.props.onSelect)this.props.onSelect(this.state.employees.find(e=>e.id==id));
    }
    checkReady(){
        const {position, fio}=this.state;
        return position!=null && fio.length>0;
    }
    handleSelectPosition(position){
        this.setState({
            position:position
        });
    }
    setMessage(msg,status="success"){
        this.setState({
            statusMessage:{message:msg, status:status}
        });
    }
    clearMessage(){
        this.setState({
            statusMessage:{message:"", status:"success"}
        });
    }
}