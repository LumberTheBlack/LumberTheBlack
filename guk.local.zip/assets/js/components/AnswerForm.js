import React,{Component} from 'react';
import DatePicker from 'react-datetime';
import moment from 'moment';
import {createAnswer, getAnswerById, saveAnswer} from "../api/answer_api";
import Portal from "./Portal";
import FileReferenceList from "./fileList";

export default class AnswerForm extends Component{
    constructor(props){
        super(props);
        this.state={
            id:(props.answer && props.answer>0)?props.answer:null,
            appeal_id:props.appeal,
            answerDate: new Date(),
            number:"",
            content:"",
            files:[],
            isLoading:true,
            isSubmitted:false
        };
        this.handleChangeAnswerDate=this.handleChangeAnswerDate.bind(this);
        this.handleChangeContent=this.handleChangeContent.bind(this);
        this.handleSetFiles=this.handleSetFiles.bind(this);
        this.isSaveButtonEnabled=this.isSaveButtonEnabled.bind(this);
        this.handleChangeNumber=this.handleChangeNumber.bind(this);
        this.handleSubmit=this.handleSubmit.bind(this);
    }
    componentDidMount(){
        if(this.state.id)getAnswerById(this.state.id).then(data=>{
            const answer=data.answer;
            this.setState({
                answerDate:moment(answer.answerDate),
                number:answer.number,
                files:data.files.length>0?data.files:[],
                content:answer.content,
                isLoading:false
            });
        })
        else this.setState({isLoading:false});
    }
    handleChangeAnswerDate(date){
        this.setState({
            answerDate:date
        });
    }
    handleSetFiles(files){
        this.setState({
            files:files
        });
    }
    handleChangeContent(event){
        this.setState({
            content:event.target.value
        });
    }
    handleChangeNumber(event){
        this.setState({
            number:event.target.value
        });
    }
    isSaveButtonEnabled(){
        const {
            content,
            isSubmitted
        }=this.state;
        var enabled=(
            content!==''
        );
        return enabled && !isSubmitted;
    }
    handleSubmit(event){
        event.preventDefault();
        this.setState({isSubmitted:true});
        var answer=this.state;
        if(answer.id===null) {
            delete answer.id;
            createAnswer(this.state).then(data => {
                // console.log({RESPONSE:data.appeal});
                window.location.href="/appeal/"+this.state.appeal_id+"/show";
            });
        }else saveAnswer(this.state).then(data => {
            window.location.href="/appeal/"+this.state.appeal_id+"/show";
        });
    }
    render(){
        const {id,isLoading}=this.state;
        return(
          <div>
            {isLoading && (<span><i className={"fas fa-spinner fa-spin"}></i> Загружаем ...</span>)}
            {!isLoading  &&(
                <div>
                <form className={"form"} onSubmit={(event)=>{this.handleSubmit(event)}}>
                    <label>
                        <p><strong>Дата ответа</strong></p>
                        <DatePicker
                            onChange={this.handleChangeAnswerDate}
                            value={this.state.answerDate}
                            locale={"ru-RU"}
                            dateFormat={"DD.MM.YYYY"}
                            timeFormat={false}
                        />
                    </label>
                    {id && (
                        <div>
                            <label>
                                <p><strong>Входящий номер</strong></p>
                                <input
                                    type={"text"}
                                    value={this.state.number}
                                    onChange={(event)=>{this.handleChangeNumber(event)}}
                                />
                            </label>
                        </div>
                    )}
                    <div>
                        <label>
                            <p><strong>Состав ответа (по сути, кратко)</strong></p>
                            <textarea
                                value={this.state.content}
                                onChange={(event)=>{this.handleChangeContent(event)}}
                                cols={"50"}
                                rows={"8"}
                            />
                        </label>
                    </div>
                    <Portal>
                        <FileReferenceList
                            postId={null}
                            setFiles={this.handleSetFiles}
                            defaultFiles={this.state.files}
                            initializeDropzone={this.props.initializeDropzone}
                        />
                    </Portal>
                    <div className={"d-flex justify-content-center mt-2"}>
                        <button
                            type={"submit"}
                            className={"btn btn-outline-primary fas fa-save"}
                            disabled={!this.isSaveButtonEnabled()}
                        >
                            Сохранить
                        </button>
                        <a
                            href={"/appeal/"+this.state.appeal_id+"/show"}
                            className={"btn btn-outline-secondary fas fa-close"}
                        >
                            Закрыть
                        </a>
                    </div>
                </form>
            </div>
            )}
          </div>
        );
    }
}