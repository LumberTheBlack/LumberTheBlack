import React,{Component} from 'react';
import DialogModal from "./DialogModal";
import {savePrinter, getPrinters, deletePrinter} from "../api/printer_api";
import {statusOk} from '../api/common';
import LoadingComponent from "./LoadingComponent";
import {confirmAlert} from "react-confirm-alert";
import Manufacturer from "./Manufacturer";

export default class Printer extends Component{
    constructor(props){
        super(props);
        this.state={
            model:"",
            manufacturer:null,
            isSubmitted:false,
            isLoading: true,
            printers:[],
            selected:null,
            statusMessage:{message:"", status:"success", duration: 4000}
        };
        this.handleSubmit=this.handleSubmit.bind(this);
        this.handleChangeModel=this.handleChangeModel.bind(this);
        this.handleSelectManufacturer=this.handleSelectManufacturer.bind(this);
        this.checkReady=this.checkReady.bind(this);
        this.handleSelect=this.handleSelect.bind(this);
        this.clearMessage=this.clearMessage.bind(this);
        this.setMessage=this.setMessage.bind(this);
    }
    componentDidMount(){
        getPrinters().then(data=>{
            const printers=data.content.printers;
            //console.log(data.content);
            this.setState({
                printers:printers.length>0?printers:[],
                isLoading:false
            });
        });
    }
    handleChangeModel(event){
        this.setState({
            model: event.target.value
        });
    }
    handleSelectManufacturer(manufacturer){
        this.setState({
            manufacturer:manufacturer
        });
    }
    handleSelect(id){
        this.setState(prevState=>{
            const printer=prevState.printers.find(p=>p.id==id);
            return {
                selected:id,
                manufacturer:printer.manufacturer,
                model: printer.model
            };
        });
        if(this.props.onSelect)this.props.onSelect(this.state.printers.find(p=>p.id==id));
    }
    checkReady(){
        const {manufacturer, model}=this.state;
       return manufacturer!=null && model.length>0;
    }
    handleDelete(id){
        confirmAlert({
            title: 'Подтвердите действие',
            message: 'Вы уверены, что хотите удалить это?',
            buttons: [
                {
                    label: 'Да',
                    onClick: () => {
                        deletePrinter(id).then(data=>{
                            if(data.status==204){
                                this.setState(prevState=>{
                                    return{
                                        printers: prevState.printers.filter(printer=>printer.id!=id),
                                        selected: prevState.selected==id?null:prevState.selected
                                    }
                                });
                                this.setMessage("Запись успешно удалена");
                            }else this.setMessage("Ошибка удалениия записи, код "+data.status,"danger");
                        });
                    }
                },
                {
                    label: 'Нет',
                    onClick: () => {}
                }
            ]
        });

    }
    handleSubmit(event){
        const {model,manufacturer,selected}=this.state;
        //this.setState({isSubmitted:true});
        event.preventDefault();
        savePrinter(selected?{id:selected, model:model, manufacturer:manufacturer}:{model:model, manufacturer:manufacturer}).then(
            data=>{
                 if(statusOk(data.status)) {
                     this.setState(prevState => {
                         return {
                             printers: prevState.selected?[...prevState.printers.filter(printer=>printer.id!=selected),data.content.printer]:[...prevState.printers, data.content.printer],
                             selected:null
                         };
                     });
                     this.setMessage("Запись успешно сохранена");
                 }else this.setMessage("Ошибка сохранения записи, код ошибки "+data.status,"danger");
            }
        );
    }
    render(){
        const {model, manufacturer, isSubmitted, isLoading, printers, selected,statusMessage}=this.state;
        const isReady=this.checkReady();
        const printerList=printers.map(printer=>{
            return(
                <div key={printer.id} className={"d-flex"}>
                    <div
                        className={"p-1 cursor-pointer flex-fill"+(selected==printer.id?" bg-primary text-white":"")}
                        onClick={event=>this.handleSelect(printer.id)}
                    >
                        {printer.manufacturer.name} {printer.model}
                    </div>
                    <button className={"ml-auto btn btn-sm fa fa-trash text-danger"} onClick={event=>this.handleDelete(printer.id)}></button>
                </div>
            );
        });

        return(
            <LoadingComponent isLoading={isLoading} statusMessage={statusMessage} clearMessage={this.clearMessage}>
                <h1>Модели принтеров</h1>
                <div className={"d-flex"}>
                    <input type={"text"}
                           className={"form-control"}
                           readOnly={true} placeholder={"Производитель"} value={manufacturer!=null?manufacturer.name:""}/>
                    <DialogModal
                        parent={this.props.parentDom?this.props.parentDom:"#printer"}
                        btnClass={"btn btn-secondary"}
                        btnLabel={"..."}
                        onSelect={this.handleSelectManufacturer}
                    >
                        <Manufacturer
                            onSelect={this.handleSelectManufacturer}
                        />
                    </DialogModal>
                </div>
                <form className={"form"} onSubmit={(event)=>{this.handleSubmit(event)}}>
                    <input
                        className={"form-control"}
                        type={"text"}
                        value={model}
                        onChange={(event)=>{this.handleChangeModel(event)}}
                    />
                    <button type={"submit"} disabled={!isReady} className={"btn btn-outline-info"}> Сохранить</button>
                </form>
                <div className={"mt-1"}>
                    {printerList}
                </div>
            </LoadingComponent>
        );
    }
    setMessage(msg,status="success"){
        this.setState({
            statusMessage:{message:msg, status:status}
        });
    }
    clearMessage(){
        this.setState({
            statusMessage:{message:"", status:"success"}
        });
    }
}