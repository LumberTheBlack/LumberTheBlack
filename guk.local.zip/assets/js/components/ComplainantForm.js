import React,{Component} from 'react';
import AddressObjectInput from "./ao_input";
import ResidenceForm from "./ResidenceForm";
import ReactModal from "react-modal";
import OrganizationListForm from "./OrganizationListForm";
import {addComplainant} from '../api/complainant_api';
import FlashMessage from './FlashMessage';

export default class ComplainantForm extends Component{
    constructor(props){
        ReactModal.setAppElement(props.parent);
        super(props);
        this.state={
            fio:"",
            address:{
                ao: null,
                residence: {id:null, name:""},
                flat:null,
                withFlat:true
            },
            position:"",
            organization:null,
            individual: (props.individual!==undefined?props.individual:true),
            showModal:false,
            residenceLoaded: false,
            statusMessage:{message:"",status:"success"},
            isSubmitted:false
        };
        this.handleCloseModal=this.handleCloseModal.bind(this);
        this.handleOpenModal=this.handleOpenModal.bind(this);

        this.handleChangeFio=this.handleChangeFio.bind(this);
        this.handleChangePosition=this.handleChangePosition.bind(this);
        this.handleSetAddress=this.handleSetAddress.bind(this);
        this.handleSelectResidence=this.handleSelectResidence.bind(this);
        this.handleSelectOrganization=this.handleSelectOrganization.bind(this);
        this.handleSetWithFlat=this.handleSetWithFlat.bind(this);
        this.setMessage=this.setMessage.bind(this);
    }
    setMessage(message="",status="success") {
        this.setState({
            statusMessage:{message:message, status:status}
        });
    }
    handleOpenModal(){
        this.setState({
            showModal:true
        });
    }
    handleCloseModal(){
        this.setState({
            fio:"",
            address:{
                ao: null,
                residence: {id:null, name:""},
                flat:null,
                withFlat:true
            },
            position:"",
            organization:null,
            individual: (this.props.individual!==undefined?this.props.individual:true),
            showModal:false,
            residenceLoaded: false,
            flatLoaded: false,
            statusMessage:{message:"",status:"success"}
        });
    }
    handleChangeFio(event){
        this.setState({
            fio:event.target.value
        });
    }
    handleChangePosition(event){
        this.setState({
            position:event.target.value
        });
    }
    handleSetAddress(ao=null){
        this.setState((prevState)=>{
            var address=prevState.address;
            address.ao=ao;
            address.residence={id:null, name:""};
            return {address:address};
        });
    }
    handleSelectOrganization(org){
        this.setState({
            organization:org
        });
    }

    handleSelectResidence(residence,level){

        if(level===0)
            this.setState((prevState)=>{
                var address=prevState.address;
                address.residence=residence;
                address.flat=null;
                return {address:address}
            });
        else
            this.setState((prevState)=>{
                var address=prevState.address;
                address.flat=residence;
                return {address:address};
            });
    }
    handleSetWithFlat(withFlat){
            this.setState(prevState=>{
                var address=prevState.address;
                    address.flat=!withFlat?null:address.flat;
                    address.withFlat=withFlat;
                return ({
                    address:address
                });
            });

    }
    handleSubmit(event){
        event.preventDefault();
        this.setState({isSubmitted:true});
        addComplainant(this.state).then(data=>{
            //console.log(data);
            if(data.resp.status===201) {
                if (this.props.handleAddComplainant) this.props.handleAddComplainant(data.resp.complainant);
                this.handleCloseModal();
            }else {
                this.setState({isSubmitted:false});
                this.setMessage("Ошибка создания заявителя - вероятно уже есть в базе.", "danger");
            }
        });
    }
    render(){
        const {fio,address,isSubmitted}=this.state;
        var isEnabledSaveButton=(fio && address.ao && address.residence && !isSubmitted);
            if(this.state.address.withFlat)isEnabledSaveButton=(isEnabledSaveButton && address.flat && address.flat.name.length>0 );
            if(!this.state.individual)isEnabledSaveButton=(isEnabledSaveButton && this.state.position!=="" && this.state.organization);
        return(
            <div>
                <button
                    onClick={this.handleOpenModal}
                    className={"btn btn-info fa fa-plus"}
                />
                <ReactModal
                    isOpen={this.state.showModal}
                    contentLabel="onRequestClose Example"
                    onRequestClose={this.handleCloseModal}
                >
                    <h2>Добавление заявителя</h2>
                    {!this.state.individual && (
                        <div className={"form-inline"}>
                        <input
                            value={this.state.organization?this.state.organization.name:""}
                            className={"form-control"}
                            type={"text"}
                            placeholder={"Выберите организацию"}
                            disabled />
                        <OrganizationListForm
                            parent={"#organization_list_container"}
                            setOrganization={this.handleSelectOrganization}
                        />
                        </div>
                    )}
                <form className={"form"} onSubmit={(event)=>{this.handleSubmit(event)}}>
                    <input className={"form-control"} type={"text"}
                           value={this.state.fio}
                           onChange={(event)=>{this.handleChangeFio(event)}}
                           placeholder={"Введите ФИО"}/>
                    {!this.state.individual && (
                     <input className={"form-control"} type={"text"}
                               value={this.state.position}
                               onChange={(event) => {
                                   this.handleChangePosition(event)
                               }}
                               placeholder={"Введите должность"}/>
                    )}
                    <AddressObjectInput
                        level={1}
                        setAddress={this.handleSetAddress}
                        setResidence={this.handleSelectResidence}
                        setWithFlat={this.handleSetWithFlat}
                    />

                    <button type={"submit"}
                            className={"btn btn-primary fa fa-save"}
                            disabled={!isEnabledSaveButton}
                    > Сохранить</button>
                    <button className={"btn btn-secondary"} onClick={this.handleCloseModal}>Закрыть</button>
                </form>
                    {this.state.statusMessage.message &&(
                        <FlashMessage
                            statusMessage={this.state.statusMessage}
                            clearMessage={this.setMessage}
                        />
                    )}
                </ReactModal>
            </div>
        );
    }
}
