import React,{Component} from 'react';
import {getResidenceByName} from "../api/address_object_api";
import Autosuggest from 'react-autosuggest';
import {debounce} from "throttle-debounce";
const AutosuggestHighlightMatch=require('autosuggest-highlight/match');
const AutosuggestHighlightParse=require('autosuggest-highlight/parse');

function renderSuggestion(suggestion, { query }) {
    const matches = AutosuggestHighlightMatch(suggestion.name, query);
    const parts = AutosuggestHighlightParse(suggestion.name, matches);

    return (
        <span>
                {parts.map((part, index) => {
                    const className = part.highlight ? 'react-autosuggest__suggestion-match' : null;
                    return (
                        <span className={className} key={index}>
                            {part.text}
                        </span>
                    );
                })}
            </span>
    );
}
export default class ResidenceForm extends Component{
    constructor(props){
        super(props);
        this.state={
            q: "",
            suggestions:[],
            isLoading:false,
            selected:null,
            withFlat:true
        };
        this.changeQuery=this.changeQuery.bind(this);
        this.onSuggestionsClearRequested=this.onSuggestionsClearRequested.bind(this);
        this.onSuggestionsFetchRequested=debounce(2000,this.onSuggestionsFetchRequested.bind(this));
        this.getSuggestionValue=this.getSuggestionValue.bind(this);
        this.handleChangeWithFlat=this.handleChangeWithFlat.bind(this);
    }
    changeQuery(event,{newValue}){
        this.setState({
            q: newValue,
            selected: null
        });
        this.props.setResidence(null,this.props.residenceLevel?this.props.residenceLevel:0);
        //console.log(this.state);
    }
    onSuggestionsFetchRequested ({value,reason}){
        const level=this.props.residenceLevel;
        if(reason!=='input-changed') return;
        if(value.length===0) return;
        this.setState({
            isLoading:true,
        });
        if(level>0 && this.props.owner.id===null) {
            this.setState({
                suggestions: [],
                isLoading: false,
                selected:{id:null, name:value}
            });
            this.props.setResidence({id:null, name:value},level?level:0);
        }else
        getResidenceByName(value,level===0?this.props.parentAo:this.props.owner,level).then(data=>{
            this.setState(prevState=>{
                return({
                    suggestions:data,
                    isLoading:false,
                    selected:(data.length>0?null:{id:null,name:value})
                });
            });
            if(data.length==0) this.props.setResidence({id:null, name:value},level?level:0);
        });
    }

    // Autosuggest will call this function every time you need to clear suggestions.
    onSuggestionsClearRequested(){
        this.setState({
            suggestions: []
        });
    }
    getSuggestionValue(suggestion){
        const publicValue=suggestion.name;
        this.setState({
            q:publicValue,
            selected: suggestion
        });
        this.props.setResidence({id:suggestion.id, name:suggestion.name},this.props.residenceLevel?this.props.residenceLevel:0);

        return publicValue;
    }
    handleChangeWithFlat(event){
        this.setState((prevState)=>{
            if(this.props.setWithFlat)this.props.setWithFlat(!prevState.withFlat)
            return{withFlat: !prevState.withFlat};
        });
    }
    render(){
        const {q,isLoading,selected,withFlat}=this.state;
        const {residenceLevel}=this.props;
        const residenceOrflat=residenceLevel===0?"Укажите номер здания":"Укажите номер помещения/офиса";
        const inputProps = {
            placeholder: residenceOrflat,
            value: q,
            onChange: this.changeQuery,
            className: 'form-control',
            disabled: isLoading
        };
        return(
            <div>
                <Autosuggest
                    suggestions={this.state.suggestions}
                    inputProps={inputProps}
                    onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
                    onSuggestionsClearRequested={this.onSuggestionsClearRequested}
                    getSuggestionValue={this.getSuggestionValue}
                    renderSuggestion={renderSuggestion}
                />
                {isLoading && (<p className={"text-muted"}>
                    <i className={"fa fa-spinner fa-pulse"}> </i> Идет поиск...
                </p>)}
                {residenceLevel===0 && selected &&(
                    <div className="form-check">
                        <input className="form-check-input" type="checkbox"
                           checked={this.state.withFlat}
                           onChange={(event)=>{this.handleChangeWithFlat(event)}}
                           id="withFlat"/>
                        <label className="form-check-label" htmlFor="withFlat">
                            Указывать помещение
                        </label>
                    </div>
                )}
                
                {residenceLevel===0 && selected && withFlat &&(
                    <ResidenceForm
                        key={"flat"}
                        owner={selected}
                        setResidence={this.props.setResidence}
                        residenceLevel={1}
                    />
                )}

            </div>
        );
    }
}