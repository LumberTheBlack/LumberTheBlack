import React,{Component} from 'react';
import {getNomenclatures} from '../api/nomenclature_api';

export default class NomenclatureInput extends Component{
    constructor(props){
        super(props);
        this.state={
            nomenclatures:[],
            selected:props.defaultValue?props.defaultValue.id:"",
            isLoading:true
        };
        this.handleChange=this.handleChange.bind(this);
    }
    componentDidMount(){
        getNomenclatures().then(data=>{
            this.setState({
                nomenclatures:data,
                isLoading:false,
                selected:this.props.defaultValue?this.props.defaultValue.id:""
            });
        });
    }
    handleChange(event){
        const value=this.state.nomenclatures.find(item=>item.id===+event.target.value);

        this.setState({
            selected:value.id
        });
        this.props.setNomenclature(value);
    }
    render(){
        const {isLoading,selected}=this.state;
        const {msg}=this.props;

        const options=this.state.nomenclatures.map(item=>{
            return(
                <option value={item.id} key={item.id}>
                    [{item.indexDoc}] {item.name}
                </option>
            );
        });
        return(
          <div>
              <select value={selected} onChange={event=>{this.handleChange(event)}} className={"form-control"}>
                 <option value={""} key={"placeholder"} disabled={true}>{msg}</option>
                {options}
              </select>
              {isLoading && (
                  <div><i className={"fas fa-spinner fa-spin"}></i> Загружаем...</div>
              )}
          </div>
        );
    }
}