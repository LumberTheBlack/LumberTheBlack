import React,{Component} from 'react';
import {throttle, debounce} from 'throttle-debounce';
import {getAddressObject, getAddressObjectByGuid} from "../api/address_object_api";
import Autosuggest from 'react-autosuggest';
import ResidenceForm from "./ResidenceForm";
const AutosuggestHighlightMatch=require('autosuggest-highlight/match');
const AutosuggestHighlightParse=require('autosuggest-highlight/parse');

function renderSuggestion(suggestion, { query }) {
    const matches = AutosuggestHighlightMatch(suggestion.formalName+' '+suggestion.shortName, query);
    const parts = AutosuggestHighlightParse(suggestion.formalName+' '+suggestion.shortName, matches);

    return (
        <span>
                {parts.map((part, index) => {
                    const className = part.highlight ? 'react-autosuggest__suggestion-match' : null;
                    return (
                        <span className={className} key={index}>
                            {part.text}
                        </span>
                    );
                })}
            </span>
    );
}
export default class AddressObjectInput extends Component{
    constructor(props){
        super(props);
        this.state = {
            q: "",
            suggestions:[],
            isLoading: false,
            level: props.level?props.level:null,
            parent: props.parent_guid?props.parent_guid:null,
            selected:null,
            lastChild:null
        };
        this.autocompleteSearchDebounced = debounce(1000, getAddressObject);
        this.autocompleteSearchThrottled = throttle(1000, getAddressObject);
        this.changeQuery=this.changeQuery.bind(this);
        this.onSuggestionsClearRequested=this.onSuggestionsClearRequested.bind(this);
        this.onSuggestionsFetchRequested=debounce(2000,this.onSuggestionsFetchRequested.bind(this));
        this.getSuggestionValue=this.getSuggestionValue.bind(this);
        this.getParentGuid=this.getParentGuid.bind(this);
        this.addSelectedChild=this.addSelectedChild.bind(this);
    }
    componentDidMount(){
        if(this.state.level==1){
            getAddressObjectByGuid("bd8e6511-e4b9-4841-90de-6bbc231a789e").then(data=>{
                this.getSuggestionValue(data);
            });

        }
    }
    getParentGuid(){
        return this.state.selected?this.state.selected.guid:null;
    }
    changeQuery(event,{newValue}){
        this.setState({ q: newValue});
        //console.log(this.state);
    }
    onSuggestionsFetchRequested ({value,reason}){
        if(reason!=='input-changed') return;
        const {level,parent}=this.state;
        this.setState({
            isLoading:true,
            selected:null,
        });

        if(this.props.addChild)this.props.addChild();//clear lastChild value on input change
        getAddressObject(value,level,parent).then(data=>{
            this.setState({
                suggestions:data,
                isLoading:false
            });}
        );
    }

    // Autosuggest will call this function every time you need to clear suggestions.
    onSuggestionsClearRequested(){
        this.setState({
            suggestions: []
        });
    }
    getSuggestionValue(suggestion){
        const publicValue=suggestion.formalName+' '+suggestion.shortName;
        this.setState({
            q:publicValue,
            selected:suggestion
        });
        if(this.props.addChild)this.props.addChild(suggestion);
        return publicValue;
    }
    addSelectedChild(lastChild=null){
        //if(lastChild.aoLevel>6)
            this.setState({
                lastChild: lastChild
            });
            if(lastChild && lastChild.aoLevel>6 && this.props.setAddress)
                this.props.setAddress(lastChild);
    }
    render(){
        const {q,suggestions,isLoading}=this.state;
        const inputProps = {
            placeholder: 'Укажите адресный объект',
            value: q,
            onChange: this.changeQuery,
            className: 'form-control',
            disabled: isLoading
        };

        return(
            <div>
                <Autosuggest
                    key={"root"}
                    suggestions={this.state.suggestions}
                    inputProps={inputProps}
                    onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
                    onSuggestionsClearRequested={this.onSuggestionsClearRequested}
                    getSuggestionValue={this.getSuggestionValue}
                    renderSuggestion={renderSuggestion}
                />
                {isLoading && (<p className={"text-muted"}>
                    <i className={"fa fa-spinner fa-pulse"}> </i> Идет поиск...
                </p>)}
                {this.state.selected && (
                    <p className={"text-muted"}>{this.state.selected.guid}</p>
                )}
                {this.state.selected && this.state.selected.aoLevel<7 &&(
                    <AddressObjectInput
                       parent_guid={this.getParentGuid()}
                       setResidence={this.props.setResidence}
                       addChild={this.props.addChild?this.props.addChild:this.addSelectedChild}
                       setWithFlat={this.props.setWithFlat}
                    />
                )}
                {this.state.selected && this.state.selected.aoLevel>6 && (
                    <ResidenceForm
                        parentAo={this.state.selected}
                        setResidence={this.props.setResidence}
                        residenceLevel={0}
                        setWithFlat={this.props.setWithFlat}
                    />
                )}
            </div>

        );
    }
}