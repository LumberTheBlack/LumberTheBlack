import React,{Component} from 'react';
import FlashMessage from "./FlashMessage";

export default function LoadingComponent(props){
    if (props.isLoading)
            return (
                <div>
                    <i className={"fa fa-spinner fa-spin"}></i> <i>Загружаем данные...</i>
                </div>
            );
    else
            return (
                <div>
                    {props.children}
                    {props.statusMessage && props.statusMessage.message && (
                        <FlashMessage
                            duration={props.statusMessage.duration?props.statusMessage.duration:4000}
                            statusMessage={props.statusMessage}
                            clearMessage={props.clearMessage}
                        />
                    )}
                </div>
            );
}