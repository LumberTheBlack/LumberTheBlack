import React, {Component} from 'react';
import LoadingComponent from "./LoadingComponent";
import DialogModal from "./DialogModal";
import Printer from "./Printer";
import {getCartridgeModels, saveCartridgeModel} from "../api/cartridgemodels_api";
import {statusOk} from "../api/common";
import deleteCartridgeModel from "../api/cartridgemodels_api";
import {confirmAlert} from "react-confirm-alert";

export default class CartridgeModel extends Component{
    constructor(props){
        super(props);
        this.state={
            name:"",
            printer:null,
            cartridgemodels:[],
            selected:null,
            isLoading: true,
            statusMessage:{message:"", status:"success", duration: 4000}
        };
        this.clearMessage=this.clearMessage.bind(this);
        this.setMessage=this.setMessage.bind(this);
        this.handleSelectPrinter=this.handleSelectPrinter.bind(this);
        this.handleSubmit=this.handleSubmit.bind(this);
        this.checkReady=this.checkReady.bind(this);
        this.handleChangeName=this.handleChangeName.bind(this);
        this.handleSelect=this.handleSelect.bind(this);
        this.handleDeleteCartridgeModel=this.handleDeleteCartridgeModel.bind(this);
    }
    componentDidMount(){
        getCartridgeModels().then(data=>{
            const cartridgemodels=data.content.cartridgemodels;
            this.setState({
                cartridgemodels:cartridgemodels.length>0?cartridgemodels:[],
                isLoading:false
            });
        });
    }
    render(){
        const {isLoading,statusMessage,cartridgemodels,selected,name,printer}=this.state;
        const isReady=this.checkReady();
        const cartridgemodelList=cartridgemodels.map(e=>{
            return(
                <div className={"d-flex"} key={e.id}>
                    <div
                        className={"p-1 cursor-pointer flex-fill"+(selected==e.id?" bg-primary text-white":"")}
                        onClick={event=>this.handleSelect(e.id)}
                    >
                        {e.name} /{e.printer.model} {e.printer.manufacturer.name}/
                    </div>
                    <button className={"ml-auto btn btn-sm fa fa-trash text-danger"} onClick={event=>this.handleDeleteCartridgeModel(e.id)}></button>
                </div>
            );
        });

        return(
            <LoadingComponent isLoading={isLoading} statusMessage={statusMessage} clearMessage={this.clearMessage}>
                <h1>Модели картриджей</h1>
                <div className={"d-flex"}>
                    <input type={"text"}
                           className={"form-control"}
                           readOnly={true} placeholder={"модель принтера"} value={printer!=null?printer.model:""}/>
                    <DialogModal
                        parent={this.props.parentDom?this.props.parentDom:"#cartridge-model"}
                        btnClass={"btn btn-secondary"}
                        btnLabel={"..."}
                        onSelect={this.handleSelectPrinter}
                    >
                       <Printer parentDom={"#cartridge-model-printer"} onSelect={this.handleSelectPrinter}/>
                    </DialogModal>
                </div>
                <form className={"form"} onSubmit={(event)=>{this.handleSubmit(event)}}>
                    <input
                        className={"form-control"}
                        type={"text"}
                        value={name}
                        onChange={(event)=>{this.handleChangeName(event)}}
                    />
                    <button type={"submit"} disabled={!isReady} className={"btn btn-outline-info"}> Сохранить</button>
                </form>
                <div className={"mt-1"}>
                    {cartridgemodelList}
                </div>
            </LoadingComponent>
        );
    }
    handleSubmit(event){
        const {selected,name,printer}=this.state;

        event.preventDefault();
        saveCartridgeModel(selected?{id:selected,name:name,printer:printer}:{name:name,printer:printer}).then(data=>{
            if(statusOk(data.status)&& data.status!=302){
                this.setState(prevState=>{
                    return{
                        cartridgemodels: prevState.selected?[...prevState.cartridgemodels.filter(e=>e.id!=prevState.selected),data.content.cartridgemodel]:[...prevState.cartridgemodels,data.content.cartridgemodel],
                        selected: null
                    };
                });
                this.setMessage("Запись сохранена успешно");
            }else this.setMessage("Ошибка создания записи, код "+data.status,"danger");
        });
    }
    handleDeleteCartridgeModel(id){
        confirmAlert({
            title: 'Подтвердите действие',
            message: 'Вы уверены, что хотите удалить это?',
            buttons: [
                {
                    label: 'Да',
                    onClick: () => {
                        deleteCartridgeModel(id).then(data=>{
                            if(data.status==204){
                                this.setState(prevState=>{
                                    return{
                                        cartridgemodels: prevState.cartridgemodels.filter(e=>e.id!=id),
                                        selected: prevState.selected==id?null:prevState.selected
                                    }
                                });
                                this.setMessage("Запись успешно удалена");
                            }else this.setMessage("Ошибка удалениия записи, код "+data.status,"danger");
                        });
                    }
                },
                {
                    label: 'Нет',
                    onClick: () => {}
                }
            ]
        });
    }
    handleChangeName(event){
        this.setState({
            name:event.target.value
        });
    }
    handleSelect(id){
        this.setState(prevState=>{
            const cartridgemodel=prevState.cartridgemodels.find(e=>e.id==id);

            return{
                selected:id,
                name: cartridgemodel.name,
                printer: cartridgemodel.printer
            };
        });
        if(this.props.onSelect)this.props.onSelect(this.state.cartridgemodels.find(e=>e.id==id));
    }
    checkReady(){
        const {printer, name}=this.state;
        return printer!=null && name.length>0;
    }
    handleSelectPrinter(printer){
        this.setState({
            printer:printer
        });
    }
    setMessage(msg,status="success"){
        this.setState({
            statusMessage:{message:msg, status:status}
        });
    }
    clearMessage(){
        this.setState({
            statusMessage:{message:"", status:"success"}
        });
    }
}