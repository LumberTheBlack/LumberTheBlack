import React,{Component} from 'react';
import DialogModal from "./DialogModal";
import Department from "./Department";
import {savePosition, getPositions, deletePosition} from "../api/position_api";
import {statusOk} from '../api/common';
import LoadingComponent from "./LoadingComponent";
import {confirmAlert} from "react-confirm-alert";
import {deleteDepartment} from "../api/department_api";

export default class Position extends Component{
    constructor(props){
        super(props);
        this.state={
            name:"",
            department:null,
            isSubmitted:false,
            isLoading: true,
            positions:[],
            selected:null,
            statusMessage:{message:"", status:"success", duration: 4000}
        };
        this.handleSubmit=this.handleSubmit.bind(this);
        this.handleChangeName=this.handleChangeName.bind(this);
        this.handleSelectDepartment=this.handleSelectDepartment.bind(this);
        this.checkReady=this.checkReady.bind(this);
        this.handleSelect=this.handleSelect.bind(this);
        this.clearMessage=this.clearMessage.bind(this);
        this.setMessage=this.setMessage.bind(this);
    }
    componentDidMount(){
        getPositions().then(data=>{
            const positions=data.content.positions;
            //console.log(data.content);
            this.setState({
                positions:positions.length>0?positions:[],
                isLoading:false
            });
        });
    }
    handleChangeName(event){
        this.setState({
            name: event.target.value
        });
    }
    handleSelectDepartment(department){
        this.setState({
            department:department
        });
    }
    handleSelect(id){
        this.setState(prevState=>{
            const position=prevState.positions.find(p=>p.id==id);
            return {
                selected:id,
                department:position.department,
                name: position.name
            };
        });
        if(this.props.onSelect)this.props.onSelect(this.state.positions.find(p=>p.id==id));
    }
    checkReady(){
        const {department, name}=this.state;
       return department!=null && name.length>0;
    }
    handleDelete(id){
        confirmAlert({
            title: 'Подтвердите действие',
            message: 'Вы уверены, что хотите удалить это?',
            buttons: [
                {
                    label: 'Да',
                    onClick: () => {
                        deletePosition(id).then(data=>{
                            if(data.status==204){
                                this.setState(prevState=>{
                                    return{
                                        positions: prevState.positions.filter(position=>position.id!=id),
                                        selected: prevState.selected==id?null:prevState.selected
                                    }
                                });
                                this.setMessage("Запись успешно удалена");
                            }else this.setMessage("Ошибка удалениия записи, код "+data.status,"danger");
                        });
                    }
                },
                {
                    label: 'Нет',
                    onClick: () => {}
                }
            ]
        });

    }
    handleSubmit(event){
        const {name,department,selected}=this.state;
        //this.setState({isSubmitted:true});
        event.preventDefault();
        savePosition(selected?{id:selected, name:name, department:department}:{name:name, department:department}).then(
            data=>{
                 if(statusOk(data.status)) {
                     this.setState(prevState => {
                         return {
                             positions: prevState.selected?[...prevState.positions.filter(position=>position.id!=selected),data.content.position]:[...prevState.positions, data.content.position],
                             selected:null
                         };
                     });
                     this.setMessage("Запись успешно сохранена");
                 }else this.setMessage("Ошибка сохранения записи, код ошибки "+data.status,"danger");
            }
        );
    }
    render(){
        const {name, department, isSubmitted, isLoading, positions, selected,statusMessage}=this.state;
        const isReady=this.checkReady();
        const positionList=positions.map(position=>{
            return(
                <div key={position.id} className={"d-flex"}>
                    <div
                        className={"p-1 cursor-pointer flex-fill"+(selected==position.id?" bg-primary text-white":"")}
                        onClick={event=>this.handleSelect(position.id)}
                    >
                        {position.name} /{position.department.name}/
                    </div>
                    <button className={"ml-auto btn btn-sm fa fa-trash text-danger"} onClick={event=>this.handleDelete(position.id)}></button>
                </div>
            );
        });

        return(
            <LoadingComponent isLoading={isLoading} statusMessage={statusMessage} clearMessage={this.clearMessage}>
                <h1>Должности</h1>
                <div className={"d-flex"}>
                    <input type={"text"}
                           className={"form-control"}
                           readOnly={true} placeholder={"Подразделение"} value={department!=null?department.name:""}/>
                    <DialogModal
                        parent={this.props.parentDom?this.props.parentDom:"#position"}
                        btnClass={"btn btn-secondary"}
                        btnLabel={"..."}
                        onSelect={this.handleSelectDepartment}
                    >
                        <Department
                            onSelect={this.handleSelectDepartment}
                        />
                    </DialogModal>
                </div>
                <form className={"form"} onSubmit={(event)=>{this.handleSubmit(event)}}>
                    <input
                        className={"form-control"}
                        type={"text"}
                        value={name}
                        onChange={(event)=>{this.handleChangeName(event)}}
                    />
                    <button type={"submit"} disabled={!isReady} className={"btn btn-outline-info"}> Сохранить</button>
                </form>
                <div className={"mt-1"}>
                    {positionList}
                </div>
            </LoadingComponent>
        );
    }
    setMessage(msg,status="success"){
        this.setState({
            statusMessage:{message:msg, status:status}
        });
    }
    clearMessage(){
        this.setState({
            statusMessage:{message:"", status:"success"}
        });
    }
}