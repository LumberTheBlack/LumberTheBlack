import React,{Component} from 'react';
import ReactModal from 'react-modal';
import {addOrganization, deleteOrganization, getOrganizations} from "../api/organization_api";
import FlashMessage from "./FlashMessage";
import {getComplainant} from "../api/complainant_api";


export default class OrganizationListForm extends Component {
    constructor(props){
        super(props);
        ReactModal.setAppElement(props.parent);
        this.state={
            showModal:false,
            organizations:[],
            newOrganization:"",
            isLoading: false,
            focused:null,
            statusMessage:{message:"",status:"success"},
            search:""
        };
        this.handleCloseModal=this.handleCloseModal.bind(this);
        this.handleOpenModal=this.handleOpenModal.bind(this);
        this.handleChangeOrganizationName=this.handleChangeOrganizationName.bind(this);
        this.handleAddOrg=this.handleAddOrg.bind(this);
        this.handleOrganizationFocused=this.handleOrganizationFocused.bind(this);
        this.handleSelect=this.handleSelect.bind(this);
        this.handleDeleteOrganization=this.handleDeleteOrganization.bind(this);
        this.setMessage=this.setMessage.bind(this);
        this.handleChangeSearchCondition=this.handleChangeSearchCondition.bind(this);
        this.handleSubmitSearchCondition=this.handleSubmitSearchCondition.bind(this);
    }
    setMessage(message="",status="success") {
        this.setState({
            statusMessage:{message:message, status:status}
        });
    }
    handleOpenModal(){
        this.setState({
            isLoading: true
        });
        getOrganizations().then(
            (data)=>{
                this.setState({
                    organizations: data,
                    isLoading: false
                });
            }
        );
        this.setState({
            showModal:true
        });
    }
    handleCloseModal(){
        this.setState({
            showModal:false,
            organizations:[],
            focused:null
        });
    }
    handleChangeOrganizationName(event){
        this.setState({
            newOrganization: event.target.value
        });
    }
    handleAddOrg(event){
        if(this.state.newOrganization!=="")
            addOrganization(this.state.newOrganization).then(
                (data)=>{
                    if(data.resp.status===201){

                        this.setState((prevState)=>{
                            return {
                                organizations:[...prevState.organizations,data.resp.organization]
                            };
                        });
                        this.setState({
                            newOrganization:"",
                            focused: data.resp.organization.id
                        });
                        this.setMessage("Организация успешно добавлена в базу")
                    }else this.setMessage("Ошибка добавления - вероятно такая организация уже есть","danger");
                }
            );
    }
    handleOrganizationFocused(event,orgId){
        this.setState({
            focused: orgId
        });
    }
    handleDeleteOrganization(event,id){
        if(!confirm('Уверены, что это нужно удалить?')) return;
        deleteOrganization(id).then(data=>{
            if(data.status===409)this.setMessage("Ошибка удаления - организация связана с другими объектами","danger");
            else{
                this.setState(prevState=>{
                    return {organizations:prevState.organizations.filter(org=>org.id!==id)};
                });
                this.setState({
                    focused: null
                });
                this.setMessage("Организация удалена успешно.")
            }
        });
    }
    handleSelect(event){
        if(this.props.setOrganization){
            this.props.setOrganization(this.state.organizations.filter(org=>org.id===this.state.focused)[0]);
        }
        this.handleCloseModal();
    }
    handleChangeSearchCondition(event){
        this.setState({
            search: event.target.value
        });
    }
    handleSubmitSearchCondition(event){
        event.preventDefault();
        this.setState({isLoading:true});
        getOrganizations(this.state.search).then(
            data=>{
                this.setState({
                    organizations: data,
                    isLoading: false
                });
            }
        );
    }
    render(){
        const list=this.state.organizations.map((item)=>{
            return (
                <div className={"d-flex"} key={item.id}>
                    <div
                        className={"list-group-item list-group-item-action border-0"+(this.state.focused===item.id?" active":"")}
                        onClick={(event)=>{this.handleOrganizationFocused(event,item.id)}}
                    >
                        {item.name}
                    </div>
                    <button
                        className={"btn fa fa-trash text-danger"}
                        onClick={(event)=>{this.handleDeleteOrganization(event,item.id)}}
                    />
                </div>);
        });
        return(
            <div>
                <button
                    onClick={this.handleOpenModal}
                    className={"btn btn-info"}
                >...</button>
                <ReactModal
                    isOpen={this.state.showModal}
                    contentLabel="onRequestClose Example"
                    onRequestClose={this.handleCloseModal}
                >
                    <h2>Список организаций</h2>
                    <div>
                        <form className={"form row align-items-center mx-1 mb-1"} onSubmit={(event)=>{this.handleSubmitSearchCondition(event)}}>
                            <input onChange={(event)=>{this.handleChangeSearchCondition(event)}}
                                   name={"search"}
                                   type={"text"}
                                   className={"form-control col px-auto"}
                                   value={this.state.search}
                                   placeholder={"Найти..."}
                            />
                            <button type={"submit"} onClick={(event)=>{this.handleSubmitSearchCondition(event)}}
                                    className={"btn btn-info fa fa-search"}
                                    disabled={this.state.search===""}
                            />
                        </form>
                    </div>
                    <div className={"d-flex mb-2"}>
                        <input onChange={(event)=>{this.handleChangeOrganizationName(event)}}
                               name={"orgnization"}
                               type={"text"}
                               className={"form-control"}
                               value={this.state.newOrganization}
                               placeholder={"Укажите наименование !НОВОЙ! организации и нажмите кнопку с плюсом"}
                        />
                        <button onClick={(event)=>{this.handleAddOrg(event)}}
                                className={"btn btn-secondary fa fa-plus"}
                                disabled={this.state.newOrganization===""}
                        ></button>
                    </div>
                    {list.length===0 && !this.state.isLoading && <div><i>В базе нет организаций</i></div>}
                    {this.state.isLoading && <div><i className={"fas fa-spinner fa-spin"}></i> Загружаем...</div>}
                    <div className="mb-2 overflow-auto height50vh list-group"> {list} </div>
                    <div className={"d-flex justify-content-center"}>
                        <button
                            className={"btn btn-primary"}
                            disabled={this.state.focused===null}
                            onClick={(event)=>{this.handleSelect(event)}}
                        >Выбрать</button>
                        <button className={"btn btn-secondary"} onClick={this.handleCloseModal}>Закрыть</button>
                    </div>
                    {this.state.statusMessage.message &&(
                        <FlashMessage
                            statusMessage={this.state.statusMessage}
                            clearMessage={this.setMessage}
                        />
                    )}
                </ReactModal>
            </div>
        );
    }

}