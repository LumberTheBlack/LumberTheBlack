import React, {Component} from 'react';
import ReactModal from 'react-modal';

export default class DialogModal extends Component{
    constructor(props){
        super(props);
        ReactModal.setAppElement(props.parent);
        this.state={
          showModal:false
        };
        this.handleOpenModal=this.handleOpenModal.bind(this);
        this.handleCloseModal=this.handleCloseModal.bind(this);
        this.handleCancelSelect=this.handleCancelSelect.bind(this);
    }
    handleOpenModal(){
        this.setState({
            showModal:true
        });
    }
    handleCloseModal(){
        this.setState({
            showModal:false
        });
    }
    handleCancelSelect(){
        this.props.onSelect(null);
        this.handleCloseModal();
    }
    render(){
        const {btnClass,btnLabel,children}=this.props;
        return(
            <div>
                <button className={btnClass} onClick={(event)=>{this.handleOpenModal()}}>{btnLabel}</button>
                <ReactModal
                  isOpen={this.state.showModal}
                  onRequestClose={()=>{this.handleCloseModal()}}
                >
                    {children}
                   <div className={"mt-1 d-flex justify-content-center align-items-center"}>
                    <button className={"btn btn-info"} onClick={event=>this.handleCloseModal()}> Выбрать</button>
                    <button className={"btn btn-secondary"} onClick={event=>this.handleCancelSelect()}>Отмена</button>
                   </div>
                </ReactModal>
            </div>
        );
    }
}