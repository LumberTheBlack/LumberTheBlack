import React,{Component} from 'react';
import {Line,Bar} from 'react-chartjs-2';

const components = {
    line: Line,
    bar: Bar
};
 
export default class ChartJsComponent extends Component{
       constructor(props){
             super(props);
             this.state = {
               labels: props.data_x, //x-axis
               datasets: [
                  {
                     label: props.label,
                     fill: false,
                     lineTension: 0.5,
                     backgroundColor: props.bg_color?props.bg_color:'rgba(75,192,192,1)',
                     borderColor: 'rgba(0,0,0,1)',
                     borderWidth: 2,
                     data: props.data_y   //y-axis
                  }
               ]
             }  

       }   
       render(){
           const Chart=components[this.props.chartType];
           return(
              <div>
                 <Chart
                   data={this.state}
                   options={{
                     title:{
                       display:true,
                       text:this.props.title,
                       fontSize:20
                     },
                     legend:{
                       display:true,
                       position:'right'
                     }
                   }}
                 />
              </div>
           );
       }
}