import React from 'react';
import {render} from 'react-dom';
import AppealProps from './components/appealProps';

$(document).ready(function(){
    const appealPropsType=$('#appealPropsContainer').data('typeofappealprops');
    render(
        <AppealProps appealPropsType={appealPropsType}/>,
        document.getElementById('appealPropsContainer')
    );
});