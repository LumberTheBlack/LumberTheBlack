import React from 'react';
import {render} from 'react-dom' ;
import FileReferenceList from './components/fileList';
import '../css/file.css';
import Dropzone from 'dropzone/dist/min/dropzone.min';

window.Dropzone = Dropzone;

Dropzone.autoDiscover = false;

$(document).ready(function(){
    const postId=$('#fileListContainer').data('post');
    const postObjectPath=$('#fileListContainer').data('path');
    var fileList=render(
        <FileReferenceList
           postId={postId}
           postObject={postObjectPath==undefined?"post":postObjectPath}
           initializeDropzone={InitializeDropzone}
        />,
        document.getElementById('fileListContainer')
    );
});



/**
 *
 * @param {ReferenceList} referenceList
 * @constructor
 */
function InitializeDropzone(fileList){
    var formElement=document.querySelector('.js-reference-dropzone');
    if(!formElement) {return;}
    var dropzone=new Dropzone(
        formElement,
        {
            paramName: 'reference',
            init: function () {
                this.on('error',function(file,data){
                    if(data.detail){
                        this.emit('error',file,data.detail);
                    }
                });
                this.on('success', function(file, data) {
                    //referenceList.addReference(data);
                    fileList.handleAddFileReference(data.newFileReference);
                });
            }
        }
    );
}