import React from 'react';
import {render} from 'react-dom';
import '../css/adminAppeal.css';
import AppealForm from "./components/AppealForm";
import Dropzone from 'dropzone/dist/min/dropzone.min';

window.Dropzone = Dropzone;
Dropzone.autoDiscover = false;

$(document).ready(function(){
    const legal=$('#appeal_container').data('legal');
    const appeal=$('#appeal_container').data('appeal');
    //console.log({APPEAL:appeal});


    function handleSelect(obj){
        console.log(obj);
    }
    render(
        <AppealForm
            complainant_parent={'#complainant_list_container'}
            individual={legal==undefined || legal!==1}
            appeal={appeal}
            initializeDropzone={InitializeDropzone}
        />,
        document.getElementById('appeal_container')
    );
   // InitializeDropzone(window.fileList);

});
function InitializeDropzone(fileList){
    var formElement=document.querySelector('.js-reference-dropzone');
    if(!formElement) {return;}
    var dropzone=new Dropzone(
        formElement,
        {
            paramName: 'reference',
            timeout: 300000,
            init: function () {
                this.on('error',function(file,data){
                    if(data.detail){
                        this.emit('error',file,data.detail);
                    }
                });
                this.on('success', function(file, data) {
                    //referenceList.addReference(data);
                    fileList.handleAddFileReference(data.newFileReference);
                });
            }
        }
    );
}