import fetchJson from "./common";

export function getPrinters(search=null){
    return fetchJson("/admin/printer/get"+(search?"/"+search:""));
}
export function deletePrinter(id){
    return fetchJson("/admin/printer/"+id+"/delete",{
        method:"DELETE"
    });
}
export function savePrinter(value){
    return fetchJson(
        "/admin/printer/save",
        {
            method: 'POST',
            body: JSON.stringify(value),
            headers: {
                'Content-Type': 'application/json'
            }
        }
    );
}