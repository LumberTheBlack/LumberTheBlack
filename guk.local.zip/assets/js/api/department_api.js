import fetchJson from "./common";

export function getDepartment(value=null){
    return fetchJson(value!=null?'/admin/department/get/'+value:'/admin/department/get/');
}
export function saveDepartment(department){
    return fetchJson(
        '/admin/department/save',
        {
            method: 'POST',
            body: JSON.stringify(department),
            headers: {
                'Content-Type': 'application/json'
            }
        }
        );
}
export function deleteDepartment(id){
    return fetchJson('/admin/department/'+id+'/delete',{
        method: 'DELETE'
    })
}
