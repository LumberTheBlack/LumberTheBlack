export function getNomenclatures(){
    return fetchJson('/admin/nomenclature/list').then(
        data=>data.nomenclatures
    );
}
function fetchJson(url, options) {
    return fetch(url,Object.assign({credentials: 'same-origin',    }, options))
        .then(response => {              //return response.json() - if return empty response gens error
            return response.text()
                .then(text=>text?JSON.parse(text):'');     //// decode JSON, but avoid problems with empty responses
        });
}