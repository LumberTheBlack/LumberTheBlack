export default function fetchJson(url, options) {
    return fetch(url,Object.assign({credentials: 'same-origin',    }, options))
        .then(response => {              //return response.json() - if return empty response gens error
            return response.text().then(text=> {
                return {
                    content: text?JSON.parse(text):'',
                    status: response.status,
                    statusText: response.statusText
                }
            });     //// decode JSON, but avoid problems with empty responses
        });
}
export function statusOk(status){
    return (status >= 200 && status < 300);
}