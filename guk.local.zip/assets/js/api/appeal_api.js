export function getAppealProps(type){
    return fetchJson("/admin/appeal/props/"+type+"/list").then(
        data=>data.appeal_props_items
    );
}
export function createAppealProps(type_of_appeal_props,newAppealProp){
    return fetchJson(
        '/admin/appeal/props/'+type_of_appeal_props+'/new',
        {
            method: 'POST',
            body: JSON.stringify(newAppealProp),
            headers:{
                'Content-Type': 'application/json'
            }
        }
    );
}
export function saveAppealProp(type_of_appeal_props,editItem){
    return fetchJson(
        '/admin/appeal/props/'+type_of_appeal_props+'/edit/'+editItem.id,
        {
            method: 'POST',
            body: JSON.stringify(editItem),
            headers:{
                'Content-Type': 'application/json'
            }
        }
    );
}
export function deleteAppealProps(type_of_appeal_props, AppealProp){
    return fetchJson('/admin/appeal/props/'+type_of_appeal_props+'/delete/'+AppealProp,{
           method: 'DELETE'
    }); 
}
export function createAppeal(newAppeal){
    return fetchJson(
        '/admin/appeal/new',
        {
            method: 'POST',
            body: JSON.stringify(newAppeal),
            headers:{
                'Content-Type': 'application/json'
            }
        }
    );
}
export function saveAppeal(Appeal){
    return fetchJson(
        '/admin/appeal/'+Appeal.id+'/save',
        {
            method: 'POST',
            body: JSON.stringify(Appeal),
            headers:{
                'Content-Type': 'application/json'
            }
        }
    );
}
export function getAppealById(id) {
    return fetchJson('/admin/appeal/'+id+'/get');
}
function fetchJson(url, options) {
    return fetch(url,Object.assign({credentials: 'same-origin',    }, options))
        .then(response => {              //return response.json() - if return empty response gens error
            return response.text()
                .then(text=>text?JSON.parse(text):'');     //// decode JSON, but avoid problems with empty responses
        });
}