import fetchJson from "./common";

export function getCartridgeModels(value){
    return fetchJson("/admin/cartridgemodel/get"+(value?"/"+value:""));
}
export function saveCartridgeModel(cartridgemodel=null){
    return fetchJson("/admin/cartridgemodel/save"+(cartridgemodel?"/"+cartridgemodel.id:""),{
       method: "POST",
       body: JSON.stringify(cartridgemodel),
       headers:{
           'Content-Type':'application/json'
       }
    });
}
export default function deleteCartridgeModel(id){
    return fetchJson("/admin/cartridgemodel/"+id+"/delete",{
        method:'DELETE'
    });
}
