export function getComplainant(condition=null,individual=true){
    if(!condition)
    return fetchJson('/admin/complainant/list/'+(individual?1:0)).then(
        data=>data.complainants
    );
    return fetchJson('/admin/complainant/list/'+(individual?1:0)+"/"+condition).then(
        data=>data.complainants
    );
}
export function addComplainant(newComplainant){
    return fetchJson('/admin/complainant/new',
        {
            method: 'POST',
            body: JSON.stringify(newComplainant),
            headers:{
                'Content-Type': 'application/json'
            }
        }
        );
}
export function deleteComplainant(id,individual){
    const prefix_url=individual?'/admin/complainant/':'/admin/legal/';
    return fetchJson(prefix_url+id+'/delete',{method:'DELETE'});
}
function fetchJson(url, options) {
    return fetch(url,Object.assign({credentials: 'same-origin',    }, options))
        .then(response => {              //return response.json() - if return empty response gens error
            return response.text()
                .then(text=>text?JSON.parse(text):'');     //// decode JSON, but avoid problems with empty responses
        });
}