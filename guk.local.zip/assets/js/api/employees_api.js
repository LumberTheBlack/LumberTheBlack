import fetchJson from "./common";

export function getEmployees(value){
    return fetchJson("/admin/employee/get"+(value?"/"+value:""));
}
export function saveEmployee(employee=null){
    return fetchJson("/admin/employee/save"+(employee?"/"+employee.id:""),{
       method: "POST",
       body: JSON.stringify(employee),
       headers:{
           'Content-Type':'application/json'
       }
    });
}
export default function deleteEmployee(id){
    return fetchJson("/admin/employee/"+id+"/delete",{
        method:'DELETE'
    });
}
