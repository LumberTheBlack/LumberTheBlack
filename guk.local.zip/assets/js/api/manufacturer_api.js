import fetchJson from "./common";

export function getManufacturer(value=null){
    return fetchJson(value!=null?'/admin/manufacturer/get/'+value:'/admin/manufacturer/get/');
}
export function saveManufacturer(manufacturer){
    return fetchJson(
        '/admin/manufacturer/save',
        {
            method: 'POST',
            body: JSON.stringify(manufacturer),
            headers: {
                'Content-Type': 'application/json'
            }
        }
        );
}
export function deleteManufacturer(id){
    return fetchJson('/admin/manufacturer/'+id+'/delete',{
        method: 'DELETE'
    })
}
