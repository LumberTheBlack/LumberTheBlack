import fetchJson from "./common";

export function getRefills(value){
    return fetchJson("/admin/refill/get"+(value?"/"+value:""));
}
export function saveRefill(refill=null){
    return fetchJson("/admin/refill/save"+(refill?"/"+refill.id:""),{
       method: "POST",
       body: JSON.stringify(refill),
       headers:{
           'Content-Type':'application/json'
       }
    });
}
export function deleteRefill(id){
    return fetchJson("/admin/refill/"+id+"/delete",{
        method:'DELETE'
    });
}
export function toggleRefillStatus(id){
    return fetchJson("/admin/refill/"+id+"/togglestatus");
}