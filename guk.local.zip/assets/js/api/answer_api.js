export function createAnswer(newAnswer){
    return fetchJson(
        '/admin/answer/'+newAnswer.appeal_id+'/new',
        {
            method: 'POST',
            body: JSON.stringify(newAnswer),
            headers:{
                'Content-Type': 'application/json'
            }
        }
    );
}
export function saveAnswer(Answer){
    return fetchJson(
        '/admin/answer/'+Answer.id+'/save',
        {
            method: 'POST',
            body: JSON.stringify(Answer),
            headers:{
                'Content-Type': 'application/json'
            }
        }
    );
}
export function getAnswerById(id) {
    return fetchJson('/admin/answer/'+id+'/get');
}
function fetchJson(url, options) {
    return fetch(url,Object.assign({credentials: 'same-origin',    }, options))
        .then(response => {              //return response.json() - if return empty response gens error
            return response.text()
                .then(text=>text?JSON.parse(text):'');     //// decode JSON, but avoid problems with empty responses
        });
}