export function getFileReferences(id,path){
    if(!id)()=>{return [];}
    return fetchJson("/file/api/"+(path?(path+"/"):"")+id+"/list").then(
        (data)=>{return data.files}
    );
}
export function getContractFileReferences(id){
    if(!id)()=>{return [];}
    return fetchJson("/file/api/contract/"+id+"/list").then(
        (data)=>{return data.files}
    );
}

export function UpdateFileReference(file){
    return fetchJson('/file/api/update/'+file.id,{
        method:'POST',
        headers:{
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(file)
    });
}
export function deleteFileReference(id) {
    return fetchJson('/file/api/delete/'+id, {
        method: 'DELETE'
    });
}
export function deleteSelectedFileReference(files){
    return fetchJson('/file/api/deleteSelected',{
        method: 'DELETE',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(files)
    });
}
function fetchJson(url, options) {
    return fetch(url,
        Object.assign({credentials: 'same-origin',    }, options)
    )
        .then(response => {              //return response.json() - if return empty response gens error
            return response.text()
                .then(text=>text?JSON.parse(text):'');     //// decode JSON, but avoid problems with empty responses
        });
}