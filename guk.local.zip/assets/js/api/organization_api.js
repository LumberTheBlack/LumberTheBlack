export function getOrganizations(searchCondition=null){
    var url="/admin/organization/list";
    if(searchCondition!=null)url=url+"/"+searchCondition;
    return fetchJson(url).then(
        data=>data.organizations
    );
}
export function addOrganization(name){
    return fetchJson('/admin/organization/add/'+name);
}
export function deleteOrganization(id){
    return fetchJson('/admin/organization/'+id+'/delete',{method:'DELETE'});
}
function fetchJson(url, options) {
    return fetch(url,Object.assign({credentials: 'same-origin',    }, options))
        .then(response => {              //return response.json() - if return empty response gens error
            return response.text()
                .then(text=>text?JSON.parse(text):'');     //// decode JSON, but avoid problems with empty responses
        });
}