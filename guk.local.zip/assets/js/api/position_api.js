import fetchJson from "./common";

export function getPositions(search=null){
    return fetchJson("/admin/position/get"+(search?"/"+search:""));
}
export function deletePosition(id){
    return fetchJson("/admin/position/"+id+"/delete",{
        method:"DELETE"
    });
}
export function savePosition(value){
    return fetchJson(
        "/admin/position/save",
        {
            method: 'POST',
            body: JSON.stringify(value),
            headers: {
                'Content-Type': 'application/json'
            }
        }
    );
}