import fetchJson from "./common";

export function getCartridges(value){
    return fetchJson("/admin/cartridge/get"+(value?"/"+value:""));
}
export function saveCartridge(cartridge=null){
    return fetchJson("/admin/cartridge/save"+(cartridge?"/"+cartridge.id:""),{
       method: "POST",
       body: JSON.stringify(cartridge),
       headers:{
           'Content-Type':'application/json'
       }
    });
}
export function deleteCartridge(id){
    return fetchJson("/admin/cartridge/"+id+"/delete",{
        method:'DELETE'
    });
}
