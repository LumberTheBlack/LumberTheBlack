global.moment=require('moment');
require('tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min');
import 'moment-timezone';
import "../css/post.css"

$(document).ready(function () {
    var picker=$('[data-toggle="datetimepicker"]');
    var dataFormat=picker.data('format');
    var format=dataFormat?dataFormat:'DD.MM.YYYY HH:mm:ss';
    moment.locale('ru');
    var date = moment(picker.val(),format);
        picker.datetimepicker({
            date: date,
            format: format,
            locale: 'ru',
            viewMode: (dataFormat)?((dataFormat=="MM.YYYY")?"months":(dataFormat=="YYYY")?"years":"days"):"days",
            icons:{
                time: 'fa fa-clock'
            }
        });
    }
);