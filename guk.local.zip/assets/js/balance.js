import React from 'react';
import {render} from 'react-dom';
import BalanceForm from "./components/balanceForm";

$(document).ready(function(){
    render(
        <BalanceForm />,
        document.getElementById('balance-container')
    );
});