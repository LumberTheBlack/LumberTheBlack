import React from 'react';
import {render} from 'react-dom';
import '../css/adminAnswer.css';
import Dropzone from 'dropzone/dist/min/dropzone.min';
import AnswerForm from "./components/AnswerForm";

window.Dropzone = Dropzone;
Dropzone.autoDiscover = false;

$(document).ready(function(){
    const appeal=$('#answer_container').data('appeal');
    const answer=$('#answer_container').data('answer');

    render(
        <AnswerForm
            appeal={appeal}
            answer={answer}
            initializeDropzone={InitializeDropzone}
        />,
        document.getElementById('answer_container')
    );

});
function InitializeDropzone(fileList){
    var formElement=document.querySelector('.js-reference-dropzone');
    if(!formElement) {return;}
    var dropzone=new Dropzone(
        formElement,
        {
            paramName: 'reference',
            timeout: 300000,
            init: function () {
                this.on('error',function(file,data){
                    if(data.detail){
                        this.emit('error',file,data.detail);
                    }
                });
                this.on('success', function(file, data) {
                    //referenceList.addReference(data);
                    fileList.handleAddFileReference(data.newFileReference);
                });
            }
        }
    );
}