import React from 'react';
import {render} from "react-dom";
import Department from "./components/Department";

$(document).ready(function(){
    render(
        <Department/>,
        document.getElementById("department")
    );
});