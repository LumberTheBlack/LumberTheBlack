<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20200716053629 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE address_object (id INT AUTO_INCREMENT NOT NULL, guid CHAR(36) NOT NULL COMMENT \'(DC2Type:guid)\', parent_guid CHAR(36) NOT NULL COMMENT \'(DC2Type:guid)\', parent_guid_mun CHAR(36) NOT NULL COMMENT \'(DC2Type:guid)\', ao_level INT NOT NULL, code VARCHAR(255) DEFAULT NULL, short_name VARCHAR(255) NOT NULL, formal_name VARCHAR(255) NOT NULL, ao_guid CHAR(36) NOT NULL COMMENT \'(DC2Type:guid)\', PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE answer (id INT AUTO_INCREMENT NOT NULL, content LONGTEXT DEFAULT NULL, number VARCHAR(255) NOT NULL, answer_date DATE NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE file_reference (id INT AUTO_INCREMENT NOT NULL, answer_id INT DEFAULT NULL, file_name VARCHAR(255) NOT NULL, original_file_name VARCHAR(255) NOT NULL, path VARCHAR(255) DEFAULT NULL, size INT NOT NULL, mime_type VARCHAR(255) NOT NULL, created_at DATETIME NOT NULL, caption VARCHAR(255) DEFAULT NULL, INDEX IDX_20ACF665AA334807 (answer_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE file_reference ADD CONSTRAINT FK_20ACF665AA334807 FOREIGN KEY (answer_id) REFERENCES answer (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE file_reference DROP FOREIGN KEY FK_20ACF665AA334807');
        $this->addSql('DROP TABLE address_object');
        $this->addSql('DROP TABLE answer');
        $this->addSql('DROP TABLE file_reference');
    }
}
