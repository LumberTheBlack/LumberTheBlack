<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20200720115223 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
//        $this->addSql('ALTER TABLE address_object CHANGE parent_guid parent_guid CHAR(36) DEFAULT NULL COMMENT \'(DC2Type:guid)\'');
//        $this->addSql('ALTER TABLE address_object ADD CONSTRAINT FK_93F42E53168CF906 FOREIGN KEY (parent_guid) REFERENCES address_object (guid)');
//        $this->addSql('CREATE INDEX IDX_93F42E53168CF906 ON address_object (parent_guid)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
 //       $this->addSql('ALTER TABLE address_object DROP FOREIGN KEY FK_93F42E53168CF906');
 //       $this->addSql('DROP INDEX IDX_93F42E53168CF906 ON address_object');
 //       $this->addSql('ALTER TABLE address_object CHANGE parent_guid parent_guid CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\'');
    }
}
