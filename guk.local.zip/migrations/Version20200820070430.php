<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20200820070430 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE balance (id INT AUTO_INCREMENT NOT NULL, personal_account_id INT NOT NULL, saldo DOUBLE PRECISION NOT NULL, UNIQUE INDEX UNIQ_ACF41FFEDBBBF81A (personal_account_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE balance_created_at (id INT AUTO_INCREMENT NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE building (id INT AUTO_INCREMENT NOT NULL, outside_id INT NOT NULL, type_id INT NOT NULL, pid INT NOT NULL, number INT NOT NULL, litera VARCHAR(2) DEFAULT NULL, INDEX IDX_E16F61D45A7970C1 (outside_id), INDEX IDX_E16F61D4C54C8C93 (type_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE building_type (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE outside (id INT AUTO_INCREMENT NOT NULL, type_id INT NOT NULL, pid INT NOT NULL, name VARCHAR(255) NOT NULL, INDEX IDX_B5EAFDA6C54C8C93 (type_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE outside_type (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE personal_account (id INT AUTO_INCREMENT NOT NULL, room_id INT NOT NULL, pid VARCHAR(255) NOT NULL, owner VARCHAR(255) NOT NULL, INDEX IDX_FE115F8F54177093 (room_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE property (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE room (id INT AUTO_INCREMENT NOT NULL, building_id INT NOT NULL, property_id INT NOT NULL, pid INT NOT NULL, name VARCHAR(255) NOT NULL, INDEX IDX_729F519B4D2A7E12 (building_id), INDEX IDX_729F519B549213EC (property_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE balance ADD CONSTRAINT FK_ACF41FFEDBBBF81A FOREIGN KEY (personal_account_id) REFERENCES personal_account (id)');
        $this->addSql('ALTER TABLE building ADD CONSTRAINT FK_E16F61D45A7970C1 FOREIGN KEY (outside_id) REFERENCES outside (id)');
        $this->addSql('ALTER TABLE building ADD CONSTRAINT FK_E16F61D4C54C8C93 FOREIGN KEY (type_id) REFERENCES building_type (id)');
        $this->addSql('ALTER TABLE outside ADD CONSTRAINT FK_B5EAFDA6C54C8C93 FOREIGN KEY (type_id) REFERENCES outside_type (id)');
        $this->addSql('ALTER TABLE personal_account ADD CONSTRAINT FK_FE115F8F54177093 FOREIGN KEY (room_id) REFERENCES room (id)');
        $this->addSql('ALTER TABLE room ADD CONSTRAINT FK_729F519B4D2A7E12 FOREIGN KEY (building_id) REFERENCES building (id)');
        $this->addSql('ALTER TABLE room ADD CONSTRAINT FK_729F519B549213EC FOREIGN KEY (property_id) REFERENCES property (id)');
//        $this->addSql('DROP TABLE address_object_tmp');
 //       $this->addSql('ALTER TABLE address_objects ADD PRIMARY KEY (guid)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE room DROP FOREIGN KEY FK_729F519B4D2A7E12');
        $this->addSql('ALTER TABLE building DROP FOREIGN KEY FK_E16F61D4C54C8C93');
        $this->addSql('ALTER TABLE building DROP FOREIGN KEY FK_E16F61D45A7970C1');
        $this->addSql('ALTER TABLE outside DROP FOREIGN KEY FK_B5EAFDA6C54C8C93');
        $this->addSql('ALTER TABLE balance DROP FOREIGN KEY FK_ACF41FFEDBBBF81A');
        $this->addSql('ALTER TABLE room DROP FOREIGN KEY FK_729F519B549213EC');
        $this->addSql('ALTER TABLE personal_account DROP FOREIGN KEY FK_FE115F8F54177093');
        $this->addSql('CREATE TABLE address_object_tmp (id INT AUTO_INCREMENT NOT NULL, guid CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', parent_guid CHAR(36) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', parent_guid_mun CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', ao_level INT NOT NULL, code VARCHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci`, short_name VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, formal_name VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ao_guid CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', UNIQUE INDEX guid (guid), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('DROP TABLE balance');
        $this->addSql('DROP TABLE balance_created_at');
        $this->addSql('DROP TABLE building');
        $this->addSql('DROP TABLE building_type');
        $this->addSql('DROP TABLE outside');
        $this->addSql('DROP TABLE outside_type');
        $this->addSql('DROP TABLE personal_account');
        $this->addSql('DROP TABLE property');
        $this->addSql('DROP TABLE room');
        $this->addSql('ALTER TABLE address_objects DROP PRIMARY KEY');
    }
}
