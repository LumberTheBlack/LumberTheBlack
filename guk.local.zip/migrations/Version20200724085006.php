<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20200724085006 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
  /*      $this->addSql('CREATE TABLE appeal (id INT AUTO_INCREMENT NOT NULL, type_of_appeal_id INT NOT NULL, character_of_appeal_id INT NOT NULL, form_of_appeal_id INT NOT NULL, registrar_id INT NOT NULL, data_in DATE NOT NULL, content LONGTEXT DEFAULT NULL, date_doc DATE NOT NULL, initial_number VARCHAR(255) NOT NULL, execution_time INT NOT NULL, number VARCHAR(255) NOT NULL, INDEX IDX_9679435149954E7C (type_of_appeal_id), INDEX IDX_9679435111B27110 (character_of_appeal_id), INDEX IDX_96794351A491BF1B (form_of_appeal_id), INDEX IDX_96794351D1AA2FC1 (registrar_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE appeal_user (appeal_id INT NOT NULL, user_id INT NOT NULL, INDEX IDX_205FC9B9F9B2547F (appeal_id), INDEX IDX_205FC9B9A76ED395 (user_id), PRIMARY KEY(appeal_id, user_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE appeal ADD CONSTRAINT FK_9679435149954E7C FOREIGN KEY (type_of_appeal_id) REFERENCES type_of_appeal (id)');
        $this->addSql('ALTER TABLE appeal ADD CONSTRAINT FK_9679435111B27110 FOREIGN KEY (character_of_appeal_id) REFERENCES character_of_appeal (id)');
        $this->addSql('ALTER TABLE appeal ADD CONSTRAINT FK_96794351A491BF1B FOREIGN KEY (form_of_appeal_id) REFERENCES form_of_appeal (id)');
        $this->addSql('ALTER TABLE appeal ADD CONSTRAINT FK_96794351D1AA2FC1 FOREIGN KEY (registrar_id) REFERENCES user (id)');
        $this->addSql('ALTER TABLE appeal_user ADD CONSTRAINT FK_205FC9B9F9B2547F FOREIGN KEY (appeal_id) REFERENCES appeal (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE appeal_user ADD CONSTRAINT FK_205FC9B9A76ED395 FOREIGN KEY (user_id) REFERENCES user (id) ON DELETE CASCADE');
//        $this->addSql('DROP TABLE address_object_tmp');
        $this->addSql('ALTER TABLE address_objects MODIFY id INT NOT NULL');
        $this->addSql('ALTER TABLE address_objects DROP PRIMARY KEY');
        $this->addSql('ALTER TABLE address_objects CHANGE id id INT NOT NULL');
        $this->addSql('ALTER TABLE address_objects ADD PRIMARY KEY (guid)');
  */      $this->addSql('ALTER TABLE answer ADD appeal_id INT NOT NULL');
        $this->addSql('ALTER TABLE answer ADD CONSTRAINT FK_DADD4A25F9B2547F FOREIGN KEY (appeal_id) REFERENCES appeal (id)');
        $this->addSql('CREATE INDEX IDX_DADD4A25F9B2547F ON answer (appeal_id)');
        $this->addSql('ALTER TABLE file_reference ADD appeal_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE file_reference ADD CONSTRAINT FK_20ACF665F9B2547F FOREIGN KEY (appeal_id) REFERENCES appeal (id)');
        $this->addSql('CREATE INDEX IDX_20ACF665F9B2547F ON file_reference (appeal_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE answer DROP FOREIGN KEY FK_DADD4A25F9B2547F');
        $this->addSql('ALTER TABLE appeal_user DROP FOREIGN KEY FK_205FC9B9F9B2547F');
        $this->addSql('ALTER TABLE file_reference DROP FOREIGN KEY FK_20ACF665F9B2547F');
        $this->addSql('CREATE TABLE address_object_tmp (id INT AUTO_INCREMENT NOT NULL, guid CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', parent_guid CHAR(36) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', parent_guid_mun CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', ao_level INT NOT NULL, code VARCHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci`, short_name VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, formal_name VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ao_guid CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', UNIQUE INDEX guid (guid), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('DROP TABLE appeal');
        $this->addSql('DROP TABLE appeal_user');
        $this->addSql('ALTER TABLE address_objects DROP PRIMARY KEY');
        $this->addSql('ALTER TABLE address_objects CHANGE id id INT AUTO_INCREMENT NOT NULL');
        $this->addSql('ALTER TABLE address_objects ADD PRIMARY KEY (id)');
        $this->addSql('DROP INDEX IDX_DADD4A25F9B2547F ON answer');
        $this->addSql('ALTER TABLE answer DROP appeal_id');
        $this->addSql('DROP INDEX IDX_20ACF665F9B2547F ON file_reference');
        $this->addSql('ALTER TABLE file_reference DROP appeal_id');
    }
}
