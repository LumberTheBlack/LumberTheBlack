<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20200728105954 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE complainant (id INT AUTO_INCREMENT NOT NULL, address_id INT NOT NULL, type_id INT NOT NULL, fio VARCHAR(255) NOT NULL, INDEX IDX_A647D432F5B7AF75 (address_id), INDEX IDX_A647D432C54C8C93 (type_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE complainant_type (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE legal (id INT AUTO_INCREMENT NOT NULL, complainant_id INT NOT NULL, organization_id INT NOT NULL, position VARCHAR(255) NOT NULL, INDEX IDX_E362C0504C422040 (complainant_id), INDEX IDX_E362C05032C8A3DE (organization_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE organization (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE complainant ADD CONSTRAINT FK_A647D432F5B7AF75 FOREIGN KEY (address_id) REFERENCES residence (id)');
        $this->addSql('ALTER TABLE complainant ADD CONSTRAINT FK_A647D432C54C8C93 FOREIGN KEY (type_id) REFERENCES complainant_type (id)');
        $this->addSql('ALTER TABLE legal ADD CONSTRAINT FK_E362C0504C422040 FOREIGN KEY (complainant_id) REFERENCES complainant (id)');
        $this->addSql('ALTER TABLE legal ADD CONSTRAINT FK_E362C05032C8A3DE FOREIGN KEY (organization_id) REFERENCES organization (id)');
//        $this->addSql('DROP TABLE address_object_tmp');
//        $this->addSql('ALTER TABLE address_objects ADD PRIMARY KEY (guid)');
        $this->addSql('ALTER TABLE appeal ADD complainant_id INT NOT NULL');
        $this->addSql('ALTER TABLE appeal ADD CONSTRAINT FK_967943514C422040 FOREIGN KEY (complainant_id) REFERENCES complainant (id)');
        $this->addSql('CREATE INDEX IDX_967943514C422040 ON appeal (complainant_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE appeal DROP FOREIGN KEY FK_967943514C422040');
        $this->addSql('ALTER TABLE legal DROP FOREIGN KEY FK_E362C0504C422040');
        $this->addSql('ALTER TABLE complainant DROP FOREIGN KEY FK_A647D432C54C8C93');
        $this->addSql('ALTER TABLE legal DROP FOREIGN KEY FK_E362C05032C8A3DE');
        $this->addSql('CREATE TABLE address_object_tmp (id INT AUTO_INCREMENT NOT NULL, guid CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', parent_guid CHAR(36) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', parent_guid_mun CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', ao_level INT NOT NULL, code VARCHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci`, short_name VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, formal_name VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ao_guid CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', UNIQUE INDEX guid (guid), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('DROP TABLE complainant');
        $this->addSql('DROP TABLE complainant_type');
        $this->addSql('DROP TABLE legal');
        $this->addSql('DROP TABLE organization');
        $this->addSql('ALTER TABLE address_objects DROP PRIMARY KEY');
        $this->addSql('DROP INDEX IDX_967943514C422040 ON appeal');
        $this->addSql('ALTER TABLE appeal DROP complainant_id');
    }
}
