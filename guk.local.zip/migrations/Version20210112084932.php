<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210112084932 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        //$this->addSql('CREATE TABLE act (id INT AUTO_INCREMENT NOT NULL, contragent VARCHAR(255) NOT NULL, number VARCHAR(255) NOT NULL, created_at DATE NOT NULL, subject LONGTEXT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE file_reference ADD act_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE file_reference ADD CONSTRAINT FK_20ACF665D1A55B28 FOREIGN KEY (act_id) REFERENCES act (id)');
        $this->addSql('CREATE INDEX IDX_20ACF665D1A55B28 ON file_reference (act_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE file_reference DROP FOREIGN KEY FK_20ACF665D1A55B28');
        $this->addSql('CREATE TABLE address_object_tmp (id INT AUTO_INCREMENT NOT NULL, guid CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', parent_guid CHAR(36) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', parent_guid_mun CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', ao_level INT NOT NULL, code VARCHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci`, short_name VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, formal_name VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ao_guid CHAR(36) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci` COMMENT \'(DC2Type:guid)\', UNIQUE INDEX guid (guid), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('DROP TABLE act');
        $this->addSql('ALTER TABLE address_objects DROP PRIMARY KEY');
        $this->addSql('DROP INDEX IDX_20ACF665D1A55B28 ON file_reference');
        $this->addSql('ALTER TABLE file_reference DROP act_id');
    }
}
