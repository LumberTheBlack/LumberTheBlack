var Encore = require('@symfony/webpack-encore');

// Manually configure the runtime environment if not already configured yet by the "encore" command.
// It's useful when you use tools that rely on webpack.config.js file.
if (!Encore.isRuntimeEnvironmentConfigured()) {
    Encore.configureRuntimeEnvironment(process.env.NODE_ENV || 'dev');
}

Encore
    // directory where compiled assets will be stored
    .setOutputPath('public/build/')
    // public path used by the web server to access the output path
    .setPublicPath('/build')
    // only needed for CDN's or sub-directory deploy
    //.setManifestKeyPrefix('build/')

    /*
     * ENTRY CONFIG
     *
     * Add 1 entry for each "page" of your app
     * (including one that's included on every page - e.g. "app")
     *
     * Each entry will result in one JavaScript file (e.g. app.js)
     * and one CSS file (e.g. app.css) if your JavaScript imports CSS.
     */
    .addEntry('app', './assets/js/app.js')
    .addEntry('admin_appeal_props', './assets/js/adminAppealProps.js')
    .addEntry('admin_appeal','./assets/js/adminAppeal.js')
    .addEntry('admin_answer','./assets/js/adminAnswer.js')
    .addEntry('admin_executors','./assets/js/adminExecutors.js')
    .addEntry('import_balance','./assets/js/importBalance.js')
    .addEntry('balance','./assets/js/balance.js')
    //.addEntry('page2', './assets/js/page2.js')
    .addEntry('file', './assets/js/file.js')
    .addEntry('post_tags_media','./assets/js/post_tags_media.js')
    .addEntry('react_input_css','./node_modules/react-tagsinput/react-tagsinput.css')
    .addEntry('dateTimePicker','./assets/js/dateTimePickerField.js')
    .addEntry('dateTimePickerCss','./node_modules/tempusdominus-bootstrap-4/build/css/tempusdominus-bootstrap-4.min.css')
    .addEntry('refill', './assets/js/adminRefill.js')
    .addEntry('department','./assets/js/adminDepartment.js')
    .addEntry('position', './assets/js/adminPosition.js')
    .addEntry('employee', './assets/js/adminEmployee.js')
    .addEntry('manufacturer', './assets/js/adminManufacturer.js')
    .addEntry('printer', './assets/js/adminPrinter.js')
    .addEntry('cartridgemodel', './assets/js/adminCartridgeModel.js')
    .addEntry('cartridge', './assets/js/adminCartridge.js')
    .addEntry('chart_js','./assets/js/chartJs.js')

    // When enabled, Webpack "splits" your files into smaller pieces for greater optimization.
    .splitEntryChunks()

    // will require an extra script tag for runtime.js
    // but, you probably want this, unless you're building a single-page app
    .enableSingleRuntimeChunk()

    /*
     * FEATURE CONFIG
     *
     * Enable & configure other features below. For a full
     * list of features, see:
     * https://symfony.com/doc/current/frontend.html#adding-more-features
     */
    .cleanupOutputBeforeBuild()
    .enableBuildNotifications()
    .enableSourceMaps(!Encore.isProduction())
    // enables hashed filenames (e.g. app.abc123.css)
    .enableVersioning(Encore.isProduction())

    // enables @babel/preset-env polyfills
    .configureBabelPresetEnv((config) => {
        config.useBuiltIns = 'usage';
        config.corejs = 3;
    })

    // enables Sass/SCSS support
    //.enableSassLoader()

    // uncomment if you use TypeScript
    //.enableTypeScriptLoader()

    // uncomment to get integrity="..." attributes on your script & link tags
    // requires WebpackEncoreBundle 1.4 or higher
    //.enableIntegrityHashes(Encore.isProduction())

    // uncomment if you're having problems with a jQuery plugin
    //.autoProvidejQuery()

    // uncomment if you use API Platform Admin (composer req api-admin)
    .enableReactPreset()
;

module.exports = Encore.getWebpackConfig();
